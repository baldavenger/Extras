#ifndef __RRT_H_INCLUDED__
#define __RRT_H_INCLUDED__

__DEVICE__ float3 inline rrt( float3 aces)
{
float saturation = rgb_2_saturation( aces);
float ycIn = rgb_2_yc( aces);
float s = sigmoid_shaper( (saturation - 0.4f) / 0.2f);
float addedGlow = 1.0f + glow_fwd( ycIn, RRT_GLOW_GAIN * s, RRT_GLOW_MID);
aces = mult_f_f3( addedGlow, aces);
float hue = rgb_2_hue( aces);
float centeredHue = center_hue( hue, RRT_RED_HUE);
float hueWeight = cubic_basis_shaper( centeredHue, RRT_RED_WIDTH);
aces.x = aces.x + hueWeight * saturation * (RRT_RED_PIVOT - aces.x) * (1.0f - RRT_RED_SCALE);
aces = max_f3_f( aces, 0.0f);
float3 rgbPre = mult_f3_f33( aces, AP0_2_AP1_MAT);
rgbPre = max_f3_f( rgbPre, 0.0f);
rgbPre = mult_f3_f33( rgbPre, RRT_SAT_MAT);

float3 rgbPost;
rgbPost.x = segmented_spline_c5_fwd( rgbPre.x);
rgbPost.y = segmented_spline_c5_fwd( rgbPre.y);
rgbPost.z = segmented_spline_c5_fwd( rgbPre.z);
float3 rgbOces = mult_f3_f33( rgbPost, AP1_2_AP0_MAT);

return rgbOces;
}

#endif