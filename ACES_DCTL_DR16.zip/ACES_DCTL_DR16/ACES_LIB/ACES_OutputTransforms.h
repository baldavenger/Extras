#ifndef __ACES_OUTPUTTRANSFORMS_H_INCLUDED__
#define __ACES_OUTPUTTRANSFORMS_H_INCLUDED__

#include "ACES_Functions.h"
#include "ACES_Transform_Common.h"
#include "ACES_RRT_Common.h"
#include "ACES_ODT_Common.h"
#include "ACES_SSTS.h"

__DEVICE__ inline float3 limit_to_primaries( float3 XYZ, Chromaticities LIMITING_PRI)
{
mat3 XYZ_2_LIMITING_PRI_MAT = XYZtoRGB( LIMITING_PRI);
mat3 LIMITING_PRI_2_XYZ_MAT = RGBtoXYZ( LIMITING_PRI);
float3 rgb = mult_f3_f33( XYZ, XYZ_2_LIMITING_PRI_MAT);
float3 limitedRgb = clamp_f3( rgb, 0.0f, 1.0f);
return mult_f3_f33( limitedRgb, LIMITING_PRI_2_XYZ_MAT);
}

__DEVICE__ inline float3 dark_to_dim( float3 XYZ)
{
float3 xyY = XYZ_2_xyY(XYZ);
xyY.z = _fmaxf( xyY.z, 0.0f);
xyY.z = _powf( xyY.z, DIM_SURROUND_GAMMA);
return xyY_2_XYZ(xyY);
}

__DEVICE__ inline float3 dim_to_dark( float3 XYZ)
{
float3 xyY = XYZ_2_xyY(XYZ);
xyY.z = _fmaxf( xyY.z, 0.0f);
xyY.z = _powf( xyY.z, 1.0f / DIM_SURROUND_GAMMA);
return xyY_2_XYZ(xyY);
}

__DEVICE__ inline float3 outputTransform
(
float3 in,
float Y_MIN,
float Y_MID,
float Y_MAX,    
Chromaticities DISPLAY_PRI,
Chromaticities LIMITING_PRI,
int EOTF,  
int SURROUND,
bool STRETCH_BLACK = true,
bool D60_SIM = false,
bool LEGAL_RANGE = false
)
{
mat3 XYZ_2_DISPLAY_PRI_MAT = XYZtoRGB( DISPLAY_PRI);
TsParams PARAMS_DEFAULT = init_TsParams( Y_MIN, Y_MAX);
float expShift = _log2f(inv_ssts(Y_MID, PARAMS_DEFAULT)) - _log2f(0.18f);
TsParams PARAMS = init_TsParams( Y_MIN, Y_MAX, expShift);
float3 rgbPre = rrt_sweeteners( in);
float3 rgbPost = ssts_f3( rgbPre, PARAMS);
float3 linearCV = Y_2_linCV_f3( rgbPost, Y_MAX, Y_MIN);
float3 XYZ = mult_f3_f33( linearCV, AP1_2_XYZ_MAT);
if (SURROUND == 0) {
} else if (SURROUND == 1) {
if ((EOTF == 1) || (EOTF == 2) || (EOTF == 3)) { 
XYZ = dark_to_dim( XYZ);
}
} else if (SURROUND == 2) {
}
XYZ = limit_to_primaries( XYZ, LIMITING_PRI); 
if (D60_SIM == false) {
if ((DISPLAY_PRI.white.x != AP0.white.x) && (DISPLAY_PRI.white.y != AP0.white.y)) {
mat3 CAT = calculate_cat_matrix( AP0.white, DISPLAY_PRI.white);
XYZ = mult_f3_f33( XYZ, CAT);
}
}
linearCV = mult_f3_f33( XYZ, XYZ_2_DISPLAY_PRI_MAT);
if (D60_SIM == true) {
float SCALE = 1.0f;
if ((DISPLAY_PRI.white.x == 0.3127f) && (DISPLAY_PRI.white.y == 0.329f)) {
SCALE = 0.96362f;
} 
else if ((DISPLAY_PRI.white.x == 0.314f) && (DISPLAY_PRI.white.y == 0.351f)) {
linearCV.x = roll_white_fwd( linearCV.x, 0.918f, 0.5f);
linearCV.y = roll_white_fwd( linearCV.y, 0.918f, 0.5f);
linearCV.z = roll_white_fwd( linearCV.z, 0.918f, 0.5f);
SCALE = 0.96f;                
} 
linearCV = mult_f_f3( SCALE, linearCV);
}
linearCV = max_f3_f( linearCV, 0.0f);
float3 outputCV;
if (EOTF == 0) {
if (STRETCH_BLACK == true) {
outputCV = Y_2_ST2084_f3( max_f3_f( linCV_2_Y_f3(linearCV, Y_MAX, 0.0f), 0.0f) );
} else {
outputCV = Y_2_ST2084_f3( linCV_2_Y_f3(linearCV, Y_MAX, Y_MIN) );        
}
} else if (EOTF == 1) {
outputCV = bt1886_r_f3( linearCV, 2.4f, 1.0f, 0.0f);
} else if (EOTF == 2) {
outputCV = moncurve_r_f3( linearCV, 2.4f, 0.055f);
} else if (EOTF == 3) {
outputCV = pow_f3( linearCV, 1.0f/2.6f);
} else if (EOTF == 4) {
outputCV = linCV_2_Y_f3(linearCV, Y_MAX, Y_MIN);
} else if (EOTF == 5) {
if (STRETCH_BLACK == true) {
outputCV = Y_2_ST2084_f3( max_f3_f( linCV_2_Y_f3(linearCV, Y_MAX, 0.0f), 0.0f) );
}
else {
outputCV = Y_2_ST2084_f3( linCV_2_Y_f3(linearCV, Y_MAX, Y_MIN) );
}
outputCV = ST2084_2_HLG_1000nits_f3( outputCV);
}
if (LEGAL_RANGE == true) {
outputCV = fullRange_to_smpteRange_f3( outputCV);
}
return outputCV;    
}

__DEVICE__ inline float3 invOutputTransform
(
float3 in,
float Y_MIN,
float Y_MID,
float Y_MAX,    
Chromaticities DISPLAY_PRI,
Chromaticities LIMITING_PRI,
int EOTF,  
int SURROUND,
bool STRETCH_BLACK = true,
bool D60_SIM = false,
bool LEGAL_RANGE = false
)
{
mat3 DISPLAY_PRI_2_XYZ_MAT = RGBtoXYZ( DISPLAY_PRI);
TsParams PARAMS_DEFAULT = init_TsParams( Y_MIN, Y_MAX);
float expShift = _log2f(inv_ssts(Y_MID, PARAMS_DEFAULT)) - _log2f(0.18f);
TsParams PARAMS = init_TsParams( Y_MIN, Y_MAX, expShift);
float3 outputCV = in;
if (LEGAL_RANGE == true) {
outputCV = smpteRange_to_fullRange_f3( outputCV);
}
float3 linearCV;
if (EOTF == 0) {
if (STRETCH_BLACK == true) {
linearCV = Y_2_linCV_f3( ST2084_2_Y_f3( outputCV), Y_MAX, 0.0f);
} else {
linearCV = Y_2_linCV_f3( ST2084_2_Y_f3( outputCV), Y_MAX, Y_MIN);
}
} else if (EOTF == 1) {
linearCV = bt1886_f_f3( outputCV, 2.4f, 1.0f, 0.0f);
} else if (EOTF == 2) {
linearCV = moncurve_f_f3( outputCV, 2.4f, 0.055f);
} else if (EOTF == 3) {
linearCV = pow_f3( outputCV, 2.6f);
} else if (EOTF == 4) {
linearCV = Y_2_linCV_f3( outputCV, Y_MAX, Y_MIN);
} else if (EOTF == 5) {
outputCV = HLG_2_ST2084_1000nits_f3( outputCV);
if (STRETCH_BLACK == true) {
linearCV = Y_2_linCV_f3( ST2084_2_Y_f3( outputCV), Y_MAX, 0.0f);
} else {
linearCV = Y_2_linCV_f3( ST2084_2_Y_f3( outputCV), Y_MAX, Y_MIN);
}
}
if (D60_SIM == true) {
float SCALE = 1.0f;
if ((DISPLAY_PRI.white.x == 0.3127f) && (DISPLAY_PRI.white.y == 0.329f)) {
SCALE = 0.96362f;
linearCV = mult_f_f3( 1.0f / SCALE, linearCV);
} 
else if ((DISPLAY_PRI.white.x == 0.314f) && (DISPLAY_PRI.white.y == 0.351f)) {
SCALE = 0.96f;                
linearCV.x = roll_white_rev( linearCV.x / SCALE, 0.918f, 0.5f);
linearCV.y = roll_white_rev( linearCV.y / SCALE, 0.918f, 0.5f);
linearCV.z = roll_white_rev( linearCV.z / SCALE, 0.918f, 0.5f);
} 
}    
float3 XYZ = mult_f3_f33( linearCV, DISPLAY_PRI_2_XYZ_MAT);
if (D60_SIM == false) {
if ((DISPLAY_PRI.white.x != AP0.white.x) && (DISPLAY_PRI.white.y != AP0.white.y)) {
mat3 CAT = calculate_cat_matrix( AP0.white, DISPLAY_PRI.white);
XYZ = mult_f3_f33( XYZ, invert_f33(CAT) );
}
}
if (SURROUND == 0) {
} else if (SURROUND == 1) {

if ((EOTF == 1) || (EOTF == 2) || (EOTF == 3)) { 
XYZ = dim_to_dark( XYZ);
}
} else if (SURROUND == 2) {
}
linearCV = mult_f3_f33( XYZ, XYZ_2_AP1_MAT);
float3 rgbPost = linCV_2_Y_f3( linearCV, Y_MAX, Y_MIN);
float3 rgbPre = inv_ssts_f3( rgbPost, PARAMS);
float3 aces = inv_rrt_sweeteners( rgbPre);
return aces;
}

#endif