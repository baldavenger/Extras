#ifndef __ACES_UTILITIES_COLOR_H_INCLUDED__
#define __ACES_UTILITIES_COLOR_H_INCLUDED__

__CONSTANT__ Chromaticities AP0 =
{ {0.7347f, 0.2653f}, {0.0f, 1.0f}, {0.0001f, -0.077f}, {0.32168f, 0.33767f} };

__CONSTANT__ Chromaticities AP1 =
{ {0.713f, 0.293f}, {0.165f, 0.83f}, {0.128f, 0.044f}, {0.32168f, 0.33767f} };

__CONSTANT__ Chromaticities REC709_PRI =
{ {0.64f, 0.33f}, {0.3f, 0.6f}, {0.15f, 0.06f}, {0.3127f, 0.329f} };

__CONSTANT__ Chromaticities P3D60_PRI =
{ {0.68f, 0.32f}, {0.265f, 0.69f}, {0.15f, 0.06f}, {0.32168, 0.33767f} };

__CONSTANT__ Chromaticities P3D65_PRI =
{ {0.68f, 0.32f}, {0.265f, 0.69f}, {0.15f, 0.06f}, {0.3127f, 0.329f} };

__CONSTANT__ Chromaticities P3DCI_PRI =
{ {0.68f, 0.32f}, {0.265f, 0.69f}, {0.15f, 0.06f}, {0.314f, 0.351f} };

__CONSTANT__ Chromaticities ARRI_ALEXA_WG_PRI =
{ {0.684f, 0.313f}, {0.221f, 0.848f}, {0.0861f, -0.102f}, {0.3127f, 0.329f} };

__CONSTANT__ Chromaticities REC2020_PRI = 
{ {0.708f, 0.292f}, {0.17f, 0.797f}, {0.131f, 0.046f}, {0.3127f, 0.329f} };

__CONSTANT__ Chromaticities RIMMROMM_PRI = 
{ {0.7347f, 0.2653f}, {0.1596f, 0.8404f}, {0.0366f, 0.0001f}, {0.3457f, 0.3585f} };

__CONSTANT__ mat3 CONE_RESP_MAT_BRADFORD = 
{ {0.8951f, -0.7502f, 0.0389f}, {0.2664f, 1.7135f, -0.0685f}, {-0.1614f, 0.0367f, 1.0296f} };

__CONSTANT__ mat3 CONE_RESP_MAT_CAT02 = 
{ {0.7328f, -0.7036f, 0.003f}, {0.4296f, 1.6975f, 0.0136f}, {-0.1624f, 0.0061f, 0.9834f} };

__DEVICE__ inline float3 XYZ_2_xyY( float3 XYZ)
{  
float3 xyY;
float divisor = (XYZ.x + XYZ.y + XYZ.z);
if (divisor == 0.0f) divisor = 1e-10f;
xyY.x = XYZ.x / divisor;
xyY.y = XYZ.y / divisor;  
xyY.z = XYZ.y;
return xyY;
}

__DEVICE__ inline float3 xyY_2_XYZ( float3 xyY)
{
float3 XYZ;
XYZ.x = xyY.x * xyY.z / _fmaxf( xyY.y, 1e-10f);
XYZ.y = xyY.z;  
XYZ.z = (1.0f - xyY.x - xyY.y) * xyY.z / _fmaxf( xyY.y, 1e-10f);
return XYZ;
}

__DEVICE__ inline float rgb_2_hue( float3 rgb) 
{
float hue;
if (rgb.x == rgb.y && rgb.y == rgb.z) {
hue = 0.0f;
} else {
hue = (180.0f/M_PI) * _atan2f( _sqrtf(3.0f) * (rgb.y - rgb.z), 2.0f * rgb.x - rgb.y - rgb.z);
}
if (hue < 0.0f) hue = hue + 360.0f;
return hue;
}

__DEVICE__ inline float rgb_2_yc( float3 rgb, float ycRadiusWeight = 1.75f)
{
float r = rgb.x; 
float g = rgb.y; 
float b = rgb.z;
float chroma = _sqrtf(b * (b - g) + g * (g - r) + r * (r - b));
return ( b + g + r + ycRadiusWeight * chroma) / 3.0f;
}

__DEVICE__ inline mat3 calculate_cat_matrix( float2 src_xy, float2 des_xy)
{
mat3 coneRespMat = CONE_RESP_MAT_BRADFORD;
const float3 src_xyY = { src_xy.x, src_xy.y, 1.0f };
const float3 des_xyY = { des_xy.x, des_xy.y, 1.0f };
float3 src_XYZ = xyY_2_XYZ( src_xyY );
float3 des_XYZ = xyY_2_XYZ( des_xyY );
float3 src_coneResp = mult_f3_f33( src_XYZ, coneRespMat);
float3 des_coneResp = mult_f3_f33( des_XYZ, coneRespMat);
mat3 vkMat = {
{ des_coneResp.x / src_coneResp.x, 0.0f, 0.0f },
{ 0.0f, des_coneResp.y / src_coneResp.y, 0.0f },
{ 0.0f, 0.0f, des_coneResp.z / src_coneResp.z }
};
mat3 cat_matrix = mult_f33_f33( coneRespMat, mult_f33_f33( vkMat, invert_f33( coneRespMat ) ) );
return cat_matrix;
}

__DEVICE__ inline mat3 calc_sat_adjust_matrix( float sat, float3 rgb2Y)
{
float M[3][3];
M[0][0] = (1.0f - sat) * rgb2Y.x + sat; M[1][0] = (1.0f - sat) * rgb2Y.x; M[2][0] = (1.0f - sat) * rgb2Y.x;
M[0][1] = (1.0f - sat) * rgb2Y.y; M[1][1] = (1.0f - sat) * rgb2Y.y + sat; M[2][1] = (1.0f - sat) * rgb2Y.y;
M[0][2] = (1.0f - sat) * rgb2Y.z; M[1][2] = (1.0f - sat) * rgb2Y.z; M[2][2] = (1.0f - sat) * rgb2Y.z + sat;
mat3 R = make_mat3(make_float3(M[0][0], M[0][1], M[0][2]), make_float3(M[1][0], M[1][1], M[1][2]), make_float3(M[2][0], M[2][1], M[2][2]));
R = transpose_f33(R);
return R;
} 

__DEVICE__ inline float moncurve_f( float x, float gamma, float offs )
{
float y;
const float fs = (( gamma - 1.0f) / offs) * _powf( offs * gamma / ( ( gamma - 1.0f) * ( 1.0f + offs)), gamma);
const float xb = offs / ( gamma - 1.0f);
if ( x >= xb) 
y = _powf( ( x + offs) / ( 1.0f + offs), gamma);
else
y = x * fs;
return y;
}

__DEVICE__ inline float moncurve_r( float y, float gamma, float offs )
{
float x;
const float yb = _powf( offs * gamma / ( ( gamma - 1.0f) * ( 1.0f + offs)), gamma);
const float rs = _powf( ( gamma - 1.0f) / offs, gamma - 1.0f) * _powf( ( 1.0f + offs) / gamma, gamma);
if ( y >= yb) 
x = ( 1.0f + offs) * _powf( y, 1.0f / gamma) - offs;
else
x = y * rs;
return x;
}

__DEVICE__ inline float3 moncurve_f_f3( float3 x, float gamma, float offs)
{
float3 y;
y.x = moncurve_f( x.x, gamma, offs); y.y = moncurve_f( x.y, gamma, offs); y.z = moncurve_f( x.z, gamma, offs);
return y;
}

__DEVICE__ inline float3 moncurve_r_f3( float3 y, float gamma, float offs)
{
float3 x;
x.x = moncurve_r( y.x, gamma, offs); x.y = moncurve_r( y.y, gamma, offs); x.z = moncurve_r( y.z, gamma, offs);
return x;
}

__DEVICE__ inline float bt1886_f( float V, float gamma, float Lw, float Lb)
{
float a = _powf( _powf( Lw, 1.0f/gamma) - _powf( Lb, 1.0f/gamma), gamma);
float b = _powf( Lb, 1.0f/gamma) / ( _powf( Lw, 1.0f/gamma) - _powf( Lb, 1.0f/gamma));
float L = a * _powf( _fmaxf( V + b, 0.0f), gamma);
return L;
}

__DEVICE__ inline float bt1886_r( float L, float gamma, float Lw, float Lb)
{
float a = _powf( _powf( Lw, 1.0f/gamma) - _powf( Lb, 1.0f/gamma), gamma);
float b = _powf( Lb, 1.0f/gamma) / ( _powf( Lw, 1.0f/gamma) - _powf( Lb, 1.0f/gamma));
float V = _powf( _fmaxf( L / a, 0.0f), 1.0f/gamma) - b;
return V;
}

__DEVICE__ inline float3 bt1886_f_f3( float3 V, float gamma, float Lw, float Lb)
{
float3 L;
L.x = bt1886_f( V.x, gamma, Lw, Lb); L.y = bt1886_f( V.y, gamma, Lw, Lb); L.z = bt1886_f( V.z, gamma, Lw, Lb);
return L;
}

__DEVICE__ inline float3 bt1886_r_f3( float3 L, float gamma, float Lw, float Lb)
{
float3 V;
V.x = bt1886_r( L.x, gamma, Lw, Lb); V.y = bt1886_r( L.y, gamma, Lw, Lb); V.z = bt1886_r( L.z, gamma, Lw, Lb);
return V;
}

__DEVICE__ inline float smpteRange_to_fullRange( float in)
{
const float REFBLACK = ( 64.0f / 1023.0f);
const float REFWHITE = ( 940.0f / 1023.0f);
return (( in - REFBLACK) / ( REFWHITE - REFBLACK));
}

__DEVICE__ inline float fullRange_to_smpteRange( float in)
{
const float REFBLACK = (  64.0f / 1023.0f);
const float REFWHITE = ( 940.0f / 1023.0f);
return ( in * ( REFWHITE - REFBLACK) + REFBLACK );
}

__DEVICE__ inline float3 smpteRange_to_fullRange_f3( float3 rgbIn)
{
float3 rgbOut;
rgbOut.x = smpteRange_to_fullRange( rgbIn.x); rgbOut.y = smpteRange_to_fullRange( rgbIn.y); rgbOut.z = smpteRange_to_fullRange( rgbIn.z);
return rgbOut;
}

__DEVICE__ inline float3 fullRange_to_smpteRange_f3( float3 rgbIn)
{
float3 rgbOut;
rgbOut.x = fullRange_to_smpteRange( rgbIn.x); rgbOut.y = fullRange_to_smpteRange( rgbIn.y); rgbOut.z = fullRange_to_smpteRange( rgbIn.z);
return rgbOut;
}

__DEVICE__ inline float3 dcdm_decode( float3 XYZp)
{
float3 XYZ;
XYZ.x = (52.37f/48.0f) * _powf( XYZp.x, 2.6f);  
XYZ.y = (52.37f/48.0f) * _powf( XYZp.y, 2.6f);  
XYZ.z = (52.37f/48.0f) * _powf( XYZp.z, 2.6f);  
return XYZ;
}

__DEVICE__ inline float3 dcdm_encode( float3 XYZ)
{
float3 XYZp;
XYZp.x = _powf( (48.0f/52.37f) * XYZ.x, 1.0f/2.6f);
XYZp.y = _powf( (48.0f/52.37f) * XYZ.y, 1.0f/2.6f);
XYZp.z = _powf( (48.0f/52.37f) * XYZ.z, 1.0f/2.6f);
return XYZp;
}

__CONSTANT__ float pq_m1 = 0.1593017578125f;
__CONSTANT__ float pq_m2 = 78.84375f;
__CONSTANT__ float pq_c1 = 0.8359375f;
__CONSTANT__ float pq_c2 = 18.8515625f;
__CONSTANT__ float pq_c3 = 18.6875f;
__CONSTANT__ float pq_C = 10000.0f;

__DEVICE__ inline float ST2084_2_Y( float N )
{
float Np = _powf( N, 1.0f / pq_m2 );
float L = Np - pq_c1;
if ( L < 0.0f )
L = 0.0f;
L = L / ( pq_c2 - pq_c3 * Np );
L = _powf( L, 1.0f / pq_m1 );
return L * pq_C;
}

__DEVICE__ inline float Y_2_ST2084( float C )
{
float L = C / pq_C;
float Lm = _powf( L, pq_m1 );
float N = ( pq_c1 + pq_c2 * Lm ) / ( 1.0f + pq_c3 * Lm );
N = _powf( N, pq_m2 );
return N;
}

__DEVICE__ inline float3 Y_2_ST2084_f3( float3 in)
{
float3 out;
out.x = Y_2_ST2084( in.x); out.y = Y_2_ST2084( in.y); out.z = Y_2_ST2084( in.z);
return out;
}

__DEVICE__ inline float3 ST2084_2_Y_f3( float3 in)
{
float3 out;
out.x = ST2084_2_Y( in.x); out.y = ST2084_2_Y( in.y); out.z = ST2084_2_Y( in.z);
return out;
}

__DEVICE__ inline float3 ST2084_2_HLG_1000nits_f3( float3 PQ) 
{
float3 displayLinear = ST2084_2_Y_f3( PQ);
float Y_d = 0.2627f * displayLinear.x + 0.6780f * displayLinear.y + 0.0593f * displayLinear.z;
const float L_w = 1000.0f;
const float L_b = 0.0f;
const float alpha = (L_w - L_b);
const float beta = L_b;
const float gamma = 1.2f;
float3 sceneLinear;
if (Y_d == 0.0f) { 
sceneLinear.x = 0.0f; sceneLinear.y = 0.0f; sceneLinear.z = 0.0f;        
} else {
sceneLinear.x = _powf( (Y_d - beta) / alpha, (1.0f - gamma) / gamma) * ((displayLinear.x - beta) / alpha);
sceneLinear.y = _powf( (Y_d - beta) / alpha, (1.0f - gamma) / gamma) * ((displayLinear.y - beta) / alpha);
sceneLinear.z = _powf( (Y_d - beta) / alpha, (1.0f - gamma) / gamma) * ((displayLinear.z - beta) / alpha);
}
const float a = 0.17883277f;
const float b = 0.28466892f;
const float c = 0.55991073f;
float3 HLG;
if (sceneLinear.x <= 1.0f / 12.0f) {
HLG.x = _sqrtf(3.0f * sceneLinear.x);
} else {
HLG.x = a * _logf(12.0f * sceneLinear.x-b)+c;
}
if (sceneLinear.y <= 1.0f / 12.0f) {
HLG.y = _sqrtf(3.0f * sceneLinear.y);
} else {
HLG.y = a * _logf(12.0f * sceneLinear.y-b)+c;
}
if (sceneLinear.z <= 1.0f / 12.0f) {
HLG.z = _sqrtf(3.0f * sceneLinear.z);
} else {
HLG.z = a * _logf(12.0f * sceneLinear.z - b) + c;
}
return HLG;
}

__DEVICE__ inline float3 HLG_2_ST2084_1000nits_f3( float3 HLG) 
{
const float a = 0.17883277f;
const float b = 0.28466892f;
const float c = 0.55991073f;
const float L_w = 1000.0f;
const float L_b = 0.0f;
const float alpha = (L_w - L_b);
const float beta = L_b;
const float gamma = 1.2f;
float3 sceneLinear;
if ( HLG.x >= 0.0f && HLG.x <= 0.5f) {
sceneLinear.x = _powf(HLG.x, 2.0f) / 3.0f;
} else {
sceneLinear.x = (_expf((HLG.x - c) / a) + b) / 12.0f;
}        
if ( HLG.y >= 0.0f && HLG.y <= 0.5f) {
sceneLinear.y = _powf(HLG.y, 2.0f) / 3.0f;
} else {
sceneLinear.y = (_expf((HLG.y - c) / a) + b) / 12.0f;
}        
if ( HLG.z >= 0.0f && HLG.z <= 0.5f) {
sceneLinear.z = _powf(HLG.z, 2.0f) / 3.0f;
} else {
sceneLinear.z = (_expf((HLG.z - c) / a) + b) / 12.0f;
}        
float Y_s = 0.2627f * sceneLinear.x + 0.6780f * sceneLinear.y + 0.0593f * sceneLinear.z;
float3 displayLinear;
displayLinear.x = alpha * _powf( Y_s, gamma - 1.0f) * sceneLinear.x + beta;
displayLinear.y = alpha * _powf( Y_s, gamma - 1.0f) * sceneLinear.y + beta;
displayLinear.z = alpha * _powf( Y_s, gamma - 1.0f) * sceneLinear.z + beta;
float3 PQ = Y_2_ST2084_f3( displayLinear);
return PQ;
}

#endif