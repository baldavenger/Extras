#ifndef __ADX_TO_ACES_H_INCLUDED__
#define __ADX_TO_ACES_H_INCLUDED__

#define REF_PT		((7120.0f - 1520.0f) / 8000.0f * (100.0f / 55.0f) - _log10f(0.18f)) * 1.0f

__CONSTANT__ mat3 CDD_TO_CID = 
//{ {0.75573f, 0.05901f, 0.16134f}, {0.22197f, 0.96928f, 0.07406f}, {0.02230f, -0.02829f, 0.76460f} };
{ {0.75573f, 0.22197f, 0.02230f}, {0.05901f, 0.96928f, -0.02829f}, {0.16134f, 0.07406f, 0.76460f} };

__CONSTANT__ mat3 EXP_TO_ACES = 
//{ {0.72286f, 0.11923f, 0.01427f}, {0.12630f, 0.76418f, 0.08213f}, {0.15084f, 0.11659f, 0.90359f} };
{ {0.72286f, 0.12630f, 0.15084f}, {0.11923f, 0.76418f, 0.11659f}, {0.01427f, 0.08213f, 0.90359f} };

__CONSTANT__ float2 LUT_1D[11] = 
{ {-0.19f, -6.0f},
{ 0.01f, -2.721718645f},
{ 0.028f, -2.521718645f},
{ 0.054f, -2.321718645f},
{ 0.095f, -2.121718645f},
{ 0.145f, -1.921718645f},
{ 0.22f, -1.721718645f},
{ 0.3f, -1.521718645f},
{ 0.4f, -1.321718645f},
{ 0.5f, -1.121718645f},
{ 0.6f, -0.926545676714876f} };

__DEVICE__ inline float3 ADX10_to_ACES( float3 ADX10)
{
float3 adx;
adx.x = ADX10.x * 1023.0f;
adx.y = ADX10.y * 1023.0f;
adx.z = ADX10.z * 1023.0f;
float3 cdd = ( adx - 95.0f) / 500.0f;
float3 cid = mult_f3_f33( cdd, CDD_TO_CID);
float3 logE;
if ( cid.x <= 0.6f) logE.x = interpolate1D( LUT_1D, 11, cid.x);
if ( cid.y <= 0.6f) logE.y = interpolate1D( LUT_1D, 11, cid.y);
if ( cid.z <= 0.6f) logE.z = interpolate1D( LUT_1D, 11, cid.z);
if ( cid.x > 0.6f) logE.x = ( 100.0f / 55.0f) * cid.x - REF_PT;
if ( cid.y > 0.6f) logE.y = ( 100.0f / 55.0f) * cid.y - REF_PT;
if ( cid.z > 0.6f) logE.z = ( 100.0f / 55.0f) * cid.z - REF_PT;
float3 exp;
exp.x = _powf( 10.0f, logE.x);
exp.y = _powf( 10.0f, logE.y);
exp.z = _powf( 10.0f, logE.z);
float3 aces = mult_f3_f33( exp, EXP_TO_ACES);
return aces;
}

__DEVICE__ inline float3 ADX16_to_ACES( float3 ADX16)
{
float3 adx;
adx.x = ADX16.x * 65535.0f;
adx.y = ADX16.y * 65535.0f;
adx.z = ADX16.z * 65535.0f;
float3 cdd = ( adx - 1520.0f) / 8000.0f;
float3 cid = mult_f3_f33( cdd, CDD_TO_CID);
float3 logE;
if ( cid.x <= 0.6f) logE.x = interpolate1D( LUT_1D, 11, cid.x);
if ( cid.y <= 0.6f) logE.y = interpolate1D( LUT_1D, 11, cid.y);
if ( cid.z <= 0.6f) logE.z = interpolate1D( LUT_1D, 11, cid.z);
if ( cid.x > 0.6f) logE.x = ( 100.0f / 55.0f) * cid.x - REF_PT;
if ( cid.y > 0.6f) logE.y = ( 100.0f / 55.0f) * cid.y - REF_PT;
if ( cid.z > 0.6f) logE.z = ( 100.0f / 55.0f) * cid.z - REF_PT;
float3 exp;
exp.x = _powf( 10.0f, logE.x);
exp.y = _powf( 10.0f, logE.y);
exp.z = _powf( 10.0f, logE.z);
float3 aces = mult_f3_f33( exp, EXP_TO_ACES);
return aces;
}

#endif