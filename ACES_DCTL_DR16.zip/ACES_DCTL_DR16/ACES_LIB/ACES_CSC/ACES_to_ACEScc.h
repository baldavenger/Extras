#ifndef __ACES_TO_ACESCC_H_INCLUDED__
#define __ACES_TO_ACESCC_H_INCLUDED__

__DEVICE__ inline float lin_to_ACEScc( float in)
{
if (in <= 0)
return -0.3584474886f; 
else if (in < _powf(2.0f, -15.0f))
return (_log2f( _powf(2.0f, -16.0f) + in * 0.5f) + 9.72f) / 17.52f;
else
return (_log2f(in) + 9.72f) / 17.52f;
}

__DEVICE__ inline float3 ACES_to_ACEScc( float3 ACES)
{
ACES = max_f3_f( ACES, 0.0f);
float3 lin_AP1 = mult_f3_f33( ACES, AP0_2_AP1_MAT);
float3 out;
out.x = lin_to_ACEScc( lin_AP1.x);
out.y = lin_to_ACEScc( lin_AP1.y);
out.z = lin_to_ACEScc( lin_AP1.z);

return out;
}

#endif