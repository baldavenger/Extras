#ifndef __IDT_REC709_SRGB_H_INCLUDED__
#define __IDT_REC709_SRGB_H_INCLUDED__

#include "../ACES_ODT_Common.h"
#include "../ACES_SSTS.h"
#include "../ACES_OutputTransforms.h"

__DEVICE__ inline float3 InvODT_Rec709( float3 outputCV) {
mat3 DISPLAY_PRI_2_XYZ_MAT = RGBtoXYZ(REC709_PRI);
float DISPGAMMA = 2.4f; 
float L_W = 1.0f;
float L_B = 0.0f;
float3 linearCV = bt1886_f_f3( outputCV, DISPGAMMA, L_W, L_B);
float3 XYZ = mult_f3_f33( linearCV, DISPLAY_PRI_2_XYZ_MAT);
XYZ = mult_f3_f33( XYZ, invert_f33( D60_2_D65_CAT));
linearCV = mult_f3_f33( XYZ, XYZ_2_AP1_MAT);
linearCV = mult_f3_f33( linearCV, invert_f33( ODT_SAT_MAT));
float3 rgbPre = linCV_2_Y_f3( linearCV, CINEMA_WHITE, CINEMA_BLACK);
float3 rgbPost;
rgbPost = segmented_spline_c9_rev_f3( rgbPre);
float3 oces = mult_f3_f33( rgbPost, AP1_2_AP0_MAT);
return oces;
}

__DEVICE__ inline float3 InvODT_sRGB( float3 outputCV) {
mat3 DISPLAY_PRI_2_XYZ_MAT = RGBtoXYZ(REC709_PRI);
float DISPGAMMA = 2.4f; 
float OFFSET = 0.055f;
float3 linearCV;
linearCV = moncurve_f_f3( outputCV, DISPGAMMA, OFFSET);
float3 XYZ = mult_f3_f33( linearCV, DISPLAY_PRI_2_XYZ_MAT);
XYZ = mult_f3_f33( XYZ, invert_f33( D60_2_D65_CAT));
linearCV = mult_f3_f33( XYZ, XYZ_2_AP1_MAT);
linearCV = mult_f3_f33( linearCV, invert_f33( ODT_SAT_MAT));
float3 rgbPre = linCV_2_Y_f3( linearCV, CINEMA_WHITE, CINEMA_BLACK);
float3 rgbPost;
rgbPost = segmented_spline_c9_rev_f3( rgbPre);
float3 oces = mult_f3_f33( rgbPost, AP1_2_AP0_MAT);
return oces;
}

__DEVICE__ inline float3 IDT_sRGB( float3 rgb) {
float3 aces;
aces = InvODT_sRGB(rgb);
aces = segmented_spline_c5_rev_f3( aces);
aces = max_f3_f(aces, 0.0f);
return aces;
}

__DEVICE__ inline float3 IDT_rec709( float3 rgb) {
float3 aces;
aces = InvODT_Rec709(rgb);
aces = segmented_spline_c5_rev_f3( aces);
aces = max_f3_f(aces, 0.0f);
return aces;
}

#endif