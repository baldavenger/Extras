#ifndef __IDT_CANON_C500_DCI_P3_A_TNG_H_INCLUDED__
#define __IDT_CANON_C500_DCI_P3_A_TNG_H_INCLUDED__

__DEVICE__ inline float3 IDT_Canon_C500_DCI_P3_A_Tng( float3 In)
{
float3 CLogIRE;
CLogIRE.x = (In.x * 1023.0f - 64.0f) / 876.0f;
CLogIRE.y = (In.y * 1023.0f - 64.0f) / 876.0f;
CLogIRE.z = (In.z * 1023.0f - 64.0f) / 876.0f;

float3 lin;
lin.x = 0.9f * CanonLog_to_linear( CLogIRE.x);
lin.y = 0.9f * CanonLog_to_linear( CLogIRE.y);
lin.z = 0.9f * CanonLog_to_linear( CLogIRE.z);

float3 aces;
aces.x =  0.650279125f * lin.x + 0.253880169f * lin.y + 0.095840706f * lin.z;
aces.y = -0.026137986f * lin.x + 1.017900530f * lin.y + 0.008237456f * lin.z;
aces.z =  0.007757558f * lin.x - 0.063081669f * lin.y + 1.055324110f * lin.z;

return aces;
}

#endif