#ifndef __IDT_SONY_SLOG3_SGAMUT3CINE_H_INCLUDED__
#define __IDT_SONY_SLOG3_SGAMUT3CINE_H_INCLUDED__

__DEVICE__ inline float3 IDT_Sony_SLog3_SGamut3Cine( float3 SLog3)
{
mat3 matrixCoef = { {0.6387886672f, -0.0039159060f, -0.0299072021f}, {0.2723514337f, 1.0880732309f, -0.0264325799f}, {0.0888598991f, -0.0841573249f, 1.0563397820f} };

float3 linear;
linear.x = SLog3_to_linear( SLog3.x );
linear.y = SLog3_to_linear( SLog3.y );
linear.z = SLog3_to_linear( SLog3.z );

float3 aces = mult_f3_f33( linear, matrixCoef );

return aces;
}

#endif