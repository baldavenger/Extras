#ifndef __ACES_LMT_COMMON_H_INCLUDED__
#define __ACES_LMT_COMMON_H_INCLUDED__

#define RGB_2_YAB_MAT			make_mat3(make_float3(1.0f/3.0f, 1.0f/2.0f, 0.0f), make_float3(1.0f/3.0f, -1.0f/4.0f, sqrt3over4), make_float3(1.0f/3.0f, -1.0f/4.0f, -sqrt3over4))
#define REC709_2_XYZ_MAT		RGBtoXYZ( REC709_PRI)   
#define REC709_RGB2Y			make_float3(REC709_2_XYZ_MAT.c0.y, REC709_2_XYZ_MAT.c1.y, REC709_2_XYZ_MAT.c2.y)

__CONSTANT__ float X_BRK = 0.0078125f;
__CONSTANT__ float Y_BRK = 0.155251141552511f;
__CONSTANT__ float A = 10.5402377416545f;
__CONSTANT__ float B = 0.0729055341958355f;
__CONSTANT__ float sqrt3over4 = 0.433012701892219f;

__DEVICE__ inline float lin_to_ACEScct( float in)
{
if (in <= X_BRK)
return A * in + B;
else
return (_log2f(in) + 9.72f) / 17.52f;
}

__DEVICE__ inline float ACEScct_to_lin( float in)
{
if (in > Y_BRK)
return _powf( 2.0f, in * 17.52f - 9.72f);
else
return (in - B) / A;
}

__DEVICE__ inline float3 ACES_to_ACEScct( float3 in)
{
float3 ap1_lin = mult_f3_f33( in, AP0_2_AP1_MAT);
float3 acescct;
acescct.x = lin_to_ACEScct( ap1_lin.x); acescct.y = lin_to_ACEScct( ap1_lin.y); acescct.z = lin_to_ACEScct( ap1_lin.z);
return acescct;
}

__DEVICE__ inline float3 ACEScct_to_ACES( float3 in)
{
float3 ap1_lin;
ap1_lin.x = ACEScct_to_lin( in.x); ap1_lin.y = ACEScct_to_lin( in.y); ap1_lin.z = ACEScct_to_lin( in.z);
return mult_f3_f33( ap1_lin, AP1_2_AP0_MAT);
}

__DEVICE__ inline float3 ASCCDL_inACEScct
(
float3 acesIn, 
float3 SLOPE = make_float3(1.0f, 1.0f, 1.0f),
float3 OFFSET = make_float3(0.0f, 0.0f, 0.0f),
float3 POWER = make_float3(1.0f, 1.0f, 1.0f),
float SAT = 1.0f
)
{
float3 acescct = ACES_to_ACEScct( acesIn);
acescct.x = _powf( _clampf( (acescct.x * SLOPE.x) + OFFSET.x, 0.0f, 1.0f), 1.0f / POWER.x);
acescct.y = _powf( _clampf( (acescct.y * SLOPE.y) + OFFSET.y, 0.0f, 1.0f), 1.0f / POWER.y);
acescct.z = _powf( _clampf( (acescct.z * SLOPE.z) + OFFSET.z, 0.0f, 1.0f), 1.0f / POWER.z);
float luma = 0.2126f * acescct.x + 0.7152f * acescct.y + 0.0722f * acescct.z;
float satClamp = _fmaxf(SAT, 0.0f);
acescct.x = luma + satClamp * (acescct.x - luma);
acescct.y = luma + satClamp * (acescct.y - luma);
acescct.z = luma + satClamp * (acescct.z - luma);
return ACEScct_to_ACES( acescct);
}

__DEVICE__ inline float3 gamma_adjust_linear( float3 rgbIn, float GAMMA, float PIVOT = 0.18f)
{
const float SCALAR = PIVOT / _powf( PIVOT, GAMMA);
float3 rgbOut = rgbIn;
if (rgbIn.x > 0.0f) rgbOut.x = _powf( rgbIn.x, GAMMA) * SCALAR;
if (rgbIn.y > 0.0f) rgbOut.y = _powf( rgbIn.y, GAMMA) * SCALAR;
if (rgbIn.z > 0.0f) rgbOut.z = _powf( rgbIn.z, GAMMA) * SCALAR;
return rgbOut;
}
	  
__DEVICE__ inline float3 sat_adjust( float3 rgbIn, float SAT_FACTOR, float3 RGB2Y = REC709_RGB2Y)
{
const mat3 SAT_MAT = calc_sat_adjust_matrix( SAT_FACTOR, RGB2Y);    
return mult_f3_f33( rgbIn, SAT_MAT);
}

__DEVICE__ inline float3 rgb_2_yab( float3 rgb)
{
float3 yab = mult_f3_f33( rgb, RGB_2_YAB_MAT);
return yab;
}

__DEVICE__ inline float3 yab_2_rgb( float3 yab)
{
float3 rgb = mult_f3_f33( yab, invert_f33(RGB_2_YAB_MAT));
return rgb;
}

__DEVICE__ float3 yab_2_ych(float3 yab)
{
float3 ych = yab;
float yo = yab.y * yab.y + yab.z * yab.z;
ych.y = _sqrtf(yo);
ych.z = _atan2f(yab.z, yab.y) * (180.0f / M_PI);
if (ych.z < 0.0f) ych.z += 360.0f;
return ych;
}

__DEVICE__ inline float3 ych_2_yab( float3 ych ) 
{
float3 yab;
yab.x = ych.x;
float h = ych.z * (M_PI / 180.0f);
yab.y = ych.y * _cosf(h);
yab.z = ych.y * _sinf(h);
return yab;
}

__DEVICE__ inline float3 rgb_2_ych( float3 rgb) 
{
return yab_2_ych( rgb_2_yab( rgb));
}

__DEVICE__ inline float3 ych_2_rgb( float3 ych) 
{
return yab_2_rgb( ych_2_yab( ych));
}

__DEVICE__ inline float3 scale_C_at_H( float3 rgb, float centerH, float widthH, float percentC)
{
float3 new_rgb = rgb;
float3 ych = rgb_2_ych( rgb);
if (ych.y > 0.0f) {
float centeredHue = center_hue( ych.z, centerH);
float f_H = cubic_basis_shaper( centeredHue, widthH);
if (f_H > 0.0f) {
float3 new_ych = ych;
new_ych.y = ych.y * (f_H * (percentC - 1.0f) + 1.0f);
new_rgb = ych_2_rgb( new_ych);
} else { 
new_rgb = rgb; 
}}
return new_rgb;
}

__DEVICE__ inline float3 rotate_H_in_H( float3 rgb, float centerH, float widthH, float degreesShift)
{
float3 ych = rgb_2_ych( rgb);
float3 new_ych = ych;
float centeredHue = center_hue( ych.z, centerH);
float f_H = cubic_basis_shaper( centeredHue, widthH);
float old_hue = centeredHue;
float new_hue = centeredHue + degreesShift;
float2 table[2] = { {0.0f, old_hue}, {1.0f, new_hue} };
float blended_hue = interpolate1D( table, 2, f_H);
if (f_H > 0.0f) new_ych.z = uncenter_hue(blended_hue, centerH);
return ych_2_rgb( new_ych);
}

__DEVICE__ inline float3 scale_C( float3 rgb, float percentC)
{
float3 ych = rgb_2_ych( rgb);
ych.y = ych.y * percentC;
return ych_2_rgb( ych);
}

__DEVICE__ inline float3 overlay_f3( float3 a, float3 b)
{
const float LUMA_CUT = lin_to_ACEScct( 0.5f); 
float luma = 0.2126f * a.x + 0.7152f * a.y + 0.0722f * a.z;
float3 out;
if (luma < LUMA_CUT) {
out.x = 2.0f * a.x * b.x;
out.y = 2.0f * a.y * b.y;
out.z = 2.0f * a.z * b.z;
} else {
out.x = 1.0f - (2.0f * (1.0f - a.x) * (1.0f - b.x));
out.y = 1.0f - (2.0f * (1.0f - a.y) * (1.0f - b.y));
out.z = 1.0f - (2.0f * (1.0f - a.z) * (1.0f - b.z));
}
return out;
}

#endif