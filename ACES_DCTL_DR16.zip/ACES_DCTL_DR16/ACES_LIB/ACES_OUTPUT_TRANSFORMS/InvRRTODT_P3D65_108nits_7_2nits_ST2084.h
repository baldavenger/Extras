#ifndef __INVRRTODT_P3D65_108NITS_7_2NITS_ST2084_H_INCLUDED__
#define __INVRRTODT_P3D65_108NITS_7_2NITS_ST2084_H_INCLUDED__

__DEVICE__ inline float3 InvRRTODT_P3D65_108nits_7_2nits_ST2084( float3 aces)
{
float Y_MIN = 0.0001f;
float Y_MID = 7.2f;
float Y_MAX = 108.0f;
Chromaticities DISPLAY_PRI = P3D65_PRI;
Chromaticities LIMITING_PRI = P3D65_PRI;
int EOTF = 0;
int SURROUND = 0;
bool STRETCH_BLACK = true;
bool D60_SIM = false;                       
bool LEGAL_RANGE = false;

float3 cv = invOutputTransform( aces, Y_MIN, Y_MID, Y_MAX, DISPLAY_PRI,
LIMITING_PRI, EOTF, SURROUND, STRETCH_BLACK, D60_SIM, LEGAL_RANGE );

return cv;
}

#endif