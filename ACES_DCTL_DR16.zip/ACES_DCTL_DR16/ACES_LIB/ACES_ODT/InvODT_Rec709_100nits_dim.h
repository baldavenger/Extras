#ifndef __INVODT_REC709_100NITS_DIM_H_INCLUDED__
#define __INVODT_REC709_100NITS_DIM_H_INCLUDED__

__DEVICE__ inline float3 InvODT_Rec709_100nits_dim( float3 outputCV)
{  
Chromaticities DISPLAY_PRI = REC709_PRI;
mat3 DISPLAY_PRI_2_XYZ_MAT = RGBtoXYZ(DISPLAY_PRI);
float DISPGAMMA = 2.4f;
float L_W = 1.0f;
float L_B = 0.0f;
bool legalRange = false;

if (legalRange) {
outputCV = smpteRange_to_fullRange_f3( outputCV);
}

float3 linearCV;
linearCV.x = bt1886_f( outputCV.x, DISPGAMMA, L_W, L_B);
linearCV.y = bt1886_f( outputCV.y, DISPGAMMA, L_W, L_B);
linearCV.z = bt1886_f( outputCV.z, DISPGAMMA, L_W, L_B);

float3 XYZ = mult_f3_f33( linearCV, DISPLAY_PRI_2_XYZ_MAT);
XYZ = mult_f3_f33( XYZ, invert_f33( D60_2_D65_CAT));
linearCV = mult_f3_f33( XYZ, XYZ_2_AP1_MAT);
linearCV = mult_f3_f33( linearCV, invert_f33( ODT_SAT_MAT));
linearCV = dimSurround_to_darkSurround( linearCV);

float3 rgbPre;
rgbPre.x = linCV_2_Y( linearCV.x, CINEMA_WHITE, CINEMA_BLACK);
rgbPre.y = linCV_2_Y( linearCV.y, CINEMA_WHITE, CINEMA_BLACK);
rgbPre.z = linCV_2_Y( linearCV.z, CINEMA_WHITE, CINEMA_BLACK);

float3 rgbPost;
rgbPost.x = segmented_spline_c9_rev( rgbPre.x, ODT_48nits());
rgbPost.y = segmented_spline_c9_rev( rgbPre.y, ODT_48nits());
rgbPost.z = segmented_spline_c9_rev( rgbPre.z, ODT_48nits());

float3 oces = mult_f3_f33( rgbPost, AP1_2_AP0_MAT);

return oces;
}


#endif