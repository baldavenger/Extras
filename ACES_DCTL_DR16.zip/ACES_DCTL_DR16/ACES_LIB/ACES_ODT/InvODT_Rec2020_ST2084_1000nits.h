#ifndef __INVODT_REC2020_ST2084_1000NITS_H_INCLUDED__
#define __INVODT_REC2020_ST2084_1000NITS_H_INCLUDED__

__DEVICE__ inline float3 InvODT_Rec2020_ST2084_1000nits( float3 outputCV)
{  
Chromaticities DISPLAY_PRI = REC2020_PRI;
mat3 DISPLAY_PRI_2_XYZ_MAT = RGBtoXYZ(DISPLAY_PRI);

float3 rgb = ST2084_2_Y_f3( outputCV);
float3 XYZ = mult_f3_f33( rgb, DISPLAY_PRI_2_XYZ_MAT);
XYZ = mult_f3_f33( XYZ, invert_f33( D60_2_D65_CAT));

float3 rgbPre = mult_f3_f33( XYZ, XYZ_2_AP1_MAT);
rgbPre = add_f_f3( _pow10f(-4.4550166483f), rgbPre);

float3 rgbPost;
rgbPost.x = segmented_spline_c9_rev( rgbPre.x, ODT_1000nits());
rgbPost.y = segmented_spline_c9_rev( rgbPre.y, ODT_1000nits());
rgbPost.z = segmented_spline_c9_rev( rgbPre.z, ODT_1000nits());

float3 oces = mult_f3_f33( rgbPost, AP1_2_AP0_MAT);

return oces;
}

#endif