#ifndef __ODT_P3D65_REC709LIMITED_48NITS_H_INCLUDED__
#define __ODT_P3D65_REC709LIMITED_48NITS_H_INCLUDED__

__DEVICE__ inline float3 ODT_P3D65_Rec709limited_48nits( float3 oces)
{
const Chromaticities DISPLAY_PRI = P3D65_PRI;
const mat3 XYZ_2_DISPLAY_PRI_MAT = XYZtoRGB(DISPLAY_PRI);
const Chromaticities LIMITING_PRI = REC709_PRI;
const float DISPGAMMA = 2.6f;

float3 rgbPre = mult_f3_f33( oces, AP0_2_AP1_MAT);
float3 rgbPost;
rgbPost.x = segmented_spline_c9_fwd( rgbPre.x, ODT_48nits());
rgbPost.y = segmented_spline_c9_fwd( rgbPre.y, ODT_48nits());
rgbPost.z = segmented_spline_c9_fwd( rgbPre.z, ODT_48nits());

float3 linearCV;
linearCV.x = Y_2_linCV( rgbPost.x, CINEMA_WHITE, CINEMA_BLACK);
linearCV.y = Y_2_linCV( rgbPost.y, CINEMA_WHITE, CINEMA_BLACK);
linearCV.z = Y_2_linCV( rgbPost.z, CINEMA_WHITE, CINEMA_BLACK);

float3 XYZ = mult_f3_f33( linearCV, AP1_2_XYZ_MAT);
XYZ = mult_f3_f33( XYZ, D60_2_D65_CAT);
XYZ = limit_to_primaries( XYZ, LIMITING_PRI);
linearCV = mult_f3_f33( XYZ, XYZ_2_DISPLAY_PRI_MAT);
linearCV = clamp_f3( linearCV, 0.0f, 1.0f);
float3 outputCV = pow_f3( linearCV, 1.0f / DISPGAMMA);

return outputCV;
}

#endif