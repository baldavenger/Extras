#include "MatrixPlugin.h"

#include <cstring>
#include <cmath>
#include <stdio.h>
using std::string;
#include <string> 
#include <fstream>

#include "ofxsImageEffect.h"
#include "ofxsMultiThread.h"
#include "ofxsProcessing.h"
#include "ofxsLog.h"

#ifdef __APPLE__
#define kPluginScript "/Library/Application Support/Blackmagic Design/DaVinci Resolve/LUT"
#elif defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64)
#define kPluginScript "\\ProgramData\\Blackmagic Design\\DaVinci Resolve\\Support\\LUT"
#else
#define kPluginScript "/home/resolve/LUT"
#endif

#define kPluginName "Matrix"
#define kPluginGrouping "OpenFX Yo"
#define kPluginDescription \
"------------------------------------------------------------------------------------------------------------------ \n" \
"Matrix: 3x3 Matrix with additional RGB Mixer controls, Channel V Channel controls, and \n" \
"Inverse, Luma, and Saturation preserve options."

#define kPluginIdentifier "OpenFX.Yo.Matrix"
#define kPluginVersionMajor 2
#define kPluginVersionMinor 2

#define kSupportsTiles false
#define kSupportsMultiResolution false
#define kSupportsMultipleClipPARs false

////////////////////////////////////////////////////////////////////////////////

namespace {
    struct RGBValues {
        double r,g,b;
        RGBValues(double v) : r(v), g(v), b(v) {}
        RGBValues() : r(0), g(0), b(0) {}
    };
}


class ImageScaler : public OFX::ImageProcessor
{
public:
    explicit ImageScaler(OFX::ImageEffect& p_Instance);

    virtual void processImagesCUDA();
    virtual void processImagesOpenCL();
    virtual void multiThreadProcessImages(OfxRectI p_ProcWindow);

    void setSrcImg(OFX::Image* p_SrcImg);
    void setScales(float p_ScaleRR, float p_ScaleRG, float p_ScaleRB, float p_ScaleGR, float p_ScaleGG, float p_ScaleGB,
		float p_ScaleBR, float p_ScaleBG, float p_ScaleBB, float p_Luma, float p_Sat);

private:
    OFX::Image* _srcImg;
    float _scales[9];
	float _luma[1];
	float _sat[1];
};

ImageScaler::ImageScaler(OFX::ImageEffect& p_Instance)
    : OFX::ImageProcessor(p_Instance)
{
}

extern void RunCudaKernel(int p_Width, int p_Height, float* p_Matrix, float* p_Luma, float* p_Sat, const float* p_Input, float* p_Output);

void ImageScaler::processImagesCUDA()
{
    const OfxRectI& bounds = _srcImg->getBounds();
    const int width = bounds.x2 - bounds.x1;
    const int height = bounds.y2 - bounds.y1;

    float* input = static_cast<float*>(_srcImg->getPixelData());
    float* output = static_cast<float*>(_dstImg->getPixelData());

    RunCudaKernel(width, height, _scales, _luma, _sat, input, output);
}

extern void RunOpenCLKernel(void* p_CmdQ, int p_Width, int p_Height, float* p_Matrix, float* p_Luma, float* p_Sat, const float* p_Input, float* p_Output);

void ImageScaler::processImagesOpenCL()
{
    const OfxRectI& bounds = _srcImg->getBounds();
    const int width = bounds.x2 - bounds.x1;
    const int height = bounds.y2 - bounds.y1;

    float* input = static_cast<float*>(_srcImg->getPixelData());
    float* output = static_cast<float*>(_dstImg->getPixelData());

    RunOpenCLKernel(_pOpenCLCmdQ, width, height, _scales, _luma, _sat, input, output);
}

void ImageScaler::multiThreadProcessImages(OfxRectI p_ProcWindow)
{
    for (int y = p_ProcWindow.y1; y < p_ProcWindow.y2; ++y)
    {
        if (_effect.abort()) break;

        float* dstPix = static_cast<float*>(_dstImg->getPixelAddress(p_ProcWindow.x1, y));

        for (int x = p_ProcWindow.x1; x < p_ProcWindow.x2; ++x)
        {
            float* srcPix = static_cast<float*>(_srcImg ? _srcImg->getPixelAddress(x, y) : 0);

            // do we have a source image to scale up
            if (srcPix)
            {
            	
            	float mn1 = fmin(srcPix[0], fmin(srcPix[1], srcPix[2]));    
				float Mx1 = fmax(srcPix[0], fmax(srcPix[1], srcPix[2]));    
				float del_Mx1 = Mx1 - mn1;
				float L1 = (Mx1 + mn1) / 2.0f;
				float Sat1 = del_Mx1 == 0.0f ? 0.0f : L1 < 0.5f ? del_Mx1 / (Mx1 + mn1) : del_Mx1 / (2.0f - Mx1 - mn1);
            	
   				float Y1 =  srcPix[0] * 0.299f + srcPix[1] * 0.587f + srcPix[2] * 0.114f;
            	
            	float red = (srcPix[0] * _scales[0]) + (srcPix[1] * _scales[1]) + (srcPix[2] * _scales[2]);
                float green = (srcPix[0] * _scales[3]) + (srcPix[1] * _scales[4]) + (srcPix[2] * _scales[5]);
                float blue = (srcPix[0] * _scales[6]) + (srcPix[1] * _scales[7]) + (srcPix[2] * _scales[8]);
            	
            	float Y2 =  red * 0.299f + green * 0.587f + blue * 0.114f;
   				float U2 = red * -0.147f - green * 0.289f + blue * 0.436f;
   				float V2 =  red * 0.615f - green * 0.515f - blue * 0.1f;
   				
				float R1 = (_luma[0] != 1.0f ? Y2 : Y1) + 1.140f * V2;
  				float G1 = (_luma[0] != 1.0f ? Y2 : Y1) - 0.395f * U2 - 0.581f * V2;
   				float B1 = (_luma[0] != 1.0f ? Y2 : Y1) + 2.032f * U2;
   				
   				float mn2 = fmin(R1, fmin(G1, B1));    
				float Mx2 = fmax(R1, fmax(G1, B1));    
				float del_Mx2 = Mx2 - mn2;
				float L2 = (Mx2 + mn2) / 2.0f;
				//float Sat2 = del_Mx2 == 0.0f ? 0.0f : L2 < 0.5f ? del_Mx2 / (Mx2 + mn2) : del_Mx2 / (2.0f - Mx2 - mn2);
				
				float del_R = ((Mx2 - R1) / 6.0f + del_Mx2 / 2.0f) / del_Mx2;
    			float del_G = ((Mx2 - G1) / 6.0f + del_Mx2 / 2.0f) / del_Mx2;
    			float del_B = ((Mx2 - B1) / 6.0f + del_Mx2 / 2.0f) / del_Mx2;
   
    			float h = del_Mx2 == 0.0f ? 0.0f : R1 == Mx2 ? del_B - del_G : G1 == Mx2 ? 1.0f / 3.0f + 
    			del_R - del_B : 2.0f / 3.0f + del_G - del_R;

    			float H = h < 0.0f ? h + 1.0f : h > 1.0f ? h - 1.0f : h;
    			
    			float S = Sat1;
    			
    			float Q = L2 < 0.5f ? L2 * (1.0f + S) : L2 + S - L2 * S;
				float P = 2.0f * L2 - Q;

				float RH = H + 1.0f / 3.0f < 0.0f ? H + 1.0f / 3.0f + 1.0f :
				H + 1.0f / 3.0f > 1.0f ? H + 1.0f / 3.0f - 1.0f : H + 1.0f / 3.0f;
	
				float RR = RH < 1.0f / 6.0f ? P + (Q - P) * 6.0f * RH : 
				RH < 1.0f / 2.0f ? Q : RH < 2.0f / 3.0f ? P + (Q - P) * (2.0f / 3.0f - RH) * 6.0f : P;

				float GH = H < 0.0f ? H + 1.0f : H > 1.0f ? H - 1.0f : H;

				float GG = GH < 1.0f / 6.0f ? P + (Q - P) * 6.0f * GH :
				GH < 1.0f / 2.0f ? Q : GH < 2.0f / 3.0f ? P + (Q - P) * (2.0f / 3.0f - GH) * 6.0f : P;

				float BH = H - 1.0f / 3.0f < 0.0f ? H - 1.0f / 3.0f + 1.0f :
				H - 1.0f / 3.0f > 1.0f ? H - 1.0f / 3.0f - 1.0f : H - 1.0f / 3.0f;
	
				float BB = BH < 1.0f / 6.0f ? P + (Q - P) * 6.0f * BH :
				BH < 1.0f / 2.0f ? Q : BH < 2.0f / 3.0f ? P + (Q - P) * (2.0f / 3.0f - BH) * 6.0f : P;
	
	
				float R = _sat[0] == 1.0f ? (S == 0.0f ? L2 : RR) : R1;
				float G = _sat[0] == 1.0f ? (S == 0.0f ? L2 : GG) : G1;
				float B = _sat[0] == 1.0f ? (S == 0.0f ? L2 : BB) : B1;
   				            	
                dstPix[0] = R;
				dstPix[1] = G;
				dstPix[2] = B;
                dstPix[3] = srcPix[3];
                
            }
            else
            {
                // no src pixel here, be black and transparent
                for (int c = 0; c < 4; ++c)
                {
                    dstPix[c] = 0;
                }
            }

            // increment the dst pixel
            dstPix += 4;
        }
    }
}

void ImageScaler::setSrcImg(OFX::Image* p_SrcImg)
{
    _srcImg = p_SrcImg;
}

void ImageScaler::setScales(float p_ScaleRR, float p_ScaleRG, float p_ScaleRB, float p_ScaleGR, float p_ScaleGG, float p_ScaleGB,
	float p_ScaleBR, float p_ScaleBG, float p_ScaleBB, float p_Luma, float p_Sat)
{
    _scales[0] = p_ScaleRR;
    _scales[1] = p_ScaleRG;
    _scales[2] = p_ScaleRB;
    _scales[3] = p_ScaleGR;
    _scales[4] = p_ScaleGG;
    _scales[5] = p_ScaleGB;
    _scales[6] = p_ScaleBR;
    _scales[7] = p_ScaleBG;
    _scales[8] = p_ScaleBB;
    _luma[0] = p_Luma;
    _sat[0] = p_Sat;
}

////////////////////////////////////////////////////////////////////////////////
/** @brief The plugin that does our work */
class MatrixPlugin : public OFX::ImageEffect
{
public:
    explicit MatrixPlugin(OfxImageEffectHandle p_Handle);

    /* Override the render */
    virtual void render(const OFX::RenderArguments& p_Args);

    /* Override is identity */
    virtual bool isIdentity(const OFX::IsIdentityArguments& p_Args, OFX::Clip*& p_IdentityClip, double& p_IdentityTime);
    
    /* Override changedParam */
    virtual void changedParam(const OFX::InstanceChangedArgs& p_Args, const std::string& p_ParamName);

    /* Set up and run a processor */
    void setupAndProcess(ImageScaler &p_ImageScaler, const OFX::RenderArguments& p_Args);

private:
    // Does not own the following pointers
    OFX::Clip* m_DstClip;
    OFX::Clip* m_SrcClip;

    OFX::Double3DParam* m_ScaleR;
    OFX::Double3DParam* m_ScaleG;
    OFX::Double3DParam* m_ScaleB;
    OFX::BooleanParam* m_Luma;
    OFX::BooleanParam* m_Sat;
    OFX::DoubleParam* m_RedRed;
    OFX::DoubleParam* m_RedGreen;
    OFX::DoubleParam* m_RedBlue;
    OFX::DoubleParam* m_GreenRed;
    OFX::DoubleParam* m_GreenGreen;
    OFX::DoubleParam* m_GreenBlue;
    OFX::DoubleParam* m_BlueRed;
    OFX::DoubleParam* m_BlueGreen;
    OFX::DoubleParam* m_BlueBlue;
    OFX::DoubleParam* m_RedvGreen;
    OFX::DoubleParam* m_RedvBlue;
    OFX::DoubleParam* m_RedvGreenBlue;
    OFX::DoubleParam* m_GreenvRed;
    OFX::DoubleParam* m_GreenvBlue;
    OFX::DoubleParam* m_GreenvRedBlue;
    OFX::DoubleParam* m_BluevRed;
    OFX::DoubleParam* m_BluevGreen;
    OFX::DoubleParam* m_BluevRedGreen;
    OFX::DoubleParam* m_RedVGG;
    OFX::DoubleParam* m_GreenVBB;
    OFX::DoubleParam* m_BlueVRR;
    OFX::DoubleParam* m_Cyan;
    OFX::DoubleParam* m_Magenta;
    OFX::DoubleParam* m_Yellow;
    OFX::DoubleParam* m_Temp;
    OFX::DoubleParam* m_Tint;
    OFX::StringParam* m_Name;
    OFX::PushButtonParam* m_Invert;
    OFX::PushButtonParam* m_Info;
    OFX::StringParam* m_Path;
	OFX::PushButtonParam* m_Button1;
	OFX::PushButtonParam* m_Button2;
    
};

MatrixPlugin::MatrixPlugin(OfxImageEffectHandle p_Handle)
    : ImageEffect(p_Handle)
{
    m_DstClip = fetchClip(kOfxImageEffectOutputClipName);
    m_SrcClip = fetchClip(kOfxImageEffectSimpleSourceClipName);

    m_ScaleR = fetchDouble3DParam("paramR");
    m_ScaleG = fetchDouble3DParam("paramG");
    m_ScaleB = fetchDouble3DParam("paramB");
    m_Luma = fetchBooleanParam("luma");
    m_Sat = fetchBooleanParam("sat");
    m_RedRed = fetchDoubleParam("scaleRR");
    m_RedGreen = fetchDoubleParam("scaleRG");
    m_RedBlue = fetchDoubleParam("scaleRB");
    m_GreenRed = fetchDoubleParam("scaleGR");
    m_GreenGreen = fetchDoubleParam("scaleGG");
    m_GreenBlue = fetchDoubleParam("scaleGB");
    m_BlueRed = fetchDoubleParam("scaleBR");
    m_BlueGreen = fetchDoubleParam("scaleBG");
    m_BlueBlue = fetchDoubleParam("scaleBB");
    m_RedvGreen = fetchDoubleParam("scaleRvG");
    m_RedvBlue = fetchDoubleParam("scaleRvB");
    m_RedvGreenBlue = fetchDoubleParam("scaleRvGB");
    m_GreenvRed = fetchDoubleParam("scaleGvR");
    m_GreenvBlue = fetchDoubleParam("scaleGvB");
    m_GreenvRedBlue = fetchDoubleParam("scaleGvRB");
    m_BluevRed = fetchDoubleParam("scaleBvR");
    m_BluevGreen = fetchDoubleParam("scaleBvG");
    m_BluevRedGreen = fetchDoubleParam("scaleBvRG");
    m_RedVGG = fetchDoubleParam("scaleRvGG");
    m_GreenVBB = fetchDoubleParam("scaleGvBB");
    m_BlueVRR = fetchDoubleParam("scaleBvRR");
    m_Cyan = fetchDoubleParam("scaleC");
    m_Magenta = fetchDoubleParam("scaleM");
    m_Yellow = fetchDoubleParam("scaleY");
    m_Temp = fetchDoubleParam("scaleTemp");
    m_Tint = fetchDoubleParam("scaleTint");
    m_Name = fetchStringParam("name");
    m_Invert = fetchPushButtonParam("invert");
    m_Info = fetchPushButtonParam("info");
    m_Path = fetchStringParam("path");
	m_Button1 = fetchPushButtonParam("button1");
	m_Button2 = fetchPushButtonParam("button2");
   
}

void MatrixPlugin::render(const OFX::RenderArguments& p_Args)
{
    if ((m_DstClip->getPixelDepth() == OFX::eBitDepthFloat) && (m_DstClip->getPixelComponents() == OFX::ePixelComponentRGBA))
    {
        ImageScaler imageScaler(*this);
        setupAndProcess(imageScaler, p_Args);
    }
    else
    {
        OFX::throwSuiteStatusException(kOfxStatErrUnsupported);
    }
}

bool MatrixPlugin::isIdentity(const OFX::IsIdentityArguments& p_Args, OFX::Clip*& p_IdentityClip, double& p_IdentityTime)
{

    
    RGBValues rScale;
    m_ScaleR->getValueAtTime(p_Args.time, rScale.r, rScale.g, rScale.b);
    double rrScale = rScale.r;
    double rgScale = rScale.g;
    double rbScale = rScale.b;
    
    RGBValues gScale;
    m_ScaleG->getValueAtTime(p_Args.time, gScale.r, gScale.g, gScale.b);
    double grScale = gScale.r;
    double ggScale = gScale.g;
    double gbScale = gScale.b;
    
    RGBValues bScale;
    m_ScaleB->getValueAtTime(p_Args.time, bScale.r, bScale.g, bScale.b);
    double brScale = bScale.r;
    double bgScale = bScale.g;
    double bbScale = bScale.b;
    
    bool luma = m_Luma->getValueAtTime(p_Args.time);
    bool sat = m_Sat->getValueAtTime(p_Args.time);
    
    double redred = m_RedRed->getValueAtTime(p_Args.time);
    double redgreen = m_RedGreen->getValueAtTime(p_Args.time);
    double redblue = m_RedBlue->getValueAtTime(p_Args.time);
    double greenred = m_GreenRed->getValueAtTime(p_Args.time);
    double greengreen = m_GreenGreen->getValueAtTime(p_Args.time);
    double greenblue = m_GreenBlue->getValueAtTime(p_Args.time);
    double bluered = m_BlueRed->getValueAtTime(p_Args.time);
    double bluegreen = m_BlueGreen->getValueAtTime(p_Args.time);
    double blueblue = m_BlueBlue->getValueAtTime(p_Args.time);
    double redvgreen = m_RedvGreen->getValueAtTime(p_Args.time);
    double redvblue = m_RedvBlue->getValueAtTime(p_Args.time);
    double redvgreenblue = m_RedvGreenBlue->getValueAtTime(p_Args.time);
    double greenvred = m_GreenvRed->getValueAtTime(p_Args.time);
    double greenvblue = m_GreenvBlue->getValueAtTime(p_Args.time);
    double greenvredblue = m_GreenvRedBlue->getValueAtTime(p_Args.time);
    double bluevred = m_BluevRed->getValueAtTime(p_Args.time);
    double bluevgreen = m_BluevGreen->getValueAtTime(p_Args.time);
    double bluevredgreen = m_BluevRedGreen->getValueAtTime(p_Args.time);
    double redVGG = m_RedVGG->getValueAtTime(p_Args.time);
    double greenVBB = m_GreenVBB->getValueAtTime(p_Args.time);
    double blueVRR = m_BlueVRR->getValueAtTime(p_Args.time);
    double cyan = m_Cyan->getValueAtTime(p_Args.time);
    double magenta = m_Magenta->getValueAtTime(p_Args.time);
    double yellow = m_Yellow->getValueAtTime(p_Args.time);
    double temp = m_Temp->getValueAtTime(p_Args.time);
    double tint = m_Tint->getValueAtTime(p_Args.time);
    
    if ((rrScale == 1.0f) && (rgScale == 0.0f) && (rbScale == 0.0f) && (!luma) && (!sat) && (grScale == 0.0f) && (ggScale == 1.0f) && 
    (gbScale == 0.0f) && (brScale == 0.0f) && (bgScale == 0.0f) && (bbScale == 1.0f) && (redred == 1.0f) && 
    (redgreen == 0.0f) && (redblue == 0.0f) && (greenred == 0.0f) && (greengreen == 1.0f) && (greenblue == 0.0f)
     && (bluered == 0.0f) && (bluegreen == 0.0f) && (blueblue == 1.0f) && (redvgreen == 0.0f) && (redvblue == 0.0f) && 
     (redvgreenblue == 0.0f) && (greenvred == 0.0f) && (greenvblue == 0.0f) && (greenvredblue == 0.0f) && (bluevred == 0.0f) &&
      (bluevgreen == 0.0f) && (bluevredgreen == 0.0f) && (cyan == 0.0f) && (magenta == 0.0f) && (yellow == 0.0f) && (redVGG == 0.0f) && 
      (greenVBB == 0.0f) && (blueVRR == 0.0f) && (temp == 0.0f) && (tint == 0.0f))
    {
        p_IdentityClip = m_SrcClip;
        p_IdentityTime = p_Args.time;
        return true;
    }

    return false;
}

void MatrixPlugin::changedParam(const OFX::InstanceChangedArgs& p_Args, const std::string& p_ParamName)
{
    if ((p_ParamName == "paramR" || p_ParamName == "paramG" || p_ParamName == "paramB") && p_Args.reason == OFX::eChangeUserEdit)
    {
    	RGBValues rScale;
    	m_ScaleR->getValueAtTime(p_Args.time, rScale.r, rScale.g, rScale.b);
    	RGBValues gScale;
    	m_ScaleG->getValueAtTime(p_Args.time, gScale.r, gScale.g, gScale.b);
    	RGBValues bScale;
    	m_ScaleB->getValueAtTime(p_Args.time, bScale.r, bScale.g, bScale.b);
    	
    	beginEditBlock("RGB Mixer");
    	beginEditBlock("Channel Vs Channel");
    	m_RedRed->setValue(rScale.r);
    	m_RedGreen->setValue(rScale.g);
    	m_RedBlue->setValue(rScale.b);
    	m_GreenRed->setValue(gScale.r);
    	m_GreenGreen->setValue(gScale.g);
    	m_GreenBlue->setValue(gScale.b);
    	m_BlueRed->setValue(bScale.r);
    	m_BlueGreen->setValue(bScale.g);
    	m_BlueBlue->setValue(bScale.b);
    	m_RedvGreen->setValue(0.0);
    	m_RedvBlue->setValue(0.0);
    	m_RedvGreenBlue->setValue(0.0);
    	m_GreenvRed->setValue(0.0);
    	m_GreenvBlue->setValue(0.0);
    	m_GreenvRedBlue->setValue(0.0);
    	m_BluevRed->setValue(0.0);
    	m_BluevGreen->setValue(0.0);
    	m_BluevRedGreen->setValue(0.0);
    	m_RedVGG->setValue(0.0);
    	m_GreenVBB->setValue(0.0);
    	m_BlueVRR->setValue(0.0);
    	m_Cyan->setValue(0.0);
    	m_Magenta->setValue(0.0);
    	m_Yellow->setValue(0.0);
    	m_Temp->setValue(0.0);
    	m_Tint->setValue(0.0);
    	endEditBlock();
    	
    }
    
    if (p_ParamName == "invert")
    {
    
    OFX::Message::MessageReplyEnum reply = sendMessage(OFX::Message::eMessageQuestion, "", "Get Inverse of 3x3 Matrix?");
	if (reply == OFX::Message::eMessageReplyYes) {
	
	RGBValues rScale;
	m_ScaleR->getValueAtTime(p_Args.time, rScale.r, rScale.g, rScale.b);
	RGBValues gScale;
	m_ScaleG->getValueAtTime(p_Args.time, gScale.r, gScale.g, gScale.b);
	RGBValues bScale;
	m_ScaleB->getValueAtTime(p_Args.time, bScale.r, bScale.g, bScale.b);
   	
	double A = gScale.g * bScale.b - gScale.b * bScale.g;
    double B = -(gScale.r * bScale.b - gScale.b * bScale.r);
    double C = gScale.r * bScale.g - gScale.g * bScale.r;
    double D = -(rScale.g * bScale.b - rScale.b * bScale.g);
    double E = rScale.r * bScale.b - rScale.b * bScale.r;
    double F = -(rScale.r * bScale.g - rScale.g * bScale.r);
    double G = rScale.g * gScale.b - rScale.b * gScale.g;
    double H = -(rScale.r * gScale.b - rScale.b * gScale.r);
    double I = rScale.r * gScale.g - rScale.g * gScale.r;
    
    double det = rScale.r * A + rScale.g * B + rScale.b * C;
    
    double rr = A / det;
    double rg = D / det;
    double rb = G / det;
    double gr = B / det;
    double gg = E / det;
    double gb = H / det;
    double br = C / det;
    double bg = F / det;
    double bb = I / det;
    
    beginEditBlock("3x3 Matrix");
    beginEditBlock("RGB Mixer");
    beginEditBlock("Channel Vs Channel");	
	m_ScaleR->setValue(rr, rg, rb);
	m_ScaleG->setValue(gr, gg, gb);
	m_ScaleB->setValue(br, bg, bb);
	m_RedRed->setValue(rr);
	m_RedGreen->setValue(rg);
	m_RedBlue->setValue(rb);
	m_GreenRed->setValue(gr);
	m_GreenGreen->setValue(gg);
	m_GreenBlue->setValue(gb);
	m_BlueRed->setValue(br);
	m_BlueGreen->setValue(bg);
	m_BlueBlue->setValue(bb);
	m_RedvGreen->setValue(0.0);
	m_RedvBlue->setValue(0.0);
	m_RedvGreenBlue->setValue(0.0);
	m_GreenvRed->setValue(0.0);
	m_GreenvBlue->setValue(0.0);
	m_GreenvRedBlue->setValue(0.0);
	m_BluevRed->setValue(0.0);
	m_BluevGreen->setValue(0.0);
	m_BluevRedGreen->setValue(0.0);
	m_RedVGG->setValue(0.0);
	m_GreenVBB->setValue(0.0);
	m_BlueVRR->setValue(0.0);
	m_Cyan->setValue(0.0);
	m_Magenta->setValue(0.0);
	m_Yellow->setValue(0.0);
	m_Temp->setValue(0.0);
	m_Tint->setValue(0.0);
	endEditBlock();
	
	}
	}
    
    if ((p_ParamName == "scaleRR" || p_ParamName == "scaleRG" || p_ParamName == "scaleRB" || p_ParamName == "scaleGR" || 
    p_ParamName == "scaleGG" || p_ParamName == "scaleGB" || p_ParamName == "scaleBR" || p_ParamName == "scaleBG" || 
    p_ParamName == "scaleBB" || p_ParamName == "scaleRvG" || p_ParamName == "scaleRvB" || p_ParamName == "scaleRvGB" || 
    p_ParamName == "scaleGvR" || p_ParamName == "scaleGvB" || p_ParamName == "scaleGvRB" || p_ParamName == "scaleBvR" || 
    p_ParamName == "scaleBvG" || p_ParamName == "scaleBvRG" || p_ParamName == "scaleRvGG" || p_ParamName == "scaleGvBB" || 
    p_ParamName == "scaleBvRR" || p_ParamName == "scaleC" || p_ParamName == "scaleM" || 
    p_ParamName == "scaleY" || p_ParamName == "scaleTemp" || p_ParamName == "scaleTint") && p_Args.reason == OFX::eChangeUserEdit)
    {
    	double redred = m_RedRed->getValueAtTime(p_Args.time);
		double redgreen = m_RedGreen->getValueAtTime(p_Args.time);
		double redblue = m_RedBlue->getValueAtTime(p_Args.time);
		double greenred = m_GreenRed->getValueAtTime(p_Args.time);
		double greengreen = m_GreenGreen->getValueAtTime(p_Args.time);
		double greenblue = m_GreenBlue->getValueAtTime(p_Args.time);
		double bluered = m_BlueRed->getValueAtTime(p_Args.time);
		double bluegreen = m_BlueGreen->getValueAtTime(p_Args.time);
		double blueblue = m_BlueBlue->getValueAtTime(p_Args.time);
    	double redvgreen = m_RedvGreen->getValueAtTime(p_Args.time);
    	double redvblue = m_RedvBlue->getValueAtTime(p_Args.time);
    	double redvgreenblue = m_RedvGreenBlue->getValueAtTime(p_Args.time);
    	double greenvred = m_GreenvRed->getValueAtTime(p_Args.time);
    	double greenvblue = m_GreenvBlue->getValueAtTime(p_Args.time);
    	double greenvredblue = m_GreenvRedBlue->getValueAtTime(p_Args.time);
    	double bluevred = m_BluevRed->getValueAtTime(p_Args.time);
    	double bluevgreen = m_BluevGreen->getValueAtTime(p_Args.time);
    	double bluevredgreen = m_BluevRedGreen->getValueAtTime(p_Args.time);
    	double redVGG = m_RedVGG->getValueAtTime(p_Args.time);
    	double greenVBB = m_GreenVBB->getValueAtTime(p_Args.time);
    	double blueVRR = m_BlueVRR->getValueAtTime(p_Args.time);
    	double cyan = m_Cyan->getValueAtTime(p_Args.time);
    	double magenta = m_Magenta->getValueAtTime(p_Args.time);
    	double yellow = m_Yellow->getValueAtTime(p_Args.time);
    	double temp = m_Temp->getValueAtTime(p_Args.time);
    	double tint = m_Tint->getValueAtTime(p_Args.time);
    	
    	double redred1 = redred + redvgreen + redvblue + redvgreenblue + redVGG - blueVRR + (magenta/2.0) + (yellow/2.0) + temp;
    	double redgreen1 = redgreen - redvgreen - (redvgreenblue/2.0);
    	double redblue1 = redblue - redvblue - (redvgreenblue/2.0);
    	double greenred1 = greenred - greenvred - (greenvredblue/2.0);
    	double greengreen1 = greengreen + greenvred + greenvblue + greenvredblue + greenVBB - redVGG + (cyan/2.0) + (yellow/2.0) - tint;
    	double greenblue1 = greenblue - greenvblue - (greenvredblue/2.0);
    	double bluered1 = bluered - bluevred - (bluevredgreen/2.0);
    	double bluegreen1 = bluegreen - bluevgreen - (bluevredgreen/2.0);
    	double blueblue1 = blueblue + bluevred + bluevgreen + bluevredgreen + blueVRR - greenVBB + (cyan/2.0) + (magenta/2.0) - temp;
    	
    	beginEditBlock("3x3 Matrix");	
    	m_ScaleR->setValue(redred1, redgreen1, redblue1);
    	m_ScaleG->setValue(greenred1, greengreen1, greenblue1);
    	m_ScaleB->setValue(bluered1, bluegreen1, blueblue1);
    	endEditBlock();
    	
    }
    
    if(p_ParamName == "info")
    {
	
	sendMessage(OFX::Message::eMessageMessage, "", string(kPluginDescription));
	
	}	
  
    if(p_ParamName == "button1")
    {
 
   	 bool luma = m_Luma->getValueAtTime(p_Args.time);
	 int lumaswitch = luma ? 1 : 0;
	
	 bool sat = m_Sat->getValueAtTime(p_Args.time);
	 int satswitch = sat ? 1 : 0;

   	 RGBValues rScale;
	 m_ScaleR->getValueAtTime(p_Args.time, rScale.r, rScale.g, rScale.b);
	 RGBValues gScale;
	 m_ScaleG->getValueAtTime(p_Args.time, gScale.r, gScale.g, gScale.b);
	 RGBValues bScale;
	 m_ScaleB->getValueAtTime(p_Args.time, bScale.r, bScale.g, bScale.b);
   	    
	const float Matrix[9] = {rScale.r, rScale.g, rScale.b, gScale.r, gScale.g, gScale.b, bScale.r, bScale.g, bScale.b};
   	    	
	string PATH;
	m_Path->getValue(PATH);
	
	string NAME;
	m_Name->getValue(NAME);
	
	OFX::Message::MessageReplyEnum reply = sendMessage(OFX::Message::eMessageQuestion, "", "Save " + NAME + ".dctl to " + PATH + "?");
	if (reply == OFX::Message::eMessageReplyYes) {
	
	FILE * pFile;
	
	pFile = fopen ((PATH + "/" + NAME + ".dctl").c_str(), "w");
	if (pFile != NULL) {
    	
	fprintf (pFile, "// MatrixPlugin DCTL export\n" \
	"\n" \
	"__DEVICE__ float3 transform(int p_Width, int p_Height, int p_X, int p_Y, float p_R, float p_G, float p_B)\n" \
	"{\n" \
	"\n" \
	"   const float Matrix[9] =  {%ff, %ff, %ff, %ff, %ff, %ff, %ff, %ff, %ff};\n" \
	"   int lumaswitch = %d;\n" \
	"   int satswitch = %d;\n" \
	"\n" \
	"   float mn1 = _fminf(p_R, _fminf(p_G, p_B));   \n" \
	"   float Mx1 = _fmaxf(p_R, _fmaxf(p_G, p_B));    \n" \
	"   float del_Mx1 = Mx1 - mn1;	\n" \
	"   float L1 = (Mx1 + mn1) / 2.0f;	\n" \
	"   float Sat1 = del_Mx1 == 0.0f ? 0.0f : L1 < 0.5f ? del_Mx1 / (Mx1 + mn1) : del_Mx1 / (2.0f - Mx1 - mn1);	\n" \
	"   float Y1 =  p_R * 0.299f + p_G * 0.587f + p_B * 0.114f;	\n" \
	"   	   \n" \
	"   float red = p_R * Matrix[0] + p_G * Matrix[1] + p_B * Matrix[2];	\n" \
	"   float green = p_R * Matrix[3] + p_G * Matrix[4] + p_B * Matrix[5];	\n" \
	"   float blue = p_R * Matrix[6] + p_G * Matrix[7] + p_B * Matrix[8];	\n" \
	"  			\n" \
	"   float Y2 =  red * 0.299f + green * 0.587f + blue * 0.114f;	\n" \
	"   float U2 = red * -0.147f - green * 0.289f + blue * 0.436f;	\n" \
	"   float V2 =  red * 0.615f - green * 0.515f - blue * 0.1f;	\n" \
	"				\n" \
	"   float R1 = (lumaswitch != 1 ? Y2 : Y1) + 1.140f * V2;	\n" \
	"   float G1 = (lumaswitch != 1 ? Y2 : Y1) - 0.395f * U2 - 0.581f * V2;	\n" \
	"   float B1 = (lumaswitch != 1 ? Y2 : Y1) + 2.032f * U2;	\n" \
	"						\n" \
	"   float mn2 = _fminf(R1, _fminf(G1, B1));    \n" \
	"   float Mx2 = _fmaxf(R1, _fmaxf(G1, B1));    \n" \
	"   float del_Mx2 = Mx2 - mn2;	\n" \
	"   float L2 = (Mx2 + mn2) / 2.0f;	\n" \
	"						\n" \
	"   float del_R = ((Mx2 - R1) / 6.0f + del_Mx2 / 2.0f) / del_Mx2;	\n" \
	"   float del_G = ((Mx2 - G1) / 6.0f + del_Mx2 / 2.0f) / del_Mx2;	\n" \
	"   float del_B = ((Mx2 - B1) / 6.0f + del_Mx2 / 2.0f) / del_Mx2;	\n" \
	"						\n" \
	"   float h = del_Mx2 == 0.0f ? 0.0f : R1 == Mx2 ? del_B - del_G : G1 == Mx2 ? 1.0f / 3.0f + 	\n" \
	"   del_R - del_B : 2.0f / 3.0f + del_G - del_R;	\n" \
	"					\n" \
	"   float H = h < 0.0f ? h + 1.0f : h > 1.0f ? h - 1.0f : h;	\n" \
	"					\n" \
	"   float S = Sat1;	\n" \
	"						\n" \
	"   float Q = L2 < 0.5f ? L2 * (1.0f + S) : L2 + S - L2 * S;	\n" \
	"   float P = 2.0f * L2 - Q;	\n" \
	"					\n" \
	"   float RH = H + 1.0f / 3.0f < 0.0f ? H + 1.0f / 3.0f + 1.0f :	\n" \
	"   H + 1.0f / 3.0f > 1.0f ? H + 1.0f / 3.0f - 1.0f : H + 1.0f / 3.0f;	\n" \
	"					\n" \
	"   float RR = RH < 1.0f / 6.0f ? P + (Q - P) * 6.0f * RH : 	\n" \
	"   RH < 1.0f / 2.0f ? Q : RH < 2.0f / 3.0f ? P + (Q - P) * (2.0f / 3.0f - RH) * 6.0f : P;	\n" \
	"							\n" \
	"   float GH = H < 0.0f ? H + 1.0f : H > 1.0f ? H - 1.0f : H;	\n" \
	"				\n" \
	"   float GG = GH < 1.0f / 6.0f ? P + (Q - P) * 6.0f * GH :		\n" \
	"   GH < 1.0f / 2.0f ? Q : GH < 2.0f / 3.0f ? P + (Q - P) * (2.0f / 3.0f - GH) * 6.0f : P;	\n" \
	"				\n" \
	"   float BH = H - 1.0f / 3.0f < 0.0f ? H - 1.0f / 3.0f + 1.0f :	\n" \
	"   H - 1.0f / 3.0f > 1.0f ? H - 1.0f / 3.0f - 1.0f : H - 1.0f / 3.0f;	\n" \
	"					\n" \
	"   float BB = BH < 1.0f / 6.0f ? P + (Q - P) * 6.0f * BH :		\n" \
	"   BH < 1.0f / 2.0f ? Q : BH < 2.0f / 3.0f ? P + (Q - P) * (2.0f / 3.0f - BH) * 6.0f : P;	\n" \
	"					\n" \
	"   float r = satswitch == 1 ? (S == 0.0f ? L2 : RR) : R1;	\n" \
	"   float g = satswitch == 1 ? (S == 0.0f ? L2 : GG) : G1;	\n" \
	"   float b = satswitch == 1 ? (S == 0.0f ? L2 : BB) : B1;	\n" \
	"   			\n" \
	"   return make_float3(r, g, b);	\n" \
	"}\n", Matrix[0], Matrix[1], Matrix[2], Matrix[3], Matrix[4], 
	Matrix[5], Matrix[6], Matrix[7], Matrix[8], lumaswitch, satswitch);
	fclose (pFile);
	} else {
     sendMessage(OFX::Message::eMessageError, "", string("Error: Cannot save " + NAME + ".dctl to " + PATH  + ". Check Permissions."));
	}	
	}
	}
	
	if(p_ParamName == "button2")
    {
      
	bool luma = m_Luma->getValueAtTime(p_Args.time);
	int lumaswitch = luma ? 1 : 0;
   
	bool sat = m_Sat->getValueAtTime(p_Args.time);
	int satswitch = sat ? 1 : 0;
      
	RGBValues rScale;
	m_ScaleR->getValueAtTime(p_Args.time, rScale.r, rScale.g, rScale.b);
	RGBValues gScale;
	m_ScaleG->getValueAtTime(p_Args.time, gScale.r, gScale.g, gScale.b);
	RGBValues bScale;
	m_ScaleB->getValueAtTime(p_Args.time, bScale.r, bScale.g, bScale.b);
   	    
	const float Matrix[9] = {rScale.r, rScale.g, rScale.b, gScale.r, gScale.g, gScale.b, bScale.r, bScale.g, bScale.b};
    
    string PATH;
	m_Path->getValue(PATH);
	
	string NAME;
	m_Name->getValue(NAME);
	
	OFX::Message::MessageReplyEnum reply = sendMessage(OFX::Message::eMessageQuestion, "", "Save " + NAME + ".nk to " + PATH + "?");
	if (reply == OFX::Message::eMessageReplyYes) {
	
	FILE * pFile;
	
	pFile = fopen ((PATH + "/" + NAME + ".nk").c_str(), "w");
	if (pFile != NULL) {
    	
	fprintf (pFile, "Group {\n" \
	"inputs 0\n" \
	"name Matrix\n" \
	"selected true\n" \
	"xpos -231\n" \
	"ypos -318\n" \
	"}\n" \
	"Input {\n" \
	"inputs 0\n" \
	"name Input1\n" \
	"selected true\n" \
	"xpos -29\n" \
	"ypos -318\n" \
	"}\n" \
	"NoOp {\n" \
	"name NoOp1\n" \
	"xpos -29\n" \
	"ypos -277\n" \
	"}\n" \
	"set N3aa0a920 [stack 0]\n" \
	"Colorspace {\n" \
	"colorspace_in sRGB\n" \
	"colorspace_out HSL\n" \
	"name HSL_orig\n" \
	"xpos -135\n" \
	"ypos -225\n" \
	"}\n" \
	"push $N3aa0a920\n" \
	"Expression {\n" \
	"expr0 \"r*%f + g*%f + b*%f\"\n" \
	"expr1 \"r*%f + g*%f + b*%f\"\n" \
	"expr2 \"r*%f + g*%f + b*%f\"\n" \
	"name Matrix_3x3\n" \
	"xpos 78\n" \
	"ypos -225\n" \
	"}\n" \
	"Colorspace {\n" \
	"colorspace_in sRGB\n" \
	"colorspace_out YCbCr\n" \
	"name YUV_after\n" \
	"xpos 78\n" \
	"ypos -162\n" \
	"}\n" \
	"set N3b5f1f10 [stack 0]\n" \
	"push $N3aa0a920\n" \
	"Colorspace {\n" \
	"colorspace_in sRGB\n" \
	"colorspace_out YCbCr\n" \
	"name YUV_orig\n" \
	"xpos -29\n" \
	"ypos -224\n" \
	"}\n" \
	"ShuffleCopy {\n" \
	"inputs 2\n" \
	"in rgb\n" \
	"in2 rgb\n" \
	"green green\n" \
	"blue blue\n" \
	"out rgb\n" \
	"name Yorig_UVafter\n" \
	"xpos -29\n" \
	"ypos -189\n" \
	"}\n" \
	"push $N3b5f1f10\n" \
	"Switch {\n" \
	"inputs 2\n" \
	"which %d\n" \
	"name Luma_Switch\n" \
	"xpos 40\n" \
	"ypos -105\n" \
	"}\n" \
	"Colorspace {\n" \
	"colorspace_in YCbCr\n" \
	"colorspace_out sRGB\n" \
	"name RGB_after_YUV\n" \
	"xpos 31\n" \
	"ypos -68\n" \
	"}\n" \
	"Colorspace {\n" \
	"colorspace_in sRGB\n" \
	"colorspace_out HSL\n" \
	"name HSL_after\n" \
	"xpos 31\n" \
	"ypos -30\n" \
	"}\n" \
	"set N3c72b600 [stack 0]\n" \
	"ShuffleCopy {\n" \
	"inputs 2\n" \
	"in rgb\n" \
	"in2 rgb\n" \
	"green green\n" \
	"out rgb\n" \
	"name H_after_S_orig_L_after\n" \
	"xpos -25\n" \
	"ypos 12\n" \
	"}\n" \
	"push $N3c72b600\n" \
	"Switch {\n" \
	"inputs 2\n" \
	"which %d\n" \
	"name Sat_Switch\n" \
	"xpos 12\n" \
	"ypos 48\n" \
	"}\n" \
	"Colorspace {\n" \
	"colorspace_in HSL\n" \
	"colorspace_out sRGB\n" \
	"name RGB_after_HSL\n" \
	"xpos 12\n" \
	"ypos 85\n" \
	"}\n" \
	"Output {\n" \
	"name Output1\n" \
	"xpos 12\n" \
	"ypos 133\n" \
	"}\n" \
	"end_group\n", Matrix[0], Matrix[1], Matrix[2], Matrix[3], Matrix[4], 
	Matrix[5], Matrix[6], Matrix[7], Matrix[8], lumaswitch, satswitch);
	fclose (pFile);
	} else {
     sendMessage(OFX::Message::eMessageError, "", string("Error: Cannot save " + NAME + ".nk to " + PATH  + ". Check Permissions."));
	}	
	}
	}
}

void MatrixPlugin::setupAndProcess(ImageScaler& p_ImageScaler, const OFX::RenderArguments& p_Args)
{
    // Get the dst image
    std::auto_ptr<OFX::Image> dst(m_DstClip->fetchImage(p_Args.time));
    OFX::BitDepthEnum dstBitDepth = dst->getPixelDepth();
    OFX::PixelComponentEnum dstComponents = dst->getPixelComponents();

    // Get the src image
    std::auto_ptr<OFX::Image> src(m_SrcClip->fetchImage(p_Args.time));
    OFX::BitDepthEnum srcBitDepth = src->getPixelDepth();
    OFX::PixelComponentEnum srcComponents = src->getPixelComponents();

    // Check to see if the bit depth and number of components are the same
    if ((srcBitDepth != dstBitDepth) || (srcComponents != dstComponents))
    {
        OFX::throwSuiteStatusException(kOfxStatErrValue);
    }

    
    RGBValues rScale;
    m_ScaleR->getValueAtTime(p_Args.time, rScale.r, rScale.g, rScale.b);
    double rrScale = rScale.r;
    double rgScale = rScale.g;
    double rbScale = rScale.b;
    
    RGBValues gScale;
    m_ScaleG->getValueAtTime(p_Args.time, gScale.r, gScale.g, gScale.b);
    double grScale = gScale.r;
    double ggScale = gScale.g;
    double gbScale = gScale.b;
    
    RGBValues bScale;
    m_ScaleB->getValueAtTime(p_Args.time, bScale.r, bScale.g, bScale.b);
    double brScale = bScale.r;
    double bgScale = bScale.g;
    double bbScale = bScale.b;
    
    bool luma = m_Luma->getValueAtTime(p_Args.time);
	float lumaF = luma ? 1.0f : 0.0f;
	
	bool sat = m_Sat->getValueAtTime(p_Args.time);
	float satF = sat ? 1.0f : 0.0f;

    // Set the images
    p_ImageScaler.setDstImg(dst.get());
    p_ImageScaler.setSrcImg(src.get());

    // Setup OpenCL and CUDA Render arguments
    p_ImageScaler.setGPURenderArgs(p_Args);

    // Set the render window
    p_ImageScaler.setRenderWindow(p_Args.renderWindow);

    // Set the scales
    p_ImageScaler.setScales(rrScale, rgScale, rbScale, grScale, ggScale, gbScale, brScale, bgScale, bbScale, lumaF, satF);

    // Call the base class process member, this will call the derived templated process code
    p_ImageScaler.process();
}

////////////////////////////////////////////////////////////////////////////////

using namespace OFX;

MatrixPluginFactory::MatrixPluginFactory()
    : OFX::PluginFactoryHelper<MatrixPluginFactory>(kPluginIdentifier, kPluginVersionMajor, kPluginVersionMinor)
{
}

void MatrixPluginFactory::describe(OFX::ImageEffectDescriptor& p_Desc)
{
    // Basic labels
    p_Desc.setLabels(kPluginName, kPluginName, kPluginName);
    p_Desc.setPluginGrouping(kPluginGrouping);
    p_Desc.setPluginDescription(kPluginDescription);

    // Add the supported contexts, only filter at the moment
    p_Desc.addSupportedContext(eContextFilter);
    p_Desc.addSupportedContext(eContextGeneral);

    // Add supported pixel depths
    p_Desc.addSupportedBitDepth(eBitDepthFloat);

    // Set a few flags
    p_Desc.setSingleInstance(false);
    p_Desc.setHostFrameThreading(false);
    p_Desc.setSupportsMultiResolution(kSupportsMultiResolution);
    p_Desc.setSupportsTiles(kSupportsTiles);
    p_Desc.setTemporalClipAccess(false);
    p_Desc.setRenderTwiceAlways(false);
    p_Desc.setSupportsMultipleClipPARs(kSupportsMultipleClipPARs);

    // Setup OpenCL and CUDA render capability flags
    p_Desc.setSupportsOpenCLRender(true);
    p_Desc.setSupportsCudaRender(true);
}

static DoubleParamDescriptor* defineScaleParam(OFX::ImageEffectDescriptor& p_Desc, const std::string& p_Name, const std::string& p_Label,
                                               const std::string& p_Hint, GroupParamDescriptor* p_Parent)
{
    DoubleParamDescriptor* param = p_Desc.defineDoubleParam(p_Name);
	param->setLabel(p_Label);
    param->setScriptName(p_Name);
    param->setHint(p_Hint);
    
    if (p_Parent)
    {
        param->setParent(*p_Parent);
    }

    return param;
}


void MatrixPluginFactory::describeInContext(OFX::ImageEffectDescriptor& p_Desc, OFX::ContextEnum /*p_Context*/)
{
    // Source clip only in the filter context
    // Create the mandated source clip
    ClipDescriptor* srcClip = p_Desc.defineClip(kOfxImageEffectSimpleSourceClipName);
    srcClip->addSupportedComponent(ePixelComponentRGBA);
    srcClip->setTemporalClipAccess(false);
    srcClip->setSupportsTiles(kSupportsTiles);
    srcClip->setIsMask(false);

    // Create the mandated output clip
    ClipDescriptor* dstClip = p_Desc.defineClip(kOfxImageEffectOutputClipName);
    dstClip->addSupportedComponent(ePixelComponentRGBA);
    dstClip->addSupportedComponent(ePixelComponentAlpha);
    dstClip->setSupportsTiles(kSupportsTiles);

    // Make some pages and to things in
    PageParamDescriptor* page = p_Desc.definePageParam("Controls");

    // Make the component scale params
   
	{    
    GroupParamDescriptor* matrix = p_Desc.defineGroupParam("3x3 Matrix");
    matrix->setOpen(true);
    matrix->setHint("3x3 Matrix");
      if (page) {
            page->addChild(*matrix);
            }
    
    Double3DParamDescriptor* paramR = p_Desc.defineDouble3DParam("paramR");
    paramR->setLabel("Red Output");
    paramR->setDefault(1.0, 0.0, 0.0);
    paramR->setParent(*matrix);
    page->addChild(*paramR);
    
    Double3DParamDescriptor* paramG = p_Desc.defineDouble3DParam("paramG");
    paramG->setLabel("Green Output");
    paramG->setDefault(0.0, 1.0, 0.0);
    paramG->setParent(*matrix);
    page->addChild(*paramG);
    
    Double3DParamDescriptor* paramB = p_Desc.defineDouble3DParam("paramB");
    paramB->setLabel("Blue Output");
    paramB->setDefault(0.0, 0.0, 1.0);
    paramB->setParent(*matrix);
    page->addChild(*paramB);
    
    BooleanParamDescriptor* boolParam = p_Desc.defineBooleanParam("luma");
    boolParam->setDefault(false);
    boolParam->setHint("replaces output Y with input Y to preserve luma");
    boolParam->setLabel("Preserve Luma");
    boolParam->setParent(*matrix);
    page->addChild(*boolParam);
    
    boolParam = p_Desc.defineBooleanParam("sat");
    boolParam->setDefault(false);
    boolParam->setHint("rescales UV channels to preserve saturation");
    boolParam->setLabel("Preserve Saturation");
    boolParam->setParent(*matrix);
    page->addChild(*boolParam);
    
    {
    PushButtonParamDescriptor* param = p_Desc.definePushButtonParam("invert");
    param->setLabel("Inverse Matrix");
    param->setParent(*matrix);
    page->addChild(*param);
    }
    
    {
    PushButtonParamDescriptor* param = p_Desc.definePushButtonParam("info");
    param->setLabel("Info");
    param->setParent(*matrix);
    page->addChild(*param);
    }
    
	}
	
	{    
    GroupParamDescriptor* mixer = p_Desc.defineGroupParam("RGB Mixer");
    mixer->setOpen(false);
    mixer->setHint("RGB Mixer");
      if (page) {
            page->addChild(*mixer);
            }
            
    DoubleParamDescriptor* param = defineScaleParam(p_Desc, "scaleRR", "RED red", "Red component of Red channel", mixer);
    param->setDefault(1.0);
    param->setRange(-10.0, 10.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-2.0, 2.0);
    page->addChild(*param);
    
    param = defineScaleParam(p_Desc, "scaleRG", "RED green", "Green component of Red channel", mixer);
    param->setDefault(0.0);
    param->setRange(-10.0, 10.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-2.0, 2.0);
    page->addChild(*param);
    
    param = defineScaleParam(p_Desc, "scaleRB", "RED blue", "Blue component of Red channel", mixer);
    param->setDefault(0.0);
    param->setRange(-10.0, 10.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-2.0, 2.0);
    page->addChild(*param);
    
    param = defineScaleParam(p_Desc, "scaleGR", "Green red", "Red component of Green channel", mixer);
    param->setDefault(0.0);
    param->setRange(-10.0, 10.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-2.0, 2.0);
    page->addChild(*param);
    
    param = defineScaleParam(p_Desc, "scaleGG", "Green green", "Green component of Green channel", mixer);
    param->setDefault(1.0);
    param->setRange(-10.0, 10.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-2.0, 2.0);
    page->addChild(*param);
    
    param = defineScaleParam(p_Desc, "scaleGB", "Green blue", "Blue component of Green channel", mixer);
    param->setDefault(0.0);
    param->setRange(-10.0, 10.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-2.0, 2.0);
    page->addChild(*param);
    
    param = defineScaleParam(p_Desc, "scaleBR", "Blue red", "Red component of Blue channel", mixer);
    param->setDefault(0.0);
    param->setRange(-10.0, 10.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-2.0, 2.0);
    page->addChild(*param);
    
    param = defineScaleParam(p_Desc, "scaleBG", "Blue green", "Green component of Blue channel", mixer);
    param->setDefault(0.0);
    param->setRange(-10.0, 10.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-2.0, 2.0);
    page->addChild(*param);
    
    param = defineScaleParam(p_Desc, "scaleBB", "Blue blue", "Blue component of Blue channel", mixer);
    param->setDefault(1.0);
    param->setRange(-10.0, 10.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-2.0, 2.0);
    page->addChild(*param);
    
	}
	
	{    
    GroupParamDescriptor* versus = p_Desc.defineGroupParam("Channel Vs Channel");
    versus->setOpen(false);
    versus->setHint("channel vs channel");
      if (page) {
            page->addChild(*versus);
            }
            
    DoubleParamDescriptor* param = defineScaleParam(p_Desc, "scaleRvG", "RED vs Green", "Swap Red with Green", versus);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param);   
    
    param = defineScaleParam(p_Desc, "scaleRvB", "RED vs Blue", "Swap Red with Blue", versus);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param);
    
    param = defineScaleParam(p_Desc, "scaleRvGB", "RED vs GreenBlue", "Swap Red with Green & Blue", versus);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param); 
    
    param = defineScaleParam(p_Desc, "scaleGvR", "GREEN vs Red", "Swap Green with Red", versus);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param); 
    
    param = defineScaleParam(p_Desc, "scaleGvB", "GREEN vs Blue", "Swap Green with Blue", versus);
    param->setDefault(0.0);
    param->setRange(-2.0, 2.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-2.0, 2.0);
    page->addChild(*param); 
    
    param = defineScaleParam(p_Desc, "scaleGvRB", "GREEN vs RedBlue", "Swap Green with Red & Blue", versus);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param); 
    
    param = defineScaleParam(p_Desc, "scaleBvR", "BLUE vs Red", "Swap Blue with Red", versus);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param); 
    
    param = defineScaleParam(p_Desc, "scaleBvG", "BLUE vs Green", "Swap Blue with Green", versus);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param); 
    
    param = defineScaleParam(p_Desc, "scaleBvRG", "BLUE vs RedGreen", "Swap Blue with Red & Green", versus);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param);
    
    param = defineScaleParam(p_Desc, "scaleRvGG", "RED vs GREEN", "Scale Red & Green channels in opposite directions", versus);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param);
    
    param = defineScaleParam(p_Desc, "scaleGvBB", "GREEN vs BLUE", "Scale Green & Blue channels in opposite directions", versus);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param);
    
    param = defineScaleParam(p_Desc, "scaleBvRR", "BLUE vs RED", "Scale Blue & Red channels in opposite directions", versus);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param); 
    
    param = defineScaleParam(p_Desc, "scaleC", "CYAN", "Scale Cyan", versus);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param); 
    
    param = defineScaleParam(p_Desc, "scaleM", "MAGENTA", "Scale Magenta", versus);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param); 
    
    param = defineScaleParam(p_Desc, "scaleY", "YELLOW", "Scale Yellow", versus);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param);         
    
    param = defineScaleParam(p_Desc, "scaleTemp", "TEMP", "Temperature", versus);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param);         
    
    param = defineScaleParam(p_Desc, "scaleTint", "TINT", "Tint", versus);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param);         
    
    }
    {    
    GroupParamDescriptor* script = p_Desc.defineGroupParam("Script Export");
    script->setOpen(false);
    script->setHint("export DCTL and Nuke script");
      if (page) {
            page->addChild(*script);
            }
    {
    PushButtonParamDescriptor* param = p_Desc.definePushButtonParam("button1");
    param->setLabel("Export DCTL");
    param->setHint("create DCTL version");
    param->setParent(*script);
    page->addChild(*param);
    }
    {
    PushButtonParamDescriptor* param = p_Desc.definePushButtonParam("button2");
    param->setLabel("Export Nuke script");
    param->setHint("create NUKE version");
    param->setParent(*script);
    page->addChild(*param);
    }
    {
	StringParamDescriptor* param = p_Desc.defineStringParam("name");
	param->setLabel("Name");
	param->setHint("overwrites if the same");
	param->setDefault("Matrix");
	param->setParent(*script);
	page->addChild(*param);
	}
	{
	StringParamDescriptor* param = p_Desc.defineStringParam("path");
	param->setLabel("Directory");
	param->setHint("make sure it's the absolute path");
	param->setStringType(eStringTypeFilePath);
	param->setDefault(kPluginScript);
	param->setFilePathExists(false);
	param->setParent(*script);
	page->addChild(*param);
	}
	}
}

ImageEffect* MatrixPluginFactory::createInstance(OfxImageEffectHandle p_Handle, ContextEnum /*p_Context*/)
{
    return new MatrixPlugin(p_Handle);
}

void OFX::Plugin::getPluginIDs(PluginFactoryArray& p_FactoryArray)
{
    static MatrixPluginFactory MatrixPlugin;
    p_FactoryArray.push_back(&MatrixPlugin);
}
