#ifdef _WIN64
#include <Windows.h>
#else
#include <pthread.h>
#endif
#include <map>
#include <stdio.h>
#include <cmath>

#ifdef __APPLE__
#include <OpenCL/cl.h>
#else
#include <CL/cl.h>
#endif

const char *KernelSource = "\n" \
"#define  BLOCKSIZE 4 \n" \
"__kernel void MatrixAdjustKernel(  \n" \
"   int p_Width,                                                        \n" \
"   int p_Height,                                                       \n" \
"   float p_MatrixRR,                                                      \n" \
"   float p_MatrixRG,                                                      \n" \
"   float p_MatrixRB,                                                      \n" \
"   float p_MatrixGR,                                                      \n" \
"   float p_MatrixGG,                                                      \n" \
"   float p_MatrixGB,                                                      \n" \
"   float p_MatrixBR,                                                      \n" \
"   float p_MatrixBG,                                                      \n" \
"   float p_MatrixBB,														\n" \
"	float p_Luma,                                                      \n" \
"	float p_Sat,       													\n" \
"   __global const float* p_Input,                                      \n" \
"   __global float* p_Output)                                           \n" \
"{                                                                      \n" \
"   float SRC[BLOCKSIZE]; \n" \
"   float w_MatrixRR;   \n" \
"   float w_MatrixRG;   \n" \
"   float w_MatrixRB;   \n" \
"   float w_MatrixGR;   \n" \
"   float w_MatrixGG;   \n" \
"   float w_MatrixGB;   \n" \
"   float w_MatrixBR;   \n" \
"   float w_MatrixBG;   \n" \
"   float w_MatrixBB;	\n" \
"	float w_Luma;       \n" \
"	float w_Sat;       \n" \
"	float mn1;       	\n" \
"	float Mx1;       	\n" \
"	float del_Mx1;       \n" \
"	float L1;       	\n" \
"	float Sat1;       	\n" \
"	float Y1;       	\n" \
"	float red;          \n" \
"	float green;        \n" \
"	float blue;         \n" \
"	float Y2;      		\n" \
"	float U2;      		\n" \
"	float V2;      		\n" \
"	float R1;       	\n" \
"	float G1;       	\n" \
"	float B1;       	\n" \
"	float mn2;       	\n" \
"	float Mx2;       	\n" \
"	float del_Mx2;       \n" \
"	float L2;       	\n" \
"	float del_R;       	\n" \
"	float del_G;       	\n" \
"	float del_B;       	\n" \
"	float h;       	\n" \
"	float H;       	\n" \
"	float S;       	\n" \
"	float Q;       	\n" \
"	float P;       	\n" \
"	float RH;       	\n" \
"	float RR;       	\n" \
"	float GH;       	\n" \
"	float GG;       	\n" \
"	float BH;       	\n" \
"	float BB;       	\n" \
"                                                                       \n" \
"   const int x = get_global_id(0);                                     \n" \
"   const int y = get_global_id(1);                                     \n" \
"                                                                       \n" \
"   if ((x < p_Width) && (y < p_Height))                                \n" \
"   {                                                                   \n" \
"       const int index = ((y * p_Width) + x) * BLOCKSIZE;              \n" \
"                                                                       \n" \
"      SRC[0] = p_Input[index + 0] ;    \n" \
"      SRC[1] = p_Input[index + 1] ;    \n" \
"      SRC[2] = p_Input[index + 2] ;    \n" \
"      SRC[3] = p_Input[index + 3] ;    \n" \
"      barrier(CLK_LOCAL_MEM_FENCE | CLK_GLOBAL_MEM_FENCE);   \n" \
"      w_MatrixRR   = p_MatrixRR;   \n" \
"      w_MatrixRG   = p_MatrixRG;   \n" \
"      w_MatrixRB   = p_MatrixRB;   \n" \
"      w_MatrixGR   = p_MatrixGR;   \n" \
"      w_MatrixGG   = p_MatrixGG;   \n" \
"      w_MatrixGB   = p_MatrixGB;   \n" \
"      w_MatrixBR   = p_MatrixBR;   \n" \
"      w_MatrixBG   = p_MatrixBG;   \n" \
"      w_MatrixBB   = p_MatrixBB;   \n" \
"	   w_Luma       = p_Luma;       \n" \
"	   w_Sat       = p_Sat;       	\n" \
"      barrier(CLK_LOCAL_MEM_FENCE | CLK_GLOBAL_MEM_FENCE);   \n" \
"                                                                       \n" \
"      mn1 = fmin(SRC[0], fmin(SRC[1], SRC[2]));	\n" \
"	   Mx1 = fmax(SRC[0], fmax(SRC[1], SRC[2]));    \n" \
"	   del_Mx1 = Mx1 - mn1;	\n" \
"	   L1 = (Mx1 + mn1) / 2.0f;	\n" \
"	   Sat1 = del_Mx1 == 0.0f ? 0.0f : L1 < 0.5f ? del_Mx1 / (Mx1 + mn1) : del_Mx1 / (2.0f - Mx1 - mn1);	\n" \
"	   Y1 =  SRC[0] * 0.299f + SRC[1] * 0.587f + SRC[2] * 0.114f;	\n" \
"			   \n" \
"	   red = (SRC[0] * w_MatrixRR) + (SRC[1] * w_MatrixRG) + (SRC[2] * w_MatrixRB);	\n" \
"	   green = (SRC[0] * w_MatrixGR) + (SRC[1] * w_MatrixGG) + (SRC[2] * w_MatrixGB);	\n" \
"	   blue = (SRC[0] * w_MatrixBR) + (SRC[1] * w_MatrixBG) + (SRC[2] * w_MatrixBB);	\n" \
"	   \n" \
"	   Y2 =  red * 0.299f + green * 0.587f + blue * 0.114f;	\n" \
"	   U2 =  red * -0.147f - green * 0.289f + blue * 0.436f;	\n" \
"	   V2 =  red * 0.615f - green * 0.515f - blue * 0.1f;	\n" \
"					\n" \
"	   R1 = (w_Luma != 1.0f ? Y2 : Y1) + 1.140f * V2;	\n" \
"	   G1 = (w_Luma != 1.0f ? Y2 : Y1) - 0.395f * U2 - 0.581f * V2;	\n" \
"	   B1 = (w_Luma != 1.0f ? Y2 : Y1) + 2.032f * U2;	\n" \
"                                      \n" \
"	   mn2 = fmin(R1, fmin(G1, B1));	\n" \
"	   Mx2 = fmax(R1, fmax(G1, B1));    \n" \
"	   del_Mx2 = Mx2 - mn2;	\n" \
"	   L2 = (Mx2 + mn2) / 2.0f;	\n" \
"  										\n" \
"	   del_R = ((Mx2 - R1) / 6.0f + del_Mx2 / 2.0f) / del_Mx2;	\n" \
"	   del_G = ((Mx2 - G1) / 6.0f + del_Mx2 / 2.0f) / del_Mx2;		\n" \
"	   del_B = ((Mx2 - B1) / 6.0f + del_Mx2 / 2.0f) / del_Mx2;		\n" \
"																	\n" \
"	   h = del_Mx2 == 0.0f ? 0.0f : R1 == Mx2 ? del_B - del_G : G1 == Mx2 ? 1.0f / 3.0f + 	\n" \
"	   del_R - del_B : 2.0f / 3.0f + del_G - del_R;	\n" \
"					\n" \
"	   H = h < 0.0f ? h + 1.0f : h > 1.0f ? h - 1.0f : h;		\n" \
"  					\n" \
"	   S = Sat1;		\n" \
"  						\n" \
"	   Q = L2 < 0.5f ? L2 * (1.0f + S) : L2 + S - L2 * S;		\n" \
"	   P = 2.0f * L2 - Q;			\n" \
"						\n" \
"	   RH = H + 1.0f / 3.0f < 0.0f ? H + 1.0f / 3.0f + 1.0f :		\n" \
"	   H + 1.0f / 3.0f > 1.0f ? H + 1.0f / 3.0f - 1.0f : H + 1.0f / 3.0f;		\n" \
"							\n" \
"	   RR = RH < 1.0f / 6.0f ? P + (Q - P) * 6.0f * RH : 				\n" \
"	   RH < 1.0f / 2.0f ? Q : RH < 2.0f / 3.0f ? P + (Q - P) * (2.0f / 3.0f - RH) * 6.0f : P;	\n" \
"								\n" \
"	   GH = H < 0.0f ? H + 1.0f : H > 1.0f ? H - 1.0f : H;				\n" \
"								\n" \
"	   GG = GH < 1.0f / 6.0f ? P + (Q - P) * 6.0f * GH :			\n" \
"	   GH < 1.0f / 2.0f ? Q : GH < 2.0f / 3.0f ? P + (Q - P) * (2.0f / 3.0f - GH) * 6.0f : P;	\n" \
"								\n" \
"	   BH = H - 1.0f / 3.0f < 0.0f ? H - 1.0f / 3.0f + 1.0f :			\n" \
"	   H - 1.0f / 3.0f > 1.0f ? H - 1.0f / 3.0f - 1.0f : H - 1.0f / 3.0f;		\n" \
"								\n" \
"	   BB = BH < 1.0f / 6.0f ? P + (Q - P) * 6.0f * BH :		\n" \
"	   BH < 1.0f / 2.0f ? Q : BH < 2.0f / 3.0f ? P + (Q - P) * (2.0f / 3.0f - BH) * 6.0f : P;	\n" \
"							\n" \
"	   SRC[0] = w_Sat == 1.0f ? (S == 0.0f ? L2 : RR) : R1;	\n" \
"	   SRC[1] = w_Sat == 1.0f ? (S == 0.0f ? L2 : GG) : G1;	\n" \
"	   SRC[2] = w_Sat == 1.0f ? (S == 0.0f ? L2 : BB) : B1;	\n" \
"	   									\n" \
"      p_Output[index + 0] = SRC[0];  \n" \
"      p_Output[index + 1] = SRC[1];  \n" \
"      p_Output[index + 2] = SRC[2];  \n" \
"      p_Output[index + 3] = SRC[3];  \n" \
"      barrier(CLK_LOCAL_MEM_FENCE | CLK_GLOBAL_MEM_FENCE);   \n" \
"             \n" \
"   }                                                                   \n" \
"}                                                                      \n" \
"\n";

class Locker
{
public:
	Locker()
	{
#ifdef _WIN64
		InitializeCriticalSection(&mutex);
#else
		pthread_mutex_init(&mutex, NULL);
#endif
	}

	~Locker()
	{
#ifdef _WIN64
		DeleteCriticalSection(&mutex);
#else
		pthread_mutex_destroy(&mutex);
#endif
	}

	void Lock()
	{
#ifdef _WIN64
		EnterCriticalSection(&mutex);
#else
		pthread_mutex_lock(&mutex);
#endif
	}

	void Unlock()
	{
#ifdef _WIN64
		LeaveCriticalSection(&mutex);
#else
		pthread_mutex_unlock(&mutex);
#endif
	}

private:
#ifdef _WIN64
	CRITICAL_SECTION mutex;
#else
	pthread_mutex_t mutex;
#endif
};


void CheckError(cl_int p_Error, const char* p_Msg)
{
	if (p_Error != CL_SUCCESS)
	{
		fprintf(stderr, "%s [%d]\n", p_Msg, p_Error);
	}
}


void RunOpenCLKernel(void* p_CmdQ, int p_Width, int p_Height, float* p_Matrix, float* p_Luma, float* p_Sat, const float* p_Input, float* p_Output)
{
	cl_int error;

	cl_command_queue cmdQ = static_cast<cl_command_queue>(p_CmdQ);

	// store device id and kernel per command queue (required for multi-GPU systems)
	static std::map<cl_command_queue, cl_device_id> deviceIdMap;
	static std::map<cl_command_queue, cl_kernel> kernelMap;

	static Locker locker; // simple lock to control access to the above maps from multiple threads

	locker.Lock();

	// find the device id corresponding to the command queue
	cl_device_id deviceId = NULL;
	if (deviceIdMap.find(cmdQ) == deviceIdMap.end())
	{
		error = clGetCommandQueueInfo(cmdQ, CL_QUEUE_DEVICE, sizeof(cl_device_id), &deviceId, NULL);
		CheckError(error, "Unable to get the device");

		deviceIdMap[cmdQ] = deviceId;
	}
	else
	{
		deviceId = deviceIdMap[cmdQ];
	}

//#define _DEBUG


	// find the program kernel corresponding to the command queue
	cl_kernel kernel = NULL;
	if (kernelMap.find(cmdQ) == kernelMap.end())
	{
		cl_context clContext = NULL;
		error = clGetCommandQueueInfo(cmdQ, CL_QUEUE_CONTEXT, sizeof(cl_context), &clContext, NULL);
		CheckError(error, "Unable to get the context");

		cl_program program = clCreateProgramWithSource(clContext, 1, (const char **)&KernelSource, NULL, &error);
		CheckError(error, "Unable to create program");

		error = clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
#ifdef _DEBUG
		if (error != CL_SUCCESS)
		{
			char buffer[4096];
			size_t length;
			clGetProgramBuildInfo
				(
				program,
				// valid program object
				deviceId,
				// valid device_id that executable was built
				CL_PROGRAM_BUILD_LOG,
				// indicate to retrieve build log
				sizeof(buffer),
				// size of the buffer to write log to
				buffer,
				// the actual buffer to write log to
				&length);
			// the actual size in bytes of data copied to buffer
			FILE * pFile;
			pFile = fopen("/", "w");
			if (pFile != NULL)
			{
				fprintf(pFile, "%s\n", buffer);
				//fprintf(pFile, "%s [%lu]\n", "localWorkSize 0 =", szWorkSize);
			}
			fclose(pFile);
		}
#else
		CheckError(error, "Unable to build program");
#endif

		kernel = clCreateKernel(program, "MatrixAdjustKernel", &error);
		CheckError(error, "Unable to create kernel");

		kernelMap[cmdQ] = kernel;
	}
	else
	{
		kernel = kernelMap[cmdQ];
	}

	locker.Unlock();

    int count = 0;
    error  = clSetKernelArg(kernel, count++, sizeof(int), &p_Width);
    error |= clSetKernelArg(kernel, count++, sizeof(int), &p_Height);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Matrix[0]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Matrix[1]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Matrix[2]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Matrix[3]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Matrix[4]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Matrix[5]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Matrix[6]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Matrix[7]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Matrix[8]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Luma[0]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Sat[0]);
    error |= clSetKernelArg(kernel, count++, sizeof(cl_mem), &p_Input);
    error |= clSetKernelArg(kernel, count++, sizeof(cl_mem), &p_Output);
    CheckError(error, "Unable to set kernel arguments");

    size_t localWorkSize[2], globalWorkSize[2];
    clGetKernelWorkGroupInfo(kernel, deviceId, CL_KERNEL_WORK_GROUP_SIZE, sizeof(size_t), localWorkSize, NULL);
    localWorkSize[1] = 1;
    globalWorkSize[0] = ((p_Width + localWorkSize[0] - 1) / localWorkSize[0]) * localWorkSize[0];
    globalWorkSize[1] = p_Height;

    clEnqueueNDRangeKernel(cmdQ, kernel, 2, NULL, globalWorkSize, localWorkSize, 0, NULL, NULL);
}
