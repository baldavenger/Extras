#ifndef TESTS_HPP
#define TESTS_HPP

#include "../Core.hpp"
#include <gtest/gtest.h>

using namespace SIPL;

#endif
