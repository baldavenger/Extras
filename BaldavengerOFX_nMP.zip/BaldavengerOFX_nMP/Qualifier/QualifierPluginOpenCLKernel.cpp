#ifdef _WIN64
#include <Windows.h>
#else
#include <pthread.h>
#endif
#include <map>
#include <stdio.h>
#include <cmath>

#ifdef __APPLE__
#include <OpenCL/cl.h>
#else
#include <CL/cl.h>
#endif

const char *KernelSource = "\n" \
"#define  BLOCKSIZE 4 \n" \
"__kernel void QualifierAdjustKernel(  \n" \
"   int p_Width,        \n" \
"   int p_Height,       \n" \
"   float p_QualifierA, \n" \
"   float p_QualifierB, \n" \
"   float p_QualifierC, \n" \
"   float p_QualifierD, \n" \
"   float p_QualifierE, \n" \
"   float p_QualifierF, \n" \
"   float p_QualifierG, \n" \
"   float p_QualifierH, \n" \
"   float p_QualifierI, \n" \
"   float p_QualifierJ, \n" \
"   float p_QualifierK, \n" \
"   float p_QualifierL, \n" \
"   float p_QualifierM, \n" \
"   float p_QualifierN, \n" \
"   float p_QualifierO, \n" \
"   float p_QualifierP, \n" \
"   float p_QualifierR, \n" \
"   float p_QualifierS, \n" \
"   float p_QualifierT, \n" \
"   float p_QualifierU, \n" \
"   float p_SwitchA,    \n" \
"   float p_SwitchB,    \n" \
"   float p_SwitchC,    \n" \
"   float p_SwitchD,    \n" \
"   float p_SwitchE,    \n" \
"   float p_SwitchF,    \n" \
"   float p_SwitchG,    \n" \
"   float p_SwitchH,    \n" \
"   __global const float* p_Input,  \n" \
"   __global float* p_Output)       \n" \
"{                                  \n" \
"   float SRC[BLOCKSIZE]; \n" \
"   float w_QualifierA; \n" \
"   float w_QualifierB; \n" \
"   float w_QualifierC; \n" \
"   float w_QualifierD; \n" \
"   float w_QualifierE; \n" \
"   float w_QualifierF; \n" \
"   float w_QualifierG; \n" \
"   float w_QualifierH; \n" \
"   float w_QualifierI; \n" \
"   float w_QualifierJ; \n" \
"   float w_QualifierK; \n" \
"   float w_QualifierL; \n" \
"   float w_QualifierM; \n" \
"   float w_QualifierN; \n" \
"   float w_QualifierO; \n" \
"   float w_QualifierP; \n" \
"   float w_QualifierR; \n" \
"   float w_QualifierS; \n" \
"   float w_QualifierT; \n" \
"   float w_QualifierU; \n" \
"   float w_SwitchA;    \n" \
"   float w_SwitchB;    \n" \
"   float w_SwitchC;    \n" \
"   float w_SwitchD;    \n" \
"   float w_SwitchE;    \n" \
"   float w_SwitchF;    \n" \
"   float w_SwitchG;    \n" \
"   float w_SwitchH;    \n" \
"   float luma;     \n" \
"   float lm;       \n" \
"   float L;        \n" \
"   float Mx;       \n" \
"   float mn;       \n" \
"   float C;        \n" \
"   float Ls;       \n" \
"   float S;        \n" \
"   float del_R;    \n" \
"   float del_G;    \n" \
"   float del_B;    \n" \
"   float Hr;       \n" \
"   float a;        \n" \
"   float b;        \n" \
"   float c;        \n" \
"   float d;        \n" \
"   float e;        \n" \
"   float f;        \n" \
"   float lumah;    \n" \
"   float lumal;    \n" \
"   float alphal;   \n" \
"   float alphall;  \n" \
"   float alphaL;   \n" \
"   float h;        \n" \
"   float i;        \n" \
"   float j;        \n" \
"   float k;        \n" \
"   float l;        \n" \
"   float m;        \n" \
"   float sath;     \n" \
"   float satl;     \n" \
"   float alphas;   \n" \
"   float alphass;  \n" \
"   float alphaS;   \n" \
"   float n;        \n" \
"   float o;        \n" \
"   float p;        \n" \
"   float r;        \n" \
"   float s;        \n" \
"   float t;        \n" \
"   float u;        \n" \
"   float Ha;       \n" \
"   float H;        \n" \
"   float hueh;     \n" \
"   float huel;     \n" \
"   float alphah;   \n" \
"   float alphahh;  \n" \
"   float alphaH;   \n" \
"   float g;        \n" \
"   float alphalsh; \n" \
"   float alphav;   \n" \
"   float alphaV;   \n" \
"   const int x = get_global_id(0);       \n" \
"   const int y = get_global_id(1);       \n" \
"                                         \n" \
"   if ((x < p_Width) && (y < p_Height))  \n" \
"   {        \n" \
"       const int index = ((y * p_Width) + x) * BLOCKSIZE; \n" \
"                                                          \n" \
"      SRC[0] = p_Input[index + 0];    \n" \
"      SRC[1] = p_Input[index + 1];    \n" \
"      SRC[2] = p_Input[index + 2];    \n" \
"      SRC[3] = p_Input[index + 3];    \n" \
"      w_QualifierA = p_QualifierA; \n" \
"      w_QualifierB = p_QualifierB; \n" \
"      w_QualifierC = p_QualifierC; \n" \
"      w_QualifierD = p_QualifierD; \n" \
"      w_QualifierE = p_QualifierE; \n" \
"      w_QualifierF = p_QualifierF; \n" \
"      w_QualifierG = p_QualifierG; \n" \
"      w_QualifierH = p_QualifierH; \n" \
"      w_QualifierI = p_QualifierI; \n" \
"      w_QualifierJ = p_QualifierJ; \n" \
"      w_QualifierK = p_QualifierK; \n" \
"      w_QualifierL = p_QualifierL; \n" \
"      w_QualifierM = p_QualifierM; \n" \
"      w_QualifierN = p_QualifierN; \n" \
"      w_QualifierO = p_QualifierO; \n" \
"      w_QualifierP = p_QualifierP; \n" \
"      w_QualifierR = p_QualifierR; \n" \
"      w_QualifierS = p_QualifierS; \n" \
"      w_QualifierT = p_QualifierT; \n" \
"      w_QualifierU = p_QualifierU; \n" \
"      w_SwitchA    = p_SwitchA;    \n" \
"      w_SwitchB    = p_SwitchB;    \n" \
"      w_SwitchC    = p_SwitchC;    \n" \
"      w_SwitchD    = p_SwitchD;    \n" \
"      w_SwitchE    = p_SwitchE;    \n" \
"      w_SwitchF    = p_SwitchF;    \n" \
"      w_SwitchG    = p_SwitchG;    \n" \
"      w_SwitchH    = p_SwitchH;    \n" \
"                                                             \n" \
"       luma = (SRC[0] * 0.2126f) + (SRC[1] * 0.7152f) + (SRC[2] * 0.0722f); \n" \
"       lm = fmin(luma, 1.0f);                   \n" \
"       L = fmax(lm, 0.0f);                      \n" \
"       Mx = fmax(SRC[0], fmax(SRC[1], SRC[2])); \n" \
"       mn = fmin(SRC[0], fmin(SRC[1], SRC[2])); \n" \
"       C = Mx - mn;                             \n" \
"       Ls = 0.5 * (Mx + mn);                    \n" \
"       S = C == 0.0f ? 0.0f : C / (1.0f - (2.0f * Ls - 1.0f)); \n" \
"       del_R = (((Mx - SRC[0]) / 6.0f) + (C / 2.0f)) / C;      \n" \
"       del_G = (((Mx - SRC[1]) / 6.0f) + (C / 2.0f)) / C;      \n" \
"       del_B = (((Mx - SRC[2]) / 6.0f) + (C / 2.0f)) / C;      \n" \
"       Hr = C == 0.0f ? 0.0f : (SRC[0] == Mx ? del_B - del_G : (SRC[1] == Mx ? \n" \
"          (1.0f / 3.0) + del_R - del_B : (2.0f / 3.0) + del_G - del_R));       \n" \
"       a = w_QualifierA;        \n" \
"       b = w_QualifierB;        \n" \
"       c = w_QualifierC;        \n" \
"       d = w_QualifierD;        \n" \
"       e = 1.0f / w_QualifierE; \n" \
"       f = 1.0f / w_QualifierF; \n" \
"                                \n" \
"       lumah = a == 0.0f ? 0.0f : (a - (1.0f - b) >= L ? 1.0f : (a >= L ? pow((a - L) / (1.0f - b), e) : 0.0f));   \n" \
"       lumal = d == 1.0f ? 0.0f : (d + c <= L ? 1.0f :          \n" \
"              (d <= L ? pow((L - d) / c, f) : 0.0f));          \n" \
"       alphal = lumah * lumal;  \n" \
"       alphall = (w_SwitchD == 1.0f) ? 1.0f - alphal : alphal;  \n" \
"       alphaL = (w_SwitchC == 1.0f) ? alphall : 1.0f;           \n" \
"                         \n" \
"       h = w_QualifierH; \n" \
"       i = w_QualifierI; \n" \
"       j = w_QualifierJ; \n" \
"       k = w_QualifierK; \n" \
"       l = 1.0f / w_QualifierL;  \n" \
"       m = 1.0f / w_QualifierM;  \n" \
"                                 \n" \
"       sath = h == 0.0f ? 0.0f : (h - (1.0f - i) >= S ? 1.0f : \n" \
"             (h >= S ? pow((h - S) / (1.0f - i), l) : 0.0f)); \n" \
"       satl = k == 1.0f ? 0.0f : (k + j <= S ? 1.0f :    \n" \
"             (k <= S ? pow((S - k) / j, m) : 0.0f));   \n" \
"       alphas = sath * satl;                                   \n" \
"       alphass = (w_SwitchF == 1.0f) ? 1.0f - alphas : alphas; \n" \
"       alphaS = (w_SwitchE == 1.0f) ? alphass : 1.0f;          \n" \
"                         \n" \
"       n = w_QualifierN; \n" \
"       o = w_QualifierO; \n" \
"       p = w_QualifierP; \n" \
"       r = w_QualifierR; \n" \
"       s = 1.0f / w_QualifierS;  \n" \
"       t = 1.0f / w_QualifierT;  \n" \
"       u = w_QualifierU * -1.0f; \n" \
"                                 \n" \
"       Ha = Hr == 0.0f ? 0.0f : (Hr + u > 1.0f ? Hr + u - 1.0f :    \n" \
"            (Hr + u < 0.0f ? Hr + u + 1.0f : Hr + u));      \n" \
"       H = (n == 1.0f) && (o == 1.0f) && (p == 0.0f) && (r == 0.0f) ? 1.0f : Ha; \n" \
"       hueh = n == 0.0f ? 0.0f : (n - (1.0f - o) >= H ? 1.0f :  \n" \
"              (n >= H ? pow((n - H) / (1.0f - o), s) : 0.0f)); \n" \
"       huel = r == 1.0f ? 0.0f : (r + p <= H ? 1.0f : \n" \
"              (r <= H ? pow((H - r) / p, t) : 0.0f)); \n" \
"       alphah = hueh * huel;    \n" \
"       alphahh = (w_SwitchH == 1.0f) ? 1.0f - alphah : alphah; \n" \
"       alphaH = (w_SwitchG == 1.0f) ? alphahh : 1.0f; \n" \
"       \n" \
"       g = w_QualifierG; \n" \
"       alphalsh = (alphaL * alphaS) * alphaH;      \n" \
"       alphav = alphalsh + (1.0f - alphalsh) * g;  \n" \
"       alphaV = (w_SwitchB == 1.0f) ? (1.0f - alphav) : alphav; \n" \
"             \n" \
"       SRC[0] = (w_SwitchA == 1.0f) ? alphaV : SRC[0]; \n" \
"       SRC[1] = (w_SwitchA == 1.0f) ? alphaV : SRC[1]; \n" \
"       SRC[2] = (w_SwitchA == 1.0f) ? alphaV : SRC[2]; \n" \
"       SRC[3] = (w_SwitchA == 1.0f) ? SRC[3] : alphaV; \n" \
"                                      \n" \
"       p_Output[index + 0] = SRC[0];  \n" \
"       p_Output[index + 1] = SRC[1];  \n" \
"       p_Output[index + 2] = SRC[2];  \n" \
"       p_Output[index + 3] = SRC[3];  \n" \
"       \n" \
"   } \n" \
"}    \n" \
"\n";

class Locker
{
public:
	Locker()
	{
#ifdef _WIN64
		InitializeCriticalSection(&mutex);
#else
		pthread_mutex_init(&mutex, NULL);
#endif
	}

	~Locker()
	{
#ifdef _WIN64
		DeleteCriticalSection(&mutex);
#else
		pthread_mutex_destroy(&mutex);
#endif
	}

	void Lock()
	{
#ifdef _WIN64
		EnterCriticalSection(&mutex);
#else
		pthread_mutex_lock(&mutex);
#endif
	}

	void Unlock()
	{
#ifdef _WIN64
		LeaveCriticalSection(&mutex);
#else
		pthread_mutex_unlock(&mutex);
#endif
	}

private:
#ifdef _WIN64
	CRITICAL_SECTION mutex;
#else
	pthread_mutex_t mutex;
#endif
};


void CheckError(cl_int p_Error, const char* p_Msg)
{
	if (p_Error != CL_SUCCESS)
	{
		fprintf(stderr, "%s [%d]\n", p_Msg, p_Error);
	}
}


void RunOpenCLKernel(void* p_CmdQ, int p_Width, int p_Height, float* p_Qualifier, float* p_Switch, const float* p_Input, float* p_Output)
{
	cl_int error;

	cl_command_queue cmdQ = static_cast<cl_command_queue>(p_CmdQ);

	// store device id and kernel per command queue (required for multi-GPU systems)
	static std::map<cl_command_queue, cl_device_id> deviceIdMap;
	static std::map<cl_command_queue, cl_kernel> kernelMap;

	static Locker locker; // simple lock to control access to the above maps from multiple threads

	locker.Lock();

	// find the device id corresponding to the command queue
	cl_device_id deviceId = NULL;
	if (deviceIdMap.find(cmdQ) == deviceIdMap.end())
	{
		error = clGetCommandQueueInfo(cmdQ, CL_QUEUE_DEVICE, sizeof(cl_device_id), &deviceId, NULL);
		CheckError(error, "Unable to get the device");

		deviceIdMap[cmdQ] = deviceId;
	}
	else
	{
		deviceId = deviceIdMap[cmdQ];
	}

///#define _DEBUG


	// find the program kernel corresponding to the command queue
	cl_kernel kernel = NULL;
	if (kernelMap.find(cmdQ) == kernelMap.end())
	{
		cl_context clContext = NULL;
		error = clGetCommandQueueInfo(cmdQ, CL_QUEUE_CONTEXT, sizeof(cl_context), &clContext, NULL);
		CheckError(error, "Unable to get the context");

		cl_program program = clCreateProgramWithSource(clContext, 1, (const char **)&KernelSource, NULL, &error);
		CheckError(error, "Unable to create program");

		error = clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
#ifdef _DEBUG
		if (error != CL_SUCCESS)
		{
			char buffer[4096];
			size_t length;
			clGetProgramBuildInfo
				(
				program,
				// valid program object
				deviceId,
				// valid device_id that executable was built
				CL_PROGRAM_BUILD_LOG,
				// indicate to retrieve build log
				sizeof(buffer),
				// size of the buffer to write log to
				buffer,
				// the actual buffer to write log to
				&length);
			// the actual size in bytes of data copied to buffer
			FILE * pFile;
			pFile = fopen("/", "w");
			if (pFile != NULL)
			{
				fprintf(pFile, "%s\n", buffer);
				//fprintf(pFile, "%s [%lu]\n", "localWorkSize 0 =", szWorkSize);
			}
			fclose(pFile);
		}
#else
		CheckError(error, "Unable to build program");
#endif

		kernel = clCreateKernel(program, "QualifierAdjustKernel", &error);
		CheckError(error, "Unable to create kernel");

		kernelMap[cmdQ] = kernel;
	}
	else
	{
		kernel = kernelMap[cmdQ];
	}

	locker.Unlock();

    int count = 0;
    error  = clSetKernelArg(kernel, count++, sizeof(int), &p_Width);
    error |= clSetKernelArg(kernel, count++, sizeof(int), &p_Height);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[0]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[1]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[2]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[3]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[4]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[5]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[6]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[7]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[8]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[9]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[10]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[11]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[12]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[13]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[14]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[15]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[16]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[17]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[18]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Qualifier[19]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Switch[0]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Switch[1]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Switch[2]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Switch[3]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Switch[4]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Switch[5]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Switch[6]);
    error |= clSetKernelArg(kernel, count++, sizeof(float), &p_Switch[7]); 
    error |= clSetKernelArg(kernel, count++, sizeof(cl_mem), &p_Input);
    error |= clSetKernelArg(kernel, count++, sizeof(cl_mem), &p_Output);
    CheckError(error, "Unable to set kernel arguments");

    size_t localWorkSize[2], globalWorkSize[2];
    clGetKernelWorkGroupInfo(kernel, deviceId, CL_KERNEL_WORK_GROUP_SIZE, sizeof(size_t), localWorkSize, NULL);
    localWorkSize[1] = 1;
    globalWorkSize[0] = ((p_Width + localWorkSize[0] - 1) / localWorkSize[0]) * localWorkSize[0];
    globalWorkSize[1] = p_Height;

    clEnqueueNDRangeKernel(cmdQ, kernel, 2, NULL, globalWorkSize, localWorkSize, 0, NULL, NULL);
}
