#include "QualifierPlugin.h"

#include <cstring>
#include <cmath>
#include <stdio.h>
using std::string;
#include <string> 
#include <fstream>

#include "ofxsImageEffect.h"
#include "ofxsMultiThread.h"
#include "ofxsProcessing.h"
#include "ofxsLog.h"

#ifdef __APPLE__
#define kPluginScript "/Library/Application Support/Blackmagic Design/DaVinci Resolve/LUT"
#elif defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64)
#define kPluginScript "\\ProgramData\\Blackmagic Design\\DaVinci Resolve\\Support\\LUT"
#else
#define kPluginScript "/home/resolve/LUT"
#endif

#define kPluginName "Qualifier"
#define kPluginGrouping "OpenFX Yo"
#define kPluginDescription \
"------------------------------------------------------------------------------------------------------------------ \n" \
"Qualifier: Combined Luma, Saturation, and Hue based keyer. Use eyedropper to isolate specific \n" \
"range and finetune with the controls."

#define kPluginIdentifier "OpenFX.Yo.Qualifier"
#define kPluginVersionMajor 2
#define kPluginVersionMinor 1

#define kSupportsTiles false
#define kSupportsMultiResolution false
#define kSupportsMultipleClipPARs false

////////////////////////////////////////////////////////////////////////////////

namespace {
	struct RGBValues {
		double r, g, b;
		RGBValues(double v) : r(v), g(v), b(v) {}
		RGBValues() : r(0), g(0), b(0) {}
	};
}

float RGBtoHUE(float R, float G, float B)
{

	float min = fmin(R, fmin(G, B));
	float Max = fmax(R, fmax(G, B));
	float del_Max = Max - min;

	float del_R = (((Max - R) / 6.0f) + (del_Max / 2.0f)) / del_Max;
	float del_G = (((Max - G) / 6.0f) + (del_Max / 2.0f)) / del_Max;
	float del_B = (((Max - B) / 6.0f) + (del_Max / 2.0f)) / del_Max;

	float h = del_Max == 0.0f ? 0.0f : (R == Max ? del_B - del_G : (G == Max ? (1.0f / 3.0f) + del_R - del_B : (2.0f / 3.0f) + del_G - del_R));

	float Hh = h < 0.0f ? h + 1.0f : (h > 1.0f ? h - 1.0f : h);
	return Hh;

}

float RGBtoSAT(float R, float G, float B)
{

	float mn = fmin(R, fmin(G, B));
	float Mx = fmax(R, fmax(G, B));
	float del_Max = Mx - mn;

	float Ls = 0.5 * (Mx + mn);
	float Ss = del_Max == 0.0f ? 0.0f : del_Max / (1.0f - (2.0f * Ls - 1.0f));

	return Ss;

}

float RGBtoLUM(float R, float G, float B)
{

	float lm = (R * 0.2126f) + (G * 0.7152f) + (B * 0.0722f);

	return lm;

}

class Qualifier : public OFX::ImageProcessor
{
public:
	explicit Qualifier(OFX::ImageEffect& p_Instance);

	virtual void processImagesOpenCL();
	virtual void multiThreadProcessImages(OfxRectI p_ProcWindow);

	void setSrcImg(OFX::Image* p_SrcImg);
	void setScales(float p_ScaleA, float p_ScaleB, float p_ScaleC, float p_ScaleD, float p_ScaleE, float p_ScaleF,
		float p_ScaleG, float p_ScaleH, float p_ScaleI, float p_ScaleJ, float p_ScaleK, float p_ScaleL, float p_ScaleM, float p_ScaleN,
		float p_ScaleO, float p_ScaleP, float p_ScaleR, float p_ScaleS, float p_ScaleT, float p_ScaleU, float p_SwitchA, float p_SwitchB,
		float p_SwitchC, float p_SwitchD, float p_SwitchE, float p_SwitchF, float p_SwitchG, float p_SwitchH);

private:
	OFX::Image* _srcImg;
	float _scales[20];
	float _switch[8];
};

Qualifier::Qualifier(OFX::ImageEffect& p_Instance)
	: OFX::ImageProcessor(p_Instance)
{
}

extern void RunOpenCLKernel(void* p_CmdQ, int p_Width, int p_Height, float* p_Qualifier, float* p_Switch, const float* p_Input, float* p_Output);

void Qualifier::processImagesOpenCL()
{
	const OfxRectI& bounds = _srcImg->getBounds();
	const int width = bounds.x2 - bounds.x1;
	const int height = bounds.y2 - bounds.y1;

	float* input = static_cast<float*>(_srcImg->getPixelData());
	float* output = static_cast<float*>(_dstImg->getPixelData());

	RunOpenCLKernel(_pOpenCLCmdQ, width, height, _scales, _switch, input, output);
}

void Qualifier::multiThreadProcessImages(OfxRectI p_ProcWindow)
{
	for (int y = p_ProcWindow.y1; y < p_ProcWindow.y2; ++y)
	{
		if (_effect.abort()) break;

		float* dstPix = static_cast<float*>(_dstImg->getPixelAddress(p_ProcWindow.x1, y));

		for (int x = p_ProcWindow.x1; x < p_ProcWindow.x2; ++x)
		{
			float* srcPix = static_cast<float*>(_srcImg ? _srcImg->getPixelAddress(x, y) : 0);

			// do we have a source image to scale up
			if (srcPix)
			{
				float luma = (srcPix[0] * 0.2126f) + (srcPix[1] * 0.7152f) + (srcPix[2] * 0.0722f);
				float lm = fmin(luma, 1.0f);
				float L = fmax(lm, 0.0f);
				float Mx = fmax(srcPix[0], fmax(srcPix[1], srcPix[2]));
				float mn = fmin(srcPix[0], fmin(srcPix[1], srcPix[2]));
				float C = Mx - mn;
				float Ls = 0.5 * (Mx + mn);
				float S = C == 0.0f ? 0.0f : C / (1.0f - (2.0f * Ls - 1.0f));
				float del_R = (((Mx - srcPix[0]) / 6.0f) + (C / 2.0f)) / C;
				float del_G = (((Mx - srcPix[1]) / 6.0f) + (C / 2.0f)) / C;
				float del_B = (((Mx - srcPix[2]) / 6.0f) + (C / 2.0f)) / C;
				float Hr = C == 0.0f ? 0.0f : (srcPix[0] == Mx ? del_B - del_G : (srcPix[1] == Mx ? 
					  (1.0f / 3.0f) + del_R - del_B : (2.0f / 3.0f) + del_G - del_R));

				float a = _scales[0];
				float b = _scales[1];
				float c = _scales[2];
				float d = _scales[3];
				float e = 1.0f / _scales[4];
				float f = 1.0f / _scales[5];

				float lumah = a == 0.0f ? 0.0f : (a - (1.0f - b) >= L ? 1.0f : (a >= L ? pow((a - L) / (1.0f - b), e) : 0.0f));
				float lumal = d == 1.0f ? 0.0f : (d + c <= L ? 1.0f : (d <= L ? pow((L - d) / c, f) : 0.0f));
				float alphal = lumah * lumal;
				float alphall = (_switch[3] == 1.0f) ? 1.0f - alphal : alphal;
				float alphaL = (_switch[2] == 1.0f) ? alphall : 1.0f;

				float h = _scales[7];
				float i = _scales[8];
				float j = _scales[9];
				float k = _scales[10];
				float l = 1.0f / _scales[11];
				float m = 1.0f / _scales[12];

				float sath = h == 0.0f ? 0.0f : (h - (1.0f - i) >= S ? 1.0f : (h >= S ? pow((h - S) / (1.0f - i), l) : 0.0f));
				float satl = k == 1.0f ? 0.0f : (k + j <= S ? 1.0f : (k <= S ? pow((S - k) / j, m) : 0.0f));
				float alphas = sath * satl;
				float alphass = (_switch[5] == 1.0f) ? 1.0f - alphas : alphas;
				float alphaS = (_switch[4] == 1.0f) ? alphass : 1.0f;

				float n = _scales[13];
				float o = _scales[14];
				float p = _scales[15];
				float r = _scales[16];
				float s = 1.0f / _scales[17];
				float t = 1.0f / _scales[18];
				float u = _scales[19] * -1.0f;

				float Ha = Hr == 0.0f ? 0.0f : (Hr + u > 1.0f ? Hr + u - 1.0f : (Hr + u < 0.0f ? Hr + u + 1.0f : Hr + u));
				float H = (n == 1.0f) && (o == 1.0f) && (p == 0.0f) && (r == 0.0f) ? 1.0f : Ha;
				float hueh = n == 0.0f ? 0.0f : (n - (1.0f - o) >= H ? 1.0f : (n >= H ? pow((n - H) / (1.0f - o), s) : 0.0f));
				float huel = r == 1.0f ? 0.0f : (r + p <= H ? 1.0f : (r <= H ? pow((H - r) / p, t) : 0.0f));
				float alphah = hueh * huel;
				float alphahh = (_switch[7] == 1.0f) ? 1.0f - alphah : alphah;
				float alphaH = (_switch[6] == 1.0f) ? alphahh : 1.0f;

				float g = _scales[6];
				float alphalsh = (alphaL * alphaS) * alphaH;
				float alphav = alphalsh + (1.0f - alphalsh) * g;
				float alphaV = (_switch[1] == 1.0f) ? (1.0f - (alphav)) : (alphav);

				dstPix[0] = (_switch[0] == 1.0f) ? alphaV : srcPix[0];
				dstPix[1] = (_switch[0] == 1.0f) ? alphaV : srcPix[1];
				dstPix[2] = (_switch[0] == 1.0f) ? alphaV : srcPix[2];
				dstPix[3] = (_switch[0] == 1.0f) ? srcPix[3] : alphaV;
			}
			else
			{
				// no src pixel here, be black and transparent
				for (int c = 0; c < 4; ++c)
				{
					dstPix[c] = 0.0f;
				}
			}
			// increment the dst pixel
			dstPix += 4;
		}
	}
}


void Qualifier::setSrcImg(OFX::Image* p_SrcImg)
{
	_srcImg = p_SrcImg;
}

void Qualifier::setScales(float p_ScaleA, float p_ScaleB, float p_ScaleC, float p_ScaleD, float p_ScaleE, float p_ScaleF,
	float p_ScaleG, float p_ScaleH, float p_ScaleI, float p_ScaleJ, float p_ScaleK, float p_ScaleL, float p_ScaleM, float p_ScaleN,
	float p_ScaleO, float p_ScaleP, float p_ScaleR, float p_ScaleS, float p_ScaleT, float p_ScaleU, float p_SwitchA, float p_SwitchB,
	float p_SwitchC, float p_SwitchD, float p_SwitchE, float p_SwitchF, float p_SwitchG, float p_SwitchH)
{
	_scales[0] = p_ScaleA;
	_scales[1] = p_ScaleB;
	_scales[2] = p_ScaleC;
	_scales[3] = p_ScaleD;
	_scales[4] = p_ScaleE;
	_scales[5] = p_ScaleF;
	_scales[6] = p_ScaleG;
	_scales[7] = p_ScaleH;
	_scales[8] = p_ScaleI;
	_scales[9] = p_ScaleJ;
	_scales[10] = p_ScaleK;
	_scales[11] = p_ScaleL;
	_scales[12] = p_ScaleM;
	_scales[13] = p_ScaleN;
	_scales[14] = p_ScaleO;
	_scales[15] = p_ScaleP;
	_scales[16] = p_ScaleR;
	_scales[17] = p_ScaleS;
	_scales[18] = p_ScaleT;
	_scales[19] = p_ScaleU;

	_switch[0] = p_SwitchA;
	_switch[1] = p_SwitchB;
	_switch[2] = p_SwitchC;
	_switch[3] = p_SwitchD;
	_switch[4] = p_SwitchE;
	_switch[5] = p_SwitchF;
	_switch[6] = p_SwitchG;
	_switch[7] = p_SwitchH;
}

////////////////////////////////////////////////////////////////////////////////
/** @brief The plugin that does our work */
class QualifierPlugin : public OFX::ImageEffect
{
public:
	explicit QualifierPlugin(OfxImageEffectHandle p_Handle);

	/* Override the render */
	virtual void render(const OFX::RenderArguments& p_Args);

	/* Override is identity */
	virtual bool isIdentity(const OFX::IsIdentityArguments& p_Args, OFX::Clip*& p_IdentityClip, double& p_IdentityTime);

	/* Override changedParam */
	virtual void changedParam(const OFX::InstanceChangedArgs& p_Args, const std::string& p_ParamName);

	/* Set up and run a processor */
	void setupAndProcess(Qualifier &p_Qualifier, const OFX::RenderArguments& p_Args);

private:
	// Does not own the following pointers
	OFX::Clip* m_DstClip;
	OFX::Clip* m_SrcClip;

	OFX::RGBParam *m_Sample;
	OFX::DoubleParam* m_ScaleA;
	OFX::DoubleParam* m_ScaleB;
	OFX::DoubleParam* m_ScaleC;
	OFX::DoubleParam* m_ScaleD;
	OFX::DoubleParam* m_ScaleE;
	OFX::DoubleParam* m_ScaleF;
	OFX::DoubleParam* m_ScaleG;
	OFX::DoubleParam* m_ScaleH;
	OFX::DoubleParam* m_ScaleI;
	OFX::DoubleParam* m_ScaleJ;
	OFX::DoubleParam* m_ScaleK;
	OFX::DoubleParam* m_ScaleL;
	OFX::DoubleParam* m_ScaleM;
	OFX::DoubleParam* m_ScaleN;
	OFX::DoubleParam* m_ScaleO;
	OFX::DoubleParam* m_ScaleP;
	OFX::DoubleParam* m_ScaleR;
	OFX::DoubleParam* m_ScaleS;
	OFX::DoubleParam* m_ScaleT;
	OFX::DoubleParam* m_ScaleU;
	OFX::BooleanParam* m_SwitchA;
	OFX::BooleanParam* m_SwitchB;
	OFX::BooleanParam* m_SwitchC;
	OFX::BooleanParam* m_SwitchD;
	OFX::BooleanParam* m_SwitchE;
	OFX::BooleanParam* m_SwitchF;
	OFX::BooleanParam* m_SwitchG;
	OFX::BooleanParam* m_SwitchH;
	OFX::StringParam* m_Path;
    OFX::StringParam* m_Name;
    OFX::PushButtonParam* m_Info;
	OFX::PushButtonParam* m_Button1;
	OFX::PushButtonParam* m_Button2;
};

QualifierPlugin::QualifierPlugin(OfxImageEffectHandle p_Handle)
	: ImageEffect(p_Handle)
{
	m_DstClip = fetchClip(kOfxImageEffectOutputClipName);
	m_SrcClip = fetchClip(kOfxImageEffectSimpleSourceClipName);

	m_Sample = fetchRGBParam("sample");
	m_ScaleA = fetchDoubleParam("ScaleA");
	m_ScaleB = fetchDoubleParam("ScaleB");
	m_ScaleC = fetchDoubleParam("ScaleC");
	m_ScaleD = fetchDoubleParam("ScaleD");
	m_ScaleE = fetchDoubleParam("ScaleE");
	m_ScaleF = fetchDoubleParam("ScaleF");
	m_ScaleG = fetchDoubleParam("ScaleG");
	m_ScaleH = fetchDoubleParam("ScaleH");
	m_ScaleI = fetchDoubleParam("ScaleI");
	m_ScaleJ = fetchDoubleParam("ScaleJ");
	m_ScaleK = fetchDoubleParam("ScaleK");
	m_ScaleL = fetchDoubleParam("ScaleL");
	m_ScaleM = fetchDoubleParam("ScaleM");
	m_ScaleN = fetchDoubleParam("ScaleN");
	m_ScaleO = fetchDoubleParam("ScaleO");
	m_ScaleP = fetchDoubleParam("ScaleP");
	m_ScaleR = fetchDoubleParam("ScaleR");
	m_ScaleS = fetchDoubleParam("ScaleS");
	m_ScaleT = fetchDoubleParam("ScaleT");
	m_ScaleU = fetchDoubleParam("ScaleU");
	m_SwitchA = fetchBooleanParam("display");
	m_SwitchB = fetchBooleanParam("invertAlpha");
	m_SwitchC = fetchBooleanParam("lumaOff");
	m_SwitchD = fetchBooleanParam("invertAlphaL");
	m_SwitchE = fetchBooleanParam("satOff");
	m_SwitchF = fetchBooleanParam("invertAlphaS");
	m_SwitchG = fetchBooleanParam("hueOff");
	m_SwitchH = fetchBooleanParam("invertAlphaH");
	m_Path = fetchStringParam("path");
	m_Name = fetchStringParam("name");
	m_Info = fetchPushButtonParam("info");
	m_Button1 = fetchPushButtonParam("button1");
	m_Button2 = fetchPushButtonParam("button2");

}

void QualifierPlugin::render(const OFX::RenderArguments& p_Args)
{
	if ((m_DstClip->getPixelDepth() == OFX::eBitDepthFloat) && (m_DstClip->getPixelComponents() == OFX::ePixelComponentRGBA))
	{
		Qualifier qualifier(*this);
		setupAndProcess(qualifier, p_Args);
	}
	else
	{
		OFX::throwSuiteStatusException(kOfxStatErrUnsupported);
	}
}

bool QualifierPlugin::isIdentity(const OFX::IsIdentityArguments& p_Args, OFX::Clip*& p_IdentityClip, double& p_IdentityTime)
{

	double aScale = m_ScaleA->getValueAtTime(p_Args.time);
	double bScale = m_ScaleB->getValueAtTime(p_Args.time);
	double cScale = m_ScaleC->getValueAtTime(p_Args.time);
	double dScale = m_ScaleD->getValueAtTime(p_Args.time);
	double eScale = m_ScaleE->getValueAtTime(p_Args.time);
	double fScale = m_ScaleF->getValueAtTime(p_Args.time);
	double gScale = m_ScaleG->getValueAtTime(p_Args.time);
	double hScale = m_ScaleH->getValueAtTime(p_Args.time);
	double iScale = m_ScaleI->getValueAtTime(p_Args.time);
	double jScale = m_ScaleJ->getValueAtTime(p_Args.time);
	double kScale = m_ScaleK->getValueAtTime(p_Args.time);
	double lScale = m_ScaleL->getValueAtTime(p_Args.time);
	double mScale = m_ScaleM->getValueAtTime(p_Args.time);
	double nScale = m_ScaleN->getValueAtTime(p_Args.time);
	double oScale = m_ScaleO->getValueAtTime(p_Args.time);
	double pScale = m_ScaleP->getValueAtTime(p_Args.time);
	double rScale = m_ScaleR->getValueAtTime(p_Args.time);
	double sScale = m_ScaleS->getValueAtTime(p_Args.time);
	double tScale = m_ScaleT->getValueAtTime(p_Args.time);

	if ((aScale == 1.0f) && (bScale == 1.0f) && (cScale == 0.0f) && (dScale == 0.0f) && (eScale == 1.0f) && (fScale == 1.0f) && (gScale == 0.0f) &&
		(hScale == 1.0f) && (iScale == 1.0f) && (jScale == 0.0f) && (kScale == 0.0f) && (lScale == 1.0f) && (mScale == 1.0f) &&
		(nScale == 1.0f) && (oScale == 1.0f) && (pScale == 0.0f) && (rScale == 0.0f) && (sScale == 1.0f) && (tScale == 1.0f))
	{
		p_IdentityClip = m_SrcClip;
		p_IdentityTime = p_Args.time;
		return true;
	}

	return false;
}

void QualifierPlugin::changedParam(const OFX::InstanceChangedArgs& p_Args, const std::string& p_ParamName)
{

	if(p_ParamName == "info")
    {
	
	sendMessage(OFX::Message::eMessageMessage, "", string(kPluginDescription));
	
	}
	
	if(p_ParamName == "button1")
    {
	
	float lumahigh = m_ScaleA->getValueAtTime(p_Args.time);
	float lumahighfade = m_ScaleB->getValueAtTime(p_Args.time);
	float lumalowfade = m_ScaleC->getValueAtTime(p_Args.time);
	float lumalow = m_ScaleD->getValueAtTime(p_Args.time);
	float lumahighfadecurve = m_ScaleE->getValueAtTime(p_Args.time);
	float lumalowfadecurve = m_ScaleF->getValueAtTime(p_Args.time);
	float sathigh = m_ScaleH->getValueAtTime(p_Args.time);
	float sathighfade = m_ScaleI->getValueAtTime(p_Args.time);
	float satlowfade = m_ScaleJ->getValueAtTime(p_Args.time);
	float satlow = m_ScaleK->getValueAtTime(p_Args.time);
	float sathighfadecurve = m_ScaleL->getValueAtTime(p_Args.time);
	float satlowfadecurve = m_ScaleM->getValueAtTime(p_Args.time);
	float huehigh = m_ScaleN->getValueAtTime(p_Args.time);
	float huehighfade = m_ScaleO->getValueAtTime(p_Args.time);
	float huelowfade = m_ScaleP->getValueAtTime(p_Args.time);
	float huelow = m_ScaleR->getValueAtTime(p_Args.time);
	float huehighfadecurve = m_ScaleS->getValueAtTime(p_Args.time);
	float huelowfadecurve = m_ScaleT->getValueAtTime(p_Args.time);
	float huerotate = m_ScaleU->getValueAtTime(p_Args.time);
	float mix = m_ScaleG->getValueAtTime(p_Args.time);

	bool aSwitch = m_SwitchA->getValueAtTime(p_Args.time);
	bool bSwitch = m_SwitchB->getValueAtTime(p_Args.time);
	bool cSwitch = m_SwitchC->getValueAtTime(p_Args.time);
	bool dSwitch = m_SwitchD->getValueAtTime(p_Args.time);
	bool eSwitch = m_SwitchE->getValueAtTime(p_Args.time);
	bool fSwitch = m_SwitchF->getValueAtTime(p_Args.time);
	bool gSwitch = m_SwitchG->getValueAtTime(p_Args.time);
	bool hSwitch = m_SwitchH->getValueAtTime(p_Args.time);

	int display = aSwitch ? 1 : 0;
	int maininvert = bSwitch ? 1 : 0;
	int offluma = cSwitch ? 1 : 0;
	int lumainvert = dSwitch ? 1 : 0;
	int offsat = eSwitch ? 1 : 0;
	int satinvert = fSwitch ? 1 : 0;
	int offhue = gSwitch ? 1 : 0;
	int hueinvert = hSwitch ? 1 : 0;
	
	string PATH;
	m_Path->getValue(PATH);
	
	string NAME;
	m_Name->getValue(NAME);
	
	OFX::Message::MessageReplyEnum reply = sendMessage(OFX::Message::eMessageQuestion, "", "Save " + NAME + ".dctl to " + PATH + "?");
	if (reply == OFX::Message::eMessageReplyYes) {
	
	FILE * pFile;
	
	pFile = fopen ((PATH + "/" + NAME + ".dctl").c_str(), "w");
	if (pFile != NULL) {
    	
	fprintf (pFile, "// QualifierPlugin DCTL export\n" \
	"\n" \
	"__DEVICE__ float3 transform(int p_Width, int p_Height, int p_X, int p_Y, float p_R, float p_G, float p_B)\n" \
	"{\n" \
	"    \n" \
	"    // switches for display matte, invert main alpha\n" \
	"	int display = %d;\n" \
	"	bool DisplayMatte = display == 1;\n" \
	"	int maininvert = %d;\n" \
	"	bool MainInvertAlpha = maininvert == 1;\n" \
	"\n" \
	"	// switches for luma matte enable, invert alpha\n" \
	"	int lumamatte = %d;\n" \
	"	bool LumaMatte = lumamatte == 1;\n" \
	"	int lumainvert = %d;\n" \
	"	bool LumaInvertAlpha = lumainvert == 1;\n" \
	"\n" \
	"	// switches for saturation matte enable, invert alpha\n" \
	"	int satmatte = %d;\n" \
	"	bool SatMatte = satmatte == 1;\n" \
	"	int satinvert = %d;\n" \
	"	bool SatInvertAlpha = satinvert == 1;\n" \
	"\n" \
	"	// switches for hue matte enable, invert alpha\n" \
	"	int huematte = %d;\n" \
	"	bool HueMatte = huematte == 1;\n" \
	"	int hueinvert = %d;\n" \
	"	bool HueInvertAlpha = hueinvert == 1;\n" \
	"\n" \
	"    \n" \
	"    float luma = (p_R * 0.2126f) + (p_G * 0.7152f) + (p_B * 0.0722f);\n" \
	"    float lm = _fminf(luma, 1.0f);									\n" \
	"    float L = _fmaxf(lm, 0.0f);\n" \
	"    \n" \
	"    float Mx = _fmaxf(p_R, _fmaxf(p_G, p_B));				\n" \
	"	float mn = _fminf(p_R, _fminf(p_G, p_B));	 		\n" \
	"	float del_Max = Mx - mn;\n" \
	"												\n" \
	"	float Ls = 0.5f * (Mx + mn);													\n" \
	"	float S = del_Max == 0.0f ? 0.0f : del_Max / (1.0f - (2.0f * Ls - 1.0f));\n" \
	"	\n" \
	"	float del_R = (((Mx - p_R) / 6.0f) + (del_Max / 2.0f)) / del_Max;\n" \
	"    float del_G = (((Mx - p_G) / 6.0f) + (del_Max / 2.0f)) / del_Max;\n" \
	"    float del_B = (((Mx - p_B) / 6.0f) + (del_Max / 2.0f)) / del_Max;\n" \
	"    \n" \
	"    float h = del_Max == 0.0f ? 0.0f : (p_R == Mx ? del_B - del_G : (p_G == Mx ? \n" \
	"    (1.0f / 3.0f) + del_R - del_B : (2.0f / 3.0f) + del_G - del_R));\n" \
	"    \n" \
	"    // luma matte parameter values\n" \
	"	float lumahigh = %ff;\n" \
	"	float lumahighfade = %ff;\n" \
	"	float lumalowfade = %ff;\n" \
	"	float lumalow = %ff;\n" \
	"	float lumahighfadecurve = %ff;\n" \
	"	float lumalowfadecurve = %ff;\n" \
	"	\n" \
	"	float lumahighalpha = lumahigh + L == 0.0f ? 0.0f : lumahigh - (1.0f - lumahighfade) >= L ? 1.0f : (lumahigh >= L ? _powf((lumahigh - L) / (1.0f - lumahighfade), lumahighfadecurve) : 0.0f);\n" \
	"	float lumalowalpha = lumalow + L == 2.0f ? 0.0f : lumalow + lumalowfade <= L ? 1.0f : (lumalow <= L ? _powf((L - lumalow) / lumalowfade, lumalowfadecurve) : 0.0f);\n" \
	"	float alphal = lumahighalpha * lumalowalpha;\n" \
	"	float alphall = LumaInvertAlpha ? 1.0f - alphal : alphal;		\n" \
	"    float alphaLuma = LumaMatte ? alphall : 1.0f;\n" \
	"	\n" \
	"	// saturation matte parameter values\n" \
	"	float sathigh = %ff;\n" \
	"	float sathighfade = %ff;\n" \
	"	float satlowfade = %ff;\n" \
	"	float satlow = %ff;\n" \
	"	float sathighfadecurve = %ff;\n" \
	"	float satlowfadecurve = %ff;\n" \
	"	\n" \
	"	float sathighalpha = sathigh + S == 0.0f ? 0.0f : sathigh - (1.0f - sathighfade) >= S ? 1.0f : (sathigh >= S ? _powf((sathigh - S) / (1.0f - sathighfade), sathighfadecurve) : 0.0f);\n" \
	"	float satlowalpha = satlow + S == 2.0f ? 0.0f : satlow + satlowfade <= S ? 1.0f : (satlow <= S ? _powf((S - satlow) / satlowfade, satlowfadecurve) : 0.0f);\n" \
	"	float alphas = sathighalpha * satlowalpha;\n" \
	"	float alphass = SatInvertAlpha ? 1.0f - alphas : alphas;		\n" \
	"    float alphaSat = SatMatte ? alphass : 1.0f;\n" \
	"    \n" \
	"    // hue matte parameter values\n" \
	"	float huehigh = %ff;\n" \
	"	float huehighfade = %ff;\n" \
	"	float huelowfade = %ff;\n" \
	"	float huelow = %ff;\n" \
	"	float huehighfadecurve = %ff;\n" \
	"	float huelowfadecurve = %ff;\n" \
	"	float hueoffset = %ff * -1.0f;\n" \
	"	\n" \
	"	float Ha = h == 0.0f ? 0.0f : (h + hueoffset > 1.0f ? h + hueoffset - 1.0f : (h + hueoffset < 0.0f ? h + hueoffset + 1.0f : h + hueoffset));\n" \
	"    float H = (huehigh == 1.0f) && (huehighfade == 1.0f) && (huelowfade == 0.0f) && (huelow == 0.0f) ? 1.0f : Ha;\n" \
	"	\n" \
	"	float huehighalpha = huehigh + H == 0.0f ? 0.0f : huehigh - (1.0f - huehighfade) >= H ? 1.0f : (huehigh >= H ? _powf((huehigh - H) / (1.0f - huehighfade), huehighfadecurve) : 0.0f);\n" \
	"	float huelowalpha = huelow + H == 2.0f ? 0.0f : huelow + huelowfade <= H ? 1.0f : (huelow <= H ? _powf((H - huelow) / huelowfade, huelowfadecurve) : 0.0f);\n" \
	"	float alphah = huehighalpha * huelowalpha;\n" \
	"	float alphahh = HueInvertAlpha ? 1.0f - alphah : alphah;		\n" \
	"    float alphaHue = HueMatte ? alphahh : 1.0f;\n" \
	"    \n" \
	"	float MIX = %ff;	\n" \
	"								\n" \
	"	float alphaLSH = (alphaLuma * alphaSat) * alphaHue;				\n" \
	"	float alphav = alphaLSH + (1.0f - alphaLSH) * MIX;				\n" \
	"	float alphaV = MainInvertAlpha ? (1.0 - alphav) : alphav;\n" \
	"	\n" \
	"	float r = DisplayMatte ? alphaV : p_R;\n" \
	"	float g = DisplayMatte ? alphaV : p_G;\n" \
	"	float b = DisplayMatte ? alphaV : p_B;\n" \
	"\n" \
	"    return make_float3(r, g, b);\n" \
	"}\n", display, maininvert, offluma, lumainvert, offsat, satinvert, offhue, hueinvert,
	lumahigh, lumahighfade, lumalowfade, lumalow, lumahighfadecurve, lumalowfadecurve, 
	sathigh, sathighfade, satlowfade, satlow, sathighfadecurve, satlowfadecurve, 
	huehigh, huehighfade, huelowfade, huelow, huehighfadecurve, huelowfadecurve, huerotate, mix);
	fclose (pFile);
	} else {
     sendMessage(OFX::Message::eMessageError, "", string("Error: Cannot save " + NAME + ".dctl to " + PATH  + ". Check Permissions."));
	}	
	}
	}

	if(p_ParamName == "button2")
    {
    
    float lumahigh = m_ScaleA->getValueAtTime(p_Args.time);
	float lumahighfade = m_ScaleB->getValueAtTime(p_Args.time);
	float lumalowfade = m_ScaleC->getValueAtTime(p_Args.time);
	float lumalow = m_ScaleD->getValueAtTime(p_Args.time);
	float lumahighfadecurve = m_ScaleE->getValueAtTime(p_Args.time);
	float lumalowfadecurve = m_ScaleF->getValueAtTime(p_Args.time);
	float sathigh = m_ScaleH->getValueAtTime(p_Args.time);
	float sathighfade = m_ScaleI->getValueAtTime(p_Args.time);
	float satlowfade = m_ScaleJ->getValueAtTime(p_Args.time);
	float satlow = m_ScaleK->getValueAtTime(p_Args.time);
	float sathighfadecurve = m_ScaleL->getValueAtTime(p_Args.time);
	float satlowfadecurve = m_ScaleM->getValueAtTime(p_Args.time);
	float huehigh = m_ScaleN->getValueAtTime(p_Args.time);
	float huehighfade = m_ScaleO->getValueAtTime(p_Args.time);
	float huelowfade = m_ScaleP->getValueAtTime(p_Args.time);
	float huelow = m_ScaleR->getValueAtTime(p_Args.time);
	float huehighfadecurve = m_ScaleS->getValueAtTime(p_Args.time);
	float huelowfadecurve = m_ScaleT->getValueAtTime(p_Args.time);
	float huerotate = m_ScaleU->getValueAtTime(p_Args.time);
	float mix = m_ScaleG->getValueAtTime(p_Args.time);

	bool aSwitch = m_SwitchA->getValueAtTime(p_Args.time);
	bool bSwitch = m_SwitchB->getValueAtTime(p_Args.time);
	bool cSwitch = m_SwitchC->getValueAtTime(p_Args.time);
	bool dSwitch = m_SwitchD->getValueAtTime(p_Args.time);
	bool eSwitch = m_SwitchE->getValueAtTime(p_Args.time);
	bool fSwitch = m_SwitchF->getValueAtTime(p_Args.time);
	bool gSwitch = m_SwitchG->getValueAtTime(p_Args.time);
	bool hSwitch = m_SwitchH->getValueAtTime(p_Args.time);

	int display = aSwitch ? 1 : 0;
	int maininvert = bSwitch ? 1 : 0;
	int offluma = cSwitch ? 1 : 0;
	int lumainvert = dSwitch ? 1 : 0;
	int offsat = eSwitch ? 1 : 0;
	int satinvert = fSwitch ? 1 : 0;
	int offhue = gSwitch ? 1 : 0;
	int hueinvert = hSwitch ? 1 : 0;
	
	string PATH;
	m_Path->getValue(PATH);
	
	string NAME;
	m_Name->getValue(NAME);
	
	OFX::Message::MessageReplyEnum reply = sendMessage(OFX::Message::eMessageQuestion, "", "Save " + NAME + ".nk to " + PATH + "?");
	if (reply == OFX::Message::eMessageReplyYes) {
	
	FILE * pFile;
	
	pFile = fopen ((PATH + "/" + NAME + ".nk").c_str(), "w");
	if (pFile != NULL) {
    	
	fprintf (pFile, "Group {\n" \
	" inputs 0\n" \
	" name Qualifier\n" \
	" xpos -203\n" \
	" ypos 47\n" \
	"}\n" \
	" Input {\n" \
	"  inputs 0\n" \
	"  name Input1\n" \
	"  xpos -268\n" \
	"  ypos -123\n" \
	" }\n" \
	"set N25c6ba70 [stack 0]\n" \
	" Group {\n" \
	"  name LumaKey\n" \
	"  xpos -353\n" \
	"  ypos 5\n" \
	" }\n" \
	"  Input {\n" \
	"   inputs 0\n" \
	"   name Input1\n" \
	"   xpos -432\n" \
	"   ypos 338\n" \
	"  }\n" \
	"set N25c765c0 [stack 0]\n" \
	"  Expression {\n" \
	"   temp_name0 high\n" \
	"   temp_expr0 %f\n" \
	"   temp_name1 highfade\n" \
	"   temp_expr1 %f\n" \
	"   temp_name2 highfadecurve\n" \
	"   temp_expr2 %f\n" \
	"   temp_name3 n\n" \
	"   temp_expr3 \"max(min((r * 0.2126 + g * 0.7152 + b * 0.0722), 1.0), 0.0)\"\n" \
	"   expr0 \"high + n == 0.0 ? 0.0 : high - (1.0 - highfade) >= n ? 1.0 : (high >= n ? pow((high - n) / (1.0 - highfade), highfadecurve) : 0.0)\"\n" \
	"   expr1 0\n" \
	"   expr2 0\n" \
	"   name highalpha\n" \
	"   xpos -498\n" \
	"   ypos 377\n" \
	"  }\n" \
	"push $N25c765c0\n" \
	"  Expression {\n" \
	"   temp_name0 low\n" \
	"   temp_expr0 %f\n" \
	"   temp_name1 lowfade\n" \
	"   temp_expr1 %f\n" \
	"   temp_name2 lowfadecurve\n" \
	"   temp_expr2 %f\n" \
	"   temp_name3 n\n" \
	"   temp_expr3 \"max(min((r * 0.2126 + g * 0.7152 + b * 0.0722), 1.0), 0.0)\"\n" \
	"   expr0 \"low + n == 2.0 ? 0.0 : low + lowfade <= n ? 1.0 : (low <= n ? pow((n - low) / lowfade, lowfadecurve) : 0.0)\"\n" \
	"   expr1 0\n" \
	"   expr2 0\n" \
	"   name lowalpha\n" \
	"   xpos -365\n" \
	"   ypos 383\n" \
	"  }\n" \
	"  MergeExpression {\n" \
	"   inputs 2\n" \
	"   expr0 \"Ar * Br\"\n" \
	"   expr1 \"Ar * Br\"\n" \
	"   expr2 \"Ar * Br\"\n" \
	"   name LumaAlpha\n" \
	"   xpos -498\n" \
	"   ypos 432\n" \
	"  }\n" \
	"set N25c93e00 [stack 0]\n" \
	"  Expression {\n" \
	"   expr0 \"1.0 - r\"\n" \
	"   expr1 \"1.0 - r\"\n" \
	"   expr2 \"1.0 - r\"\n" \
	"   name invertAlpha\n" \
	"   xpos -555\n" \
	"   ypos 490\n" \
	"  }\n" \
	"push $N25c93e00\n" \
	"  Switch {\n" \
	"   inputs 2\n" \
	"   which %d\n" \
	"   name InvertSwitch\n" \
	"   xpos -498\n" \
	"   ypos 542\n" \
	"  }\n" \
	"  Expression {\n" \
	"   inputs 0\n" \
	"   expr0 1.0\n" \
	"   expr1 1.0\n" \
	"   expr2 1.0\n" \
	"   name white\n" \
	"   xpos -385\n" \
	"   ypos 510\n" \
	"  }\n" \
	"  Switch {\n" \
	"   inputs 2\n" \
	"   which %d\n" \
	"   name Display_LumaKey\n" \
	"   xpos -432\n" \
	"   ypos 582\n" \
	"  }\n" \
	"  Output {\n" \
	"   name Output1\n" \
	"   xpos -432\n" \
	"   ypos 615\n" \
	"  }\n" \
	" end_group\n" \
	"push $N25c6ba70\n" \
	" Group {\n" \
	"  name SaturationKey\n" \
	"  xpos -268\n" \
	"  ypos 4\n" \
	" }\n" \
	"  Input {\n" \
	"   inputs 0\n" \
	"   name Input1\n" \
	"   xpos -386\n" \
	"   ypos 268\n" \
	"  }\n" \
	"  Colorspace {\n" \
	"   colorspace_in sRGB\n" \
	"   colorspace_out HSL\n" \
	"   name RGB_to_HSL\n" \
	"   xpos -466\n" \
	"   ypos 311\n" \
	"  }\n" \
	"set N223e5a20 [stack 0]\n" \
	"  Expression {\n" \
	"   temp_name0 high\n" \
	"   temp_expr0 %f\n" \
	"   temp_name1 highfade\n" \
	"   temp_expr1 %f\n" \
	"   temp_name2 highfadecurve\n" \
	"   temp_expr2 %f\n" \
	"   temp_name3 n\n" \
	"   temp_expr3 \"g == 0.0 ? 0.0 : max(min(g, 1.0), 0.0)\"\n" \
	"   expr0 \"high + n == 0.0 ? 0.0 : high - (1.0 - highfade) >= n ? 1.0 : (high >= n ? pow((high - n) / (1.0 - highfade), highfadecurve) : 0.0)\"\n" \
	"   expr1 0\n" \
	"   expr2 0\n" \
	"   name highalpha\n" \
	"   xpos -524\n" \
	"   ypos 378\n" \
	"  }\n" \
	"push $N223e5a20\n" \
	"  Expression {\n" \
	"   temp_name0 low\n" \
	"   temp_expr0 %f\n" \
	"   temp_name1 lowfade\n" \
	"   temp_expr1 %f\n" \
	"   temp_name2 lowfadecurve\n" \
	"   temp_expr2 %f\n" \
	"   temp_name3 n\n" \
	"   temp_expr3 \"g == 0.0 ? 0.0 : max(min(g, 1.0), 0.0)\"\n" \
	"   expr0 \"low + n == 2.0 ? 0.0 : low + lowfade <= n ? 1.0 : (low <= n ? pow((n - low) / lowfade, lowfadecurve) : 0.0)\"\n" \
	"   expr1 0\n" \
	"   expr2 0\n" \
	"   name lowalpha\n" \
	"   xpos -444\n" \
	"   ypos 353\n" \
	"  }\n" \
	"  MergeExpression {\n" \
	"   inputs 2\n" \
	"   expr0 \"Ar * Br\"\n" \
	"   expr1 \"Ar * Br\"\n" \
	"   expr2 \"Ar * Br\"\n" \
	"   name SatAlpha\n" \
	"   xpos -444\n" \
	"   ypos 411\n" \
	"  }\n" \
	"set N223b5050 [stack 0]\n" \
	"  Expression {\n" \
	"   expr0 \"1.0 - r\"\n" \
	"   expr1 \"1.0 - r\"\n" \
	"   expr2 \"1.0 - r\"\n" \
	"   name invertAlpha\n" \
	"   xpos -508\n" \
	"   ypos 451\n" \
	"  }\n" \
	"push $N223b5050\n" \
	"  Switch {\n" \
	"   inputs 2\n" \
	"   which %d\n" \
	"   name InvertSwitch\n" \
	"   xpos -444\n" \
	"   ypos 492\n" \
	"  }\n" \
	"  Expression {\n" \
	"   inputs 0\n" \
	"   expr0 1.0\n" \
	"   expr1 1.0\n" \
	"   expr2 1.0\n" \
	"   name white\n" \
	"   xpos -360\n" \
	"   ypos 446\n" \
	"  }\n" \
	"  Switch {\n" \
	"   inputs 2\n" \
	"   which %d\n" \
	"   name Display_matte\n" \
	"   xpos -386\n" \
	"   ypos 534\n" \
	"  }\n" \
	"  Output {\n" \
	"   name Output1\n" \
	"   xpos -386\n" \
	"   ypos 569\n" \
	"  }\n" \
	" end_group\n" \
	" ShuffleCopy {\n" \
	"  inputs 2\n" \
	"  in rgb\n" \
	"  in2 rgb\n" \
	"  red red\n" \
	"  blue black\n" \
	"  out rgb\n" \
	"  name LumaSat\n" \
	"  xpos -302\n" \
	"  ypos 48\n" \
	" }\n" \
	"push $N25c6ba70\n" \
	" Group {\n" \
	"  name HueKey\n" \
	"  xpos -183\n" \
	"  ypos 4\n" \
	" }\n" \
	"  Input {\n" \
	"   inputs 0\n" \
	"   name Input1\n" \
	"   xpos -386\n" \
	"   ypos 283\n" \
	"  }\n" \
	"  Colorspace {\n" \
	"   colorspace_in sRGB\n" \
	"   colorspace_out HSL\n" \
	"   name RGB_to_HSL\n" \
	"   xpos -496\n" \
	"   ypos 316\n" \
	"  }\n" \
	"set N25e266d0 [stack 0]\n" \
	"  Expression {\n" \
	"   temp_name0 high\n" \
	"   temp_expr0 %f\n" \
	"   temp_name1 highfade\n" \
	"   temp_expr1 %f\n" \
	"   temp_name2 offset\n" \
	"   temp_expr2 %f\n" \
	"   temp_name3 hue\n" \
	"   temp_expr3 \"r == 0.0 ? 0.0 : (r + offset > 1.0 ? r + offset - 1.0 : (r + offset < 0.0 ? 1.0 + r + offset : r + offset))\"\n" \
	"   expr0 \"high + n == 0.0 ? 0.0 : high - (1.0 - highfade) >= n ? 1.0 : (high >= n ? pow((high - n) / (1.0 - highfade), %f) : 0.0)\"\n" \
	"   expr1 0\n" \
	"   expr2 0\n" \
	"   name highalpha\n" \
	"   xpos -537\n" \
	"   ypos 386\n" \
	"  }\n" \
	"push $N25e266d0\n" \
	"  Expression {\n" \
	"   temp_name0 low\n" \
	"   temp_expr0 %f\n" \
	"   temp_name1 lowfade\n" \
	"   temp_expr1 %f\n" \
	"   temp_name2 offset\n" \
	"   temp_expr2 %f\n" \
	"   temp_name3 n\n" \
	"   temp_expr3 \"r == 0.0 ? 0.0 : (r + offset > 1.0 ? r + offset - 1.0 : (r + offset < 0.0 ? 1.0 + r + offset : r + offset))\"\n" \
	"   expr0 \"low + n == 2.0 ? 0.0 : low + lowfade <= n ? 1.0 : (low <= n ? pow((n - low) / lowfade, %f) : 0.0)\"\n" \
	"   expr1 0\n" \
	"   expr2 0\n" \
	"   name lowalpha\n" \
	"   xpos -450\n" \
	"   ypos 356\n" \
	"  }\n" \
	"  MergeExpression {\n" \
	"   inputs 2\n" \
	"   expr0 \"Ar * Br\"\n" \
	"   expr1 \"Ar * Br\"\n" \
	"   expr2 \"Ar * Br\"\n" \
	"   name HueAlpha\n" \
	"   xpos -457\n" \
	"   ypos 417\n" \
	"  }\n" \
	"set N25e50610 [stack 0]\n" \
	"  Expression {\n" \
	"   expr0 \"1.0 - r\"\n" \
	"   expr1 \"1.0 - r\"\n" \
	"   expr2 \"1.0 - r\"\n" \
	"   name invertAlpha\n" \
	"   xpos -520\n" \
	"   ypos 461\n" \
	"  }\n" \
	"push $N25e50610\n" \
	"  Switch {\n" \
	"   inputs 2\n" \
	"   which %d\n" \
	"   name InvertSwitch\n" \
	"   xpos -457\n" \
	"   ypos 501\n" \
	"  }\n" \
	"  Expression {\n" \
	"   inputs 0\n" \
	"   expr0 1.0\n" \
	"   expr1 1.0\n" \
	"   expr2 1.0\n" \
	"   name white\n" \
	"   xpos -342\n" \
	"   ypos 472\n" \
	"  }\n" \
	"  Switch {\n" \
	"   inputs 2\n" \
	"   which %d\n" \
	"   name Display_matte\n" \
	"   xpos -386\n" \
	"   ypos 546\n" \
	"  }\n" \
	"  Output {\n" \
	"   name Output1\n" \
	"   xpos -386\n" \
	"   ypos 586\n" \
	"  }\n" \
	" end_group\n" \
	" ShuffleCopy {\n" \
	"  inputs 2\n" \
	"  in rgb\n" \
	"  in2 rgb\n" \
	"  red red\n" \
	"  green green\n" \
	"  out rgb\n" \
	"  name LumaSatHue\n" \
	"  xpos -261\n" \
	"  ypos 86\n" \
	" }\n" \
	" Expression {\n" \
	"  inputs 0\n" \
	"  expr0 1.0\n" \
	"  expr1 1.0\n" \
	"  expr2 1.0\n" \
	"  name white\n" \
	"  xpos -161\n" \
	"  ypos 85\n" \
	" }\n" \
	" MergeExpression {\n" \
	"  inputs 2\n" \
	"  expr0 \"Ar * Ag * Ab\"\n" \
	"  expr1 \"Ar * Ag * Ab\"\n" \
	"  expr2 \"Ar * Ag * Ab\"\n" \
	"  mix %f\n" \
	"  name AlphaMix\n" \
	"  xpos -225\n" \
	"  ypos 135\n" \
	" }\n" \
	"set N25ea1650 [stack 0]\n" \
	" Expression {\n" \
	"  expr0 \"1.0 - r\"\n" \
	"  expr1 \"1.0 - r\"\n" \
	"  expr2 \"1.0 - r\"\n" \
	"  name AlphaInvert\n" \
	"  xpos -300\n" \
	"  ypos 187\n" \
	" }\n" \
	"push $N25ea1650\n" \
	" Switch {\n" \
	"  inputs 2\n" \
	"  which %d\n" \
	"  name AlphaInvertSwitch\n" \
	"  xpos -225\n" \
	"  ypos 217\n" \
	" }\n" \
	"push $N25c6ba70\n" \
	" Dot {\n" \
	"  name Dot1\n" \
	"  xpos -367\n" \
	"  ypos -58\n" \
	" }\n" \
	" Dot {\n" \
	"  name Dot2\n" \
	"  xpos -367\n" \
	"  ypos 165\n" \
	" }\n" \
	" Switch {\n" \
	"  inputs 2\n" \
	"  which %d\n" \
	"  name DisplaySwitch\n" \
	"  xpos -267\n" \
	"  ypos 276\n" \
	" }\n" \
	" Output {\n" \
	"  name Output1\n" \
	"  xpos -267\n" \
	"  ypos 317\n" \
	" }\n" \
	"end_group\n", lumahigh, lumahighfade, lumahighfadecurve, lumalow, lumalowfade, lumalowfadecurve, lumainvert, offluma, 
	sathigh, sathighfade, sathighfadecurve, satlow, satlowfade, satlowfadecurve, satinvert, offsat,
	huehigh, huehighfade, huerotate, huehighfadecurve, huelow, huelowfade, huerotate, huelowfadecurve, hueinvert, offhue,
	mix, maininvert, display);
	fclose (pFile);
	} else {
     sendMessage(OFX::Message::eMessageError, "", string("Error: Cannot save " + NAME + ".nk to " + PATH  + ". Check Permissions."));
	}	
	}
	}
	
	if (p_ParamName == "sample")
	{

		m_SwitchC->setValue(true);
		m_SwitchE->setValue(true);
		m_SwitchG->setValue(true);

		RGBValues sample;
		m_Sample->getValueAtTime(p_Args.time, sample.r, sample.g, sample.b);

		float hue = RGBtoHUE(sample.r, sample.g, sample.b);
		float h1 = hue == 0.0f ? 0.0f : (hue + 0.2f > 1.0f ? 1.0f : hue + 0.2f);
		float h2 = hue - 0.2f < 0.0001f ? 0.0001f : hue - 0.2f;
		float h3 = hue > 0.9f ? 1.0f : 0.95f;
		float h4 = hue < 0.1f ? 0.0f : 0.05f;
		m_ScaleN->setValue(h1);
		m_ScaleO->setValue(h3);
		m_ScaleP->setValue(h4);
		m_ScaleR->setValue(h2);

		float sat = RGBtoSAT(sample.r, sample.g, sample.b);
		float S1 = sat + 0.2f > 1.0f ? 1.0f : sat + 0.2f;
		float S2 = sat - 0.2f < 0.0f ? 0.0f : sat - 0.2f;
		float S3 = sat > 0.9f ? 1.0f : 0.95;
		float S4 = sat < 0.1f ? 0.0f : 0.05f;
		m_ScaleH->setValue(S1);
		m_ScaleI->setValue(S3);
		m_ScaleJ->setValue(S4);
		m_ScaleK->setValue(S2);

		float lum = RGBtoLUM(sample.r, sample.g, sample.b);
		float L1 = lum + 0.2f > 1.0f ? 1.0f : lum + 0.2f;
		float L2 = lum - 0.2f < 0.0f ? 0.0f : lum - 0.2f;
		float L3 = lum > 0.9f ? 1.0f : 0.95;
		float L4 = lum < 0.1f ? 0.0f : 0.05f;
		m_ScaleA->setValue(L1);
		m_ScaleB->setValue(L3);
		m_ScaleC->setValue(L4);
		m_ScaleD->setValue(L2);

	}

	if (p_ParamName == "ScaleN")
	{
		float hl = m_ScaleR->getValueAtTime(p_Args.time);
		float HL = hl == 0.0f ? 0.0001 : hl;
		m_ScaleR->setValue(HL);

	}

	if (p_ParamName == "ScaleO")
	{
		float hl = m_ScaleR->getValueAtTime(p_Args.time);
		float HL = hl == 0.0f ? 0.0001 : hl;
		m_ScaleR->setValue(HL);

	}
}

void QualifierPlugin::setupAndProcess(Qualifier& p_Qualifier, const OFX::RenderArguments& p_Args)
{
	// Get the dst image
	std::auto_ptr<OFX::Image> dst(m_DstClip->fetchImage(p_Args.time));
	OFX::BitDepthEnum dstBitDepth = dst->getPixelDepth();
	OFX::PixelComponentEnum dstComponents = dst->getPixelComponents();

	// Get the src image
	std::auto_ptr<OFX::Image> src(m_SrcClip->fetchImage(p_Args.time));
	OFX::BitDepthEnum srcBitDepth = src->getPixelDepth();
	OFX::PixelComponentEnum srcComponents = src->getPixelComponents();

	// Check to see if the bit depth and number of components are the same
	if ((srcBitDepth != dstBitDepth) || (srcComponents != dstComponents))
	{
		OFX::throwSuiteStatusException(kOfxStatErrValue);
	}


	double aScale = m_ScaleA->getValueAtTime(p_Args.time);
	double bScale = m_ScaleB->getValueAtTime(p_Args.time);
	double cScale = m_ScaleC->getValueAtTime(p_Args.time);
	double dScale = m_ScaleD->getValueAtTime(p_Args.time);
	double eScale = m_ScaleE->getValueAtTime(p_Args.time);
	double fScale = m_ScaleF->getValueAtTime(p_Args.time);
	double gScale = m_ScaleG->getValueAtTime(p_Args.time);
	double hScale = m_ScaleH->getValueAtTime(p_Args.time);
	double iScale = m_ScaleI->getValueAtTime(p_Args.time);
	double jScale = m_ScaleJ->getValueAtTime(p_Args.time);
	double kScale = m_ScaleK->getValueAtTime(p_Args.time);
	double lScale = m_ScaleL->getValueAtTime(p_Args.time);
	double mScale = m_ScaleM->getValueAtTime(p_Args.time);
	double nScale = m_ScaleN->getValueAtTime(p_Args.time);
	double oScale = m_ScaleO->getValueAtTime(p_Args.time);
	double pScale = m_ScaleP->getValueAtTime(p_Args.time);
	double rScale = m_ScaleR->getValueAtTime(p_Args.time);
	double sScale = m_ScaleS->getValueAtTime(p_Args.time);
	double tScale = m_ScaleT->getValueAtTime(p_Args.time);
	double uScale = m_ScaleU->getValueAtTime(p_Args.time);

	bool aSwitch = m_SwitchA->getValueAtTime(p_Args.time);
	bool bSwitch = m_SwitchB->getValueAtTime(p_Args.time);
	bool cSwitch = m_SwitchC->getValueAtTime(p_Args.time);
	bool dSwitch = m_SwitchD->getValueAtTime(p_Args.time);
	bool eSwitch = m_SwitchE->getValueAtTime(p_Args.time);
	bool fSwitch = m_SwitchF->getValueAtTime(p_Args.time);
	bool gSwitch = m_SwitchG->getValueAtTime(p_Args.time);
	bool hSwitch = m_SwitchH->getValueAtTime(p_Args.time);

	float aSwitchF = aSwitch ? 1.0f : 0.0f;
	float bSwitchF = bSwitch ? 1.0f : 0.0f;
	float cSwitchF = cSwitch ? 1.0f : 0.0f;
	float dSwitchF = dSwitch ? 1.0f : 0.0f;
	float eSwitchF = eSwitch ? 1.0f : 0.0f;
	float fSwitchF = fSwitch ? 1.0f : 0.0f;
	float gSwitchF = gSwitch ? 1.0f : 0.0f;
	float hSwitchF = hSwitch ? 1.0f : 0.0f;

	// Set the images
	p_Qualifier.setDstImg(dst.get());
	p_Qualifier.setSrcImg(src.get());

	// Setup OpenCL and CUDA Render arguments
	p_Qualifier.setGPURenderArgs(p_Args);

	// Set the render window
	p_Qualifier.setRenderWindow(p_Args.renderWindow);

	// Set the scales
	p_Qualifier.setScales(aScale, bScale, cScale, dScale, eScale, fScale, gScale, hScale, iScale, jScale, kScale, lScale, mScale,
		nScale, oScale, pScale, rScale, sScale, tScale, uScale, aSwitchF, bSwitchF, cSwitchF, dSwitchF,
		eSwitchF, fSwitchF, gSwitchF, hSwitchF);

	// Call the base class process member, this will call the derived templated process code
	p_Qualifier.process();
}

////////////////////////////////////////////////////////////////////////////////

using namespace OFX;

QualifierPluginFactory::QualifierPluginFactory()
	: OFX::PluginFactoryHelper<QualifierPluginFactory>(kPluginIdentifier, kPluginVersionMajor, kPluginVersionMinor)
{
}

void QualifierPluginFactory::describe(OFX::ImageEffectDescriptor& p_Desc)
{
	// Basic labels
	p_Desc.setLabels(kPluginName, kPluginName, kPluginName);
	p_Desc.setPluginGrouping(kPluginGrouping);
	p_Desc.setPluginDescription(kPluginDescription);

	// Add the supported contexts, only filter at the moment
	p_Desc.addSupportedContext(eContextFilter);
	p_Desc.addSupportedContext(eContextGeneral);

	// Add supported pixel depths
	p_Desc.addSupportedBitDepth(eBitDepthFloat);

	// Set a few flags
	p_Desc.setSingleInstance(false);
	p_Desc.setHostFrameThreading(false);
	p_Desc.setSupportsMultiResolution(kSupportsMultiResolution);
	p_Desc.setSupportsTiles(kSupportsTiles);
	p_Desc.setTemporalClipAccess(false);
	p_Desc.setRenderTwiceAlways(false);
	p_Desc.setSupportsMultipleClipPARs(kSupportsMultipleClipPARs);

	// Setup OpenCL and CUDA render capability flags
	p_Desc.setSupportsOpenCLRender(true);
	p_Desc.setSupportsCudaRender(true);
}

static DoubleParamDescriptor* defineScaleParam(OFX::ImageEffectDescriptor& p_Desc, const std::string& p_Name, const std::string& p_Label,
	const std::string& p_Hint, GroupParamDescriptor* p_Parent)
{
	DoubleParamDescriptor* param = p_Desc.defineDoubleParam(p_Name);
	param->setLabels(p_Label, p_Label, p_Label);
	param->setScriptName(p_Name);
	param->setHint(p_Hint);
	param->setDefault(1.0f);
	param->setRange(0.0f, 1.0f);
	param->setIncrement(0.001);
	param->setDisplayRange(0.0f, 1.0f);
	param->setDoubleType(eDoubleTypeScale);

	if (p_Parent)
	{
		param->setParent(*p_Parent);
	}

	return param;
}


void QualifierPluginFactory::describeInContext(OFX::ImageEffectDescriptor& p_Desc, OFX::ContextEnum /*p_Context*/)
{
	// Source clip only in the filter context
	// Create the mandated source clip
	ClipDescriptor* srcClip = p_Desc.defineClip(kOfxImageEffectSimpleSourceClipName);
	srcClip->addSupportedComponent(ePixelComponentRGBA);
	srcClip->setTemporalClipAccess(false);
	srcClip->setSupportsTiles(kSupportsTiles);
	srcClip->setIsMask(false);

	// Create the mandated output clip
	ClipDescriptor* dstClip = p_Desc.defineClip(kOfxImageEffectOutputClipName);
	dstClip->addSupportedComponent(ePixelComponentRGBA);
	dstClip->addSupportedComponent(ePixelComponentAlpha);
	dstClip->setSupportsTiles(kSupportsTiles);

	// Make some pages and to things in
	PageParamDescriptor* page = p_Desc.definePageParam("Controls");

	// Add a boolean to enable the component scale
	BooleanParamDescriptor* boolParam = p_Desc.defineBooleanParam("display");
	boolParam->setDefault(false);
	boolParam->setHint("Displays Matte on RGB Channels");
	boolParam->setLabels("Display Matte", "Display Matte", "Display Matte");
	page->addChild(*boolParam);

	boolParam = p_Desc.defineBooleanParam("invertAlpha");
	boolParam->setDefault(false);
	boolParam->setHint("Inverts the Alpha Channel");
	boolParam->setLabels("Invert", "Invert", "Invert");
	page->addChild(*boolParam);

	RGBParamDescriptor *rgbparam = p_Desc.defineRGBParam("sample");
	rgbparam->setLabel("HSL Sample");
	rgbparam->setHint("click on pixel");
	rgbparam->setDefault(1.0f, 1.0f, 1.0f);
	rgbparam->setDisplayRange(0.0f, 0.0f, 0.0f, 4.0f, 4.0f, 4.0f);
	rgbparam->setAnimates(true); // can animate
	page->addChild(*rgbparam);



	GroupParamDescriptor* luma = p_Desc.defineGroupParam("Luminance Key");
	luma->setOpen(true);
	luma->setHint("Pull Luminance Key");
	if (page) {
		page->addChild(*luma);
	}
	// Add a boolean to enable the component scale
	boolParam = p_Desc.defineBooleanParam("lumaOff");
	boolParam->setDefault(false);
	boolParam->setHint("Disable Luma Key");
	boolParam->setLabels("Enable", "Enable", "Enable");
	boolParam->setParent(*luma);

	boolParam = p_Desc.defineBooleanParam("invertAlphaL");
	boolParam->setDefault(false);
	boolParam->setHint("Inverts the Alpha Channel");
	boolParam->setLabels("Invert", "Invert", "Invert");
	boolParam->setParent(*luma);

	// Make the four component scale params
	DoubleParamDescriptor* param = defineScaleParam(p_Desc, "ScaleA", "high", "High limit of alpha channel", luma);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleB", "high fade", "Roll-off between high limit", luma);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleC", "low fade", "Roll-off between low limit", luma);
	param->setDefault(0.0f);
	param->setRange(0.0f, 1.0f);
	param->setIncrement(0.001);
	param->setDisplayRange(0.0f, 1.0f);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleD", "low", "Low limit of alpha channel", luma);
	param->setDefault(0.0f);
	param->setRange(0.0f, 1.0f);
	param->setIncrement(0.001);
	param->setDisplayRange(0.0f, 1.0f);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleE", "high fade curve", "Easy out / Easy in", luma);
	param->setDefault(1.0f);
	param->setRange(0.2f, 5.0f);
	param->setIncrement(0.001);
	param->setDisplayRange(0.2f, 5.0f);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleF", "low fade curve", "Easy out / Easy in", luma);
	param->setDefault(1.0f);
	param->setRange(0.2f, 5.0f);
	param->setIncrement(0.001);
	param->setDisplayRange(0.2f, 5.0f);
	page->addChild(*param);


	GroupParamDescriptor* sat = p_Desc.defineGroupParam("Saturation Key");
	sat->setOpen(true);
	sat->setHint("Pull Saturation Key");
	if (page) {
		page->addChild(*sat);
	}

	// Add a boolean to enable the component scale
	boolParam = p_Desc.defineBooleanParam("satOff");
	boolParam->setDefault(false);
	boolParam->setHint("Disable Sat Key");
	boolParam->setLabels("Enable", "Enable", "Enable");
	boolParam->setParent(*sat);

	boolParam = p_Desc.defineBooleanParam("invertAlphaS");
	boolParam->setDefault(false);
	boolParam->setHint("Inverts the Alpha Channel");
	boolParam->setLabels("Invert", "Invert", "Invert");
	boolParam->setParent(*sat);


	// Make the four component scale params
	param = defineScaleParam(p_Desc, "ScaleH", "high", "High limit of alpha channel", sat);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleI", "high fade", "Roll-off between high limit", sat);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleJ", "low fade", "Roll-off between low limit", sat);
	param->setDefault(0.0f);
	param->setRange(0.0f, 1.0f);
	param->setIncrement(0.001);
	param->setDisplayRange(0.0f, 1.0f);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleK", "low", "Low limit of alpha channel", sat);
	param->setDefault(0.0f);
	param->setRange(0.0f, 1.0f);
	param->setIncrement(0.001);
	param->setDisplayRange(0.0f, 1.0f);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleL", "high fade curve", "Easy out / Easy in", sat);
	param->setDefault(1.0f);
	param->setRange(0.2f, 5.0f);
	param->setIncrement(0.001);
	param->setDisplayRange(0.2f, 5.0f);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleM", "low fade curve", "Easy out / Easy in", sat);
	param->setDefault(1.0f);
	param->setRange(0.2f, 5.0f);
	param->setIncrement(0.001);
	param->setDisplayRange(0.2f, 5.0f);
	page->addChild(*param);


	// Group param to group the scales
	GroupParamDescriptor* hue = p_Desc.defineGroupParam("Hue Key");
	hue->setOpen(true);
	hue->setHint("Pull Hue Key");
	if (page) {
		page->addChild(*hue);

	}

	// Add a boolean to enable the component scale
	boolParam = p_Desc.defineBooleanParam("hueOff");
	boolParam->setDefault(false);
	boolParam->setHint("Disable Hue Key");
	boolParam->setLabels("Enable", "Enable", "Enable");
	boolParam->setParent(*hue);

	boolParam = p_Desc.defineBooleanParam("invertAlphaH");
	boolParam->setDefault(false);
	boolParam->setHint("Inverts the Alpha Channel");
	boolParam->setLabels("Invert", "Invert", "Invert");
	boolParam->setParent(*hue);

	// Make the four component scale params
	param = defineScaleParam(p_Desc, "ScaleN", "high", "High limit of alpha channel", hue);
	param->setDefault(1.0f);
	param->setRange(0.0f, 1.0f);
	param->setIncrement(0.001f);
	param->setDisplayRange(0.0f, 1.0f);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleO", "high fade", "Roll-off between high limit", hue);
	param->setDefault(1.0f);
	param->setRange(0.0f, 1.0f);
	param->setIncrement(0.001f);
	param->setDisplayRange(0.0f, 1.0f);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleP", "low fade", "Roll-off between low limit", hue);
	param->setDefault(0.0f);
	param->setRange(0.0f, 1.0f);
	param->setIncrement(0.001f);
	param->setDisplayRange(0.0f, 1.0f);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleR", "low", "Low limit of alpha channel", hue);
	param->setDefault(0.0f);
	param->setRange(0.0f, 1.0f);
	param->setIncrement(0.001f);
	param->setDisplayRange(0.0f, 1.0f);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleS", "high fade curve", "Easy out / Easy in", hue);
	param->setDefault(1.0f);
	param->setRange(0.2f, 5.0f);
	param->setIncrement(0.001f);
	param->setDisplayRange(0.2f, 5.0f);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleT", "low fade curve", "Easy out / Easy in", hue);
	param->setDefault(1.0f);
	param->setRange(0.2f, 5.0f);
	param->setIncrement(0.001f);
	param->setDisplayRange(0.2f, 5.0f);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleU", "rotate", "Rotate Hue Wheel", hue);
	param->setDefault(0.0f);
	param->setRange(-1.0f, 1.0f);
	param->setIncrement(0.001f);
	param->setDisplayRange(-1.0f, 1.0f);
	page->addChild(*param);

	param = defineScaleParam(p_Desc, "ScaleG", "mix", "Blends new alpha with original alpha", 0);
	param->setDefault(0.0f);
	param->setRange(0.0f, 1.0f);
	param->setIncrement(0.001f);
	param->setDisplayRange(0.0f, 1.0f);
	page->addChild(*param);
	
	 {
    PushButtonParamDescriptor* param = p_Desc.definePushButtonParam("info");
    param->setLabel("Info");
    page->addChild(*param);
    }
    
    {    
    GroupParamDescriptor* script = p_Desc.defineGroupParam("Script Export");
    script->setOpen(false);
    script->setHint("export DCTL and Nuke script");
      if (page) {
            page->addChild(*script);
            }
    {
    PushButtonParamDescriptor* param = p_Desc.definePushButtonParam("button1");
    param->setLabel("Export DCTL");
    param->setHint("create DCTL version");
    param->setParent(*script);
    page->addChild(*param);
    }
    {
    PushButtonParamDescriptor* param = p_Desc.definePushButtonParam("button2");
    param->setLabel("Export Nuke script");
    param->setHint("create NUKE version");
    param->setParent(*script);
    page->addChild(*param);
    }
    {
	StringParamDescriptor* param = p_Desc.defineStringParam("name");
	param->setLabel("Name");
	param->setHint("overwrites if the same");
	param->setDefault("Qualifier");
	param->setParent(*script);
	page->addChild(*param);
	}
	{
	StringParamDescriptor* param = p_Desc.defineStringParam("path");
	param->setLabel("Directory");
	param->setHint("make sure it's the absolute path");
	param->setStringType(eStringTypeFilePath);
	param->setDefault(kPluginScript);
	param->setFilePathExists(false);
	param->setParent(*script);
	page->addChild(*param);
	}
	}
}

ImageEffect* QualifierPluginFactory::createInstance(OfxImageEffectHandle p_Handle, ContextEnum /*p_Context*/)
{
	return new QualifierPlugin(p_Handle);
}

void OFX::Plugin::getPluginIDs(PluginFactoryArray& p_FactoryArray)
{
	static QualifierPluginFactory QualifierPlugin;
	p_FactoryArray.push_back(&QualifierPlugin);
}
