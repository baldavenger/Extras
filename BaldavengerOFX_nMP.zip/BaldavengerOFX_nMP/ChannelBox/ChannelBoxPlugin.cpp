#include "ChannelBoxPlugin.h"

#include <cstring>
#include <cmath>
#include <stdio.h>
using std::string;
#include <string> 
#include <fstream>

#include "ofxsImageEffect.h"
#include "ofxsMultiThread.h"
#include "ofxsProcessing.h"
#include "ofxsParam.h"
#include "ofxsLog.h"

#ifdef __APPLE__
#define kPluginScript "/Library/Application Support/Blackmagic Design/DaVinci Resolve/LUT"
#elif defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64)
#define kPluginScript "\\ProgramData\\Blackmagic Design\\DaVinci Resolve\\Support\\LUT"
#else
#define kPluginScript "/home/resolve/LUT"
#endif

#define kPluginName "ChannelBox"
#define kPluginGrouping "OpenFX Yo"
#define kPluginDescription \
"------------------------------------------------------------------------------------------------------------------ \n" \
"ChannelBox: Limit specific colour channels so that they never exceed the value of one or \n" \
"both of the other two channels. Coombine with the built in Luma Keyer to isolate the effect \n" \
"to a specific range."

#define kPluginIdentifier "OpenFX.Yo.ChannelBox"
#define kOfxParamPropChoiceOption "OfxParamPropChoiceOption"
#define kOfxParamPropDefault "OfxParamPropDefault"
#define kPluginVersionMajor 2
#define kPluginVersionMinor 1

#define kSupportsTiles false
#define kSupportsMultiResolution false
#define kSupportsMultipleClipPARs false

#define kParamChannelBox "channelBox"
#define kParamChannelBoxLabel "Options"
#define kParamChannelBoxHint "Channels and Limits"
#define kParamChannelBoxOptionBR "Blue < Red"
#define kParamChannelBoxOptionBRHint "Limits Blue to Red"
#define kParamChannelBoxOptionBG "Blue < Green"
#define kParamChannelBoxOptionBGHint "Limits Blue to Green"
#define kParamChannelBoxOptionBGR "Blue < Green & Red"
#define kParamChannelBoxOptionBGRHint "Limits Blue to Green & Red"
#define kParamChannelBoxOptionBGRX "Blue < Max(Green, Red)"
#define kParamChannelBoxOptionBGRXHint "Limits Blue to Max of Green & Red"
#define kParamChannelBoxOptionGR "Green < Red"
#define kParamChannelBoxOptionGRHint "Limits Green to Red"
#define kParamChannelBoxOptionGB "Green < Blue"
#define kParamChannelBoxOptionGBHint "Limits Green to Blue"
#define kParamChannelBoxOptionGBR "Green < Blue & Red"
#define kParamChannelBoxOptionGBRHint "Limits Green to Blue & Red"
#define kParamChannelBoxOptionGBRX "Green < Max(Blue, Red)"
#define kParamChannelBoxOptionGBRXHint "Limits Green to Max of Blue & Red"
#define kParamChannelBoxOptionRG "Red < Green"
#define kParamChannelBoxOptionRGHint "Limits Red to Green"
#define kParamChannelBoxOptionRB "Red < Blue"
#define kParamChannelBoxOptionRBHint "Limits Red to Blue"
#define kParamChannelBoxOptionRBG "Red < Blue & Green"
#define kParamChannelBoxOptionRBGHint "Limits Red to Blue & Green"
#define kParamChannelBoxOptionRBGX "Red < Max(Blue, Green)"
#define kParamChannelBoxOptionRBGXHint "Limits Red to Max of Blue & Green"

enum ChannelBoxEnum {
    eChannelBoxBR,
    eChannelBoxBG,
    eChannelBoxBGR,
    eChannelBoxBGRX,
    eChannelBoxGR,
    eChannelBoxGB,
    eChannelBoxGBR,
    eChannelBoxGBRX,
    eChannelBoxRG,
    eChannelBoxRB,
    eChannelBoxRBG,
    eChannelBoxRBGX,
    
};

////////////////////////////////////////////////////////////////////////////////

namespace {
    struct RGBValues {
        double r,g,b;
        RGBValues(double v) : r(v), g(v), b(v) {}
        RGBValues() : r(0), g(0), b(0) {}
    };
}

class ChannelBox : public OFX::ImageProcessor
{
public:
    explicit ChannelBox(OFX::ImageEffect& p_Instance);

    virtual void processImagesOpenCL();
    virtual void multiThreadProcessImages(OfxRectI p_ProcWindow);
    
    void setSrcImg(OFX::Image* p_SrcImg);
	void setScales(float p_ChannelBR, float p_ChannelBG, float p_ChannelBGR, float p_ChannelBGRX,
		float p_ChannelGR, float p_ChannelGB, float p_ChannelGBR, float p_ChannelGBRX, float p_ChannelRG,
		float p_ChannelRB, float p_ChannelRBG, float p_ChannelRBGX, float p_ScaleR, float p_ScaleG,
        float p_ScaleB, float p_ScaleA, float p_ScaleD, float p_ScaleE, float p_ScaleO,
		float p_ScaleZ, float p_SwitchA, float p_SwitchB);

private:
    OFX::Image* _srcImg;
	float _channel[12];
    float _scales[8];
	float _switch[2];
};

ChannelBox::ChannelBox(OFX::ImageEffect& p_Instance)
    : OFX::ImageProcessor(p_Instance)
{
}

extern void RunOpenCLKernel(void* p_CmdQ, int p_Width, int p_Height, float* p_Channel, float* p_Scale, float* p_Switch, const float* p_Input, float* p_Output);

void ChannelBox::processImagesOpenCL()
{
    const OfxRectI& bounds = _srcImg->getBounds();
    const int width = bounds.x2 - bounds.x1;
    const int height = bounds.y2 - bounds.y1;

    float* input = static_cast<float*>(_srcImg->getPixelData());
    float* output = static_cast<float*>(_dstImg->getPixelData());

    RunOpenCLKernel(_pOpenCLCmdQ, width, height, _channel, _scales, _switch, input, output);
}

void ChannelBox::multiThreadProcessImages(OfxRectI p_ProcWindow)
{
    for (int y = p_ProcWindow.y1; y < p_ProcWindow.y2; ++y)
    {
        if (_effect.abort()) break;

        float* dstPix = static_cast<float*>(_dstImg->getPixelAddress(p_ProcWindow.x1, y));

        for (int x = p_ProcWindow.x1; x < p_ProcWindow.x2; ++x)
        {
            float* srcPix = static_cast<float*>(_srcImg ? _srcImg->getPixelAddress(x, y) : 0);

            // do we have a source image to scale up
            if (srcPix)
            {
				const float R = srcPix[0];
				const float G = srcPix[1];
				const float B = srcPix[2];
				float l = (srcPix[0] * 0.2126f) + (srcPix[1] * 0.7152f) + (srcPix[2] * 0.0722f);
				float L = l - _scales[6];
				float q = fmin(L, 1.0f);
				float n = fmax(q, 0.0f);

				float BR = B > R ? R : B;
				float BG = B > G ? G : B;
				float BGR = B > fmin(G, R) ? fmin(G, R) : B;
				float BGRX = B > fmax(G, R) ? fmax(G, R) : B;
				float blue = (_channel[0] == 1.0f) ? BR : ((_channel[1] == 1.0f) ? BG : ((_channel[2] == 1.0f) ? BGR : ((_channel[3] == 1.0f) ? BGRX : B)));

				float GR = G > R ? R : G;
				float GB = G > B ? B : G;
				float GBR = G > fmin(B, R) ? fmin(B, R) : G;
				float GBRX = G > fmax(B, R) ? fmax(B, R) : G;
				float green = (_channel[4] == 1.0f) ? GR : ((_channel[5] == 1.0f) ? GB : ((_channel[6] == 1.0f) ? GBR : ((_channel[7] == 1.0f) ? GBRX : G)));

				float RG = R > G ? G : R;
				float RB = R > B ? B : R;
				float RBG = R > fmin(B, G) ? fmin(B, G) : R;
				float RBGX = R > fmax(B, G) ? fmax(B, G) : R;
				float red = (_channel[8] == 1.0f) ? RG : ((_channel[9] == 1.0f) ? RB : ((_channel[10] == 1.0f) ? RBG : ((_channel[11] == 1.0f) ? RBGX : R)));

				float r = _scales[0];
				float g = _scales[1];
				float b = _scales[2];
				float a = _scales[3];
				float d = 1.0f / _scales[4];
				float e = 1.0f / _scales[5];
				float z = _scales[7];

				float w = r == 0.0f ? 0.0f : (r - (1.0f - g) >= n ? 1.0f : (r >= n ? pow((r - n) / (1.0f - g), d) : 0.0f));
				float k = a == 1.0f ? 0.0f : (a + b <= n ? 1.0f : (a <= n ? pow((n - a) / b, e) : 0.0f));
				float alpha = k * w;
				float alphaM = alpha + (1.0f - alpha) * z;
				float alphaV = (_switch[1] == 1.0f) ? 1.0f - alphaM : alphaM;

				dstPix[0] = (_switch[0] == 1.0f) ? alphaV : (R * (1.0f - alphaV)) + (red * alphaV);
				dstPix[1] = (_switch[0] == 1.0f) ? alphaV : (G * (1.0f - alphaV)) + (green * alphaV);
				dstPix[2] = (_switch[0] == 1.0f) ? alphaV : (B * (1.0f - alphaV)) + (blue * alphaV);
				dstPix[3] = (_switch[0] == 1.0f) ? srcPix[3] : alphaV;
			}
			else
            {
                // no src pixel here, be black and transparent
                for (int c = 0; c < 4; ++c)
                {
                    dstPix[c] = 0;
                }
            }

            // increment the dst pixel
            dstPix += 4;
        }
    }
}

void ChannelBox::setSrcImg(OFX::Image* p_SrcImg)
{
    _srcImg = p_SrcImg;
}

void ChannelBox::setScales(float p_ChannelBR, float p_ChannelBG, float p_ChannelBGR, float p_ChannelBGRX,
	float p_ChannelGR, float p_ChannelGB, float p_ChannelGBR, float p_ChannelGBRX,float p_ChannelRG, 
	float p_ChannelRB, float p_ChannelRBG, float p_ChannelRBGX, float p_ScaleR, float p_ScaleG, float p_ScaleB, 
	float p_ScaleA, float p_ScaleD, float p_ScaleE, float p_ScaleO, float p_ScaleZ, float p_SwitchA, float p_SwitchB)
{
    _channel[0] = p_ChannelBR;
    _channel[1] = p_ChannelBG;
    _channel[2] = p_ChannelBGR;
    _channel[3] = p_ChannelBGRX;
    _channel[4] = p_ChannelGR;
    _channel[5] = p_ChannelGB;
    _channel[6] = p_ChannelGBR;
    _channel[7] = p_ChannelGBRX;
    _channel[8] = p_ChannelRG;
    _channel[9] = p_ChannelRB;
    _channel[10] = p_ChannelRBG;
    _channel[11] = p_ChannelRBGX;
    
    _scales[0] = p_ScaleR;
    _scales[1] = p_ScaleG;
    _scales[2] = p_ScaleB;
    _scales[3] = p_ScaleA;
    _scales[4] = p_ScaleD;
    _scales[5] = p_ScaleE;
    _scales[6] = p_ScaleO;
    _scales[7] = p_ScaleZ;
    
    _switch[0] = p_SwitchA;
    _switch[1] = p_SwitchB;
}

////////////////////////////////////////////////////////////////////////////////
/** @brief The plugin that does our work */
class ChannelBoxPlugin : public OFX::ImageEffect
{
public:
    explicit ChannelBoxPlugin(OfxImageEffectHandle p_Handle);

    /* Override the render */
    virtual void render(const OFX::RenderArguments& p_Args);
    
    /* Override is identity */
    virtual bool isIdentity(const OFX::IsIdentityArguments& p_Args, OFX::Clip*& p_IdentityClip, double& p_IdentityTime);

    /* Override changedParam */
    virtual void changedParam(const OFX::InstanceChangedArgs& p_Args, const std::string& p_ParamName);

    /* Set up and run a processor */
    void setupAndProcess(ChannelBox &p_ChannelBox, const OFX::RenderArguments& p_Args);

private:
    // Does not own the following pointers
    OFX::Clip* m_DstClip;
    OFX::Clip* m_SrcClip;

    OFX::ChoiceParam* m_ChannelBox;
    OFX::RGBParam *m_Sample;
	OFX::DoubleParam* m_ScaleL;
    OFX::DoubleParam* m_ScaleR;
    OFX::DoubleParam* m_ScaleG;
    OFX::DoubleParam* m_ScaleB;
    OFX::DoubleParam* m_ScaleA;
    OFX::DoubleParam* m_ScaleD;
    OFX::DoubleParam* m_ScaleE;
    OFX::DoubleParam* m_ScaleO;
    OFX::DoubleParam* m_ScaleZ;
    OFX::BooleanParam* m_SwitchA;
    OFX::BooleanParam* m_SwitchB;
    OFX::StringParam* m_Path;
    OFX::StringParam* m_Name;
    OFX::PushButtonParam* m_Info;
	OFX::PushButtonParam* m_Button1;
	OFX::PushButtonParam* m_Button2;
};

ChannelBoxPlugin::ChannelBoxPlugin(OfxImageEffectHandle p_Handle)
    : ImageEffect(p_Handle)
{
    m_DstClip = fetchClip(kOfxImageEffectOutputClipName);
    m_SrcClip = fetchClip(kOfxImageEffectSimpleSourceClipName);

    m_ChannelBox = fetchChoiceParam("channelBox");
    m_Sample = fetchRGBParam("sample");
    m_ScaleL = fetchDoubleParam("luma");
    m_ScaleR = fetchDoubleParam("scaleR");
    m_ScaleG = fetchDoubleParam("scaleG");
    m_ScaleB = fetchDoubleParam("scaleB");
    m_ScaleA = fetchDoubleParam("scaleA");
    m_ScaleD = fetchDoubleParam("scaleD");
    m_ScaleE = fetchDoubleParam("scaleE");
    m_ScaleO = fetchDoubleParam("scaleO");
    m_ScaleZ = fetchDoubleParam("scaleZ");
    m_SwitchA = fetchBooleanParam("display");
    m_SwitchB = fetchBooleanParam("invertAlpha");
    m_Path = fetchStringParam("path");
	m_Name = fetchStringParam("name");
	m_Info = fetchPushButtonParam("info");
	m_Button1 = fetchPushButtonParam("button1");
	m_Button2 = fetchPushButtonParam("button2");

}

void ChannelBoxPlugin::render(const OFX::RenderArguments& p_Args)
{
    if ((m_DstClip->getPixelDepth() == OFX::eBitDepthFloat) && (m_DstClip->getPixelComponents() == OFX::ePixelComponentRGBA))
    {
        ChannelBox channelBox(*this);
        setupAndProcess(channelBox, p_Args);
    }
    else
    {
        OFX::throwSuiteStatusException(kOfxStatErrUnsupported);
    }
}

bool ChannelBoxPlugin::isIdentity(const OFX::IsIdentityArguments& p_Args, OFX::Clip*& p_IdentityClip, double& p_IdentityTime)
{
   
    double rScale = m_ScaleR->getValueAtTime(p_Args.time);
    double gScale = m_ScaleG->getValueAtTime(p_Args.time);
    double bScale = m_ScaleB->getValueAtTime(p_Args.time);
    double aScale = m_ScaleA->getValueAtTime(p_Args.time);
    double dScale = m_ScaleD->getValueAtTime(p_Args.time);
    double eScale = m_ScaleE->getValueAtTime(p_Args.time);
    double oScale = m_ScaleO->getValueAtTime(p_Args.time);
    double zScale = m_ScaleZ->getValueAtTime(p_Args.time);
    

    
    if ((rScale == 1.0) && (gScale == 1.0) && (bScale == 0.0) && (aScale == 0.0) && (dScale == 1.0) && (eScale == 1.0) && (oScale == 0.0) && (zScale == 0.0))
    {
        p_IdentityClip = m_SrcClip;
        p_IdentityTime = p_Args.time;
        return true;
    }

    return false;
}

void ChannelBoxPlugin::changedParam(const OFX::InstanceChangedArgs& p_Args, const std::string& p_ParamName)
{
 
 	if(p_ParamName == "info")
    {
	
	sendMessage(OFX::Message::eMessageMessage, "", string(kPluginDescription));
	
	}
	
	if(p_ParamName == "button1")
    {
       
    float high = m_ScaleR->getValueAtTime(p_Args.time);
    float highfade = m_ScaleG->getValueAtTime(p_Args.time);
    float lowfade = m_ScaleB->getValueAtTime(p_Args.time);
    float low = m_ScaleA->getValueAtTime(p_Args.time);
    float highfadecurve = m_ScaleD->getValueAtTime(p_Args.time);
    float lowfadecurve = m_ScaleE->getValueAtTime(p_Args.time);
    float offset = m_ScaleO->getValueAtTime(p_Args.time);
    float mix = m_ScaleZ->getValueAtTime(p_Args.time);
    
    bool Display = m_SwitchA->getValueAtTime(p_Args.time);
    bool Invert = m_SwitchB->getValueAtTime(p_Args.time);

	int display = Display ? 1 : 0;
	int invert = Invert ? 1 : 0;
	
	int channelBox_i;
    m_ChannelBox->getValueAtTime(p_Args.time, channelBox_i);
    ChannelBoxEnum channelBox = (ChannelBoxEnum)channelBox_i;
    
    bool brChannel = channelBox_i == 0;
    bool bgChannel = channelBox_i == 1;
    bool bgrChannel = channelBox_i == 2;
    bool bgrxChannel = channelBox_i == 3;
    bool grChannel = channelBox_i == 4;
    bool gbChannel = channelBox_i == 5;
    bool gbrChannel = channelBox_i == 6;
    bool gbrxChannel = channelBox_i == 7;
    bool rgChannel = channelBox_i == 8;
    bool rbChannel = channelBox_i == 9;
    bool rbgChannel = channelBox_i == 10;
    bool rbgxChannel = channelBox_i == 11;

	int brChannelI = brChannel ? 1 : 0;
	int bgChannelI = bgChannel ? 1 : 0;
	int bgrChannelI = bgrChannel ? 1 : 0;
	int bgrxChannelI = bgrxChannel ? 1 : 0;
	int grChannelI = grChannel ? 1 : 0;
	int gbChannelI = gbChannel ? 1 : 0;
	int gbrChannelI = gbrChannel ? 1 : 0;
	int gbrxChannelI = gbrxChannel ? 1 : 0;
	int rgChannelI = rgChannel ? 1 : 0;
	int rbChannelI = rbChannel ? 1 : 0;
	int rbgChannelI = rbgChannel ? 1 : 0;
	int rbgxChannelI = rbgxChannel ? 1 : 0;
	
	string PATH;
	m_Path->getValue(PATH);
	
	string NAME;
	m_Name->getValue(NAME);
	
	OFX::Message::MessageReplyEnum reply = sendMessage(OFX::Message::eMessageQuestion, "", "Save " + NAME + ".dctl to " + PATH + "?");
	if (reply == OFX::Message::eMessageReplyYes) {
	
	FILE * pFile;
	
	pFile = fopen ((PATH + "/" + NAME + ".dctl").c_str(), "w");
	if (pFile != NULL) {
    	
	fprintf (pFile, "// ChannelBoxPlugin DCTL export\n" \
	"\n" \
	"__DEVICE__ float3 transform(int p_Width, int p_Height, int p_X, int p_Y, float p_R, float p_G, float p_B)\n" \
	"{\n" \
	"    \n" \
	"	// switches for display matte, invert alpha\n" \
	"	int display = %d;\n" \
	"	bool DisplayMatte = display == 1;\n" \
	"	int invert = %d;\n" \
	"	bool InvertAlpha = invert == 1;\n" \
	"\n" \
	"	// channel combinations\n" \
	"	int bluered = %d;\n" \
	"	int bluegreen = %d;\n" \
	"	int bluegreenred = %d;\n" \
	"	int bluemxgreenred = %d;\n" \
	"\n" \
	"	int greenred = %d;\n" \
	"	int greenblue = %d;\n" \
	"	int greenbluered = %d;\n" \
	"	int greenmxbluered = %d;\n" \
	"\n" \
	"	int redgreen = %d;\n" \
	"	int redblue = %d;\n" \
	"	int redbluegreen = %d;\n" \
	"	int redmxbluegreen = %d;\n" \
	"\n" \
	"	bool BlueRed = bluered == 1;\n" \
	"	bool BlueGreen = bluegreen == 1;\n" \
	"	bool BlueGreenRed = bluegreenred == 1;\n" \
	"	bool BlueMxGreenRed = bluemxgreenred == 1;\n" \
	"\n" \
	"	bool GreenRed = greenred == 1;\n" \
	"	bool GreenBlue = greenblue == 1;\n" \
	"	bool GreenBlueRed = greenbluered == 1;\n" \
	"	bool GreenMxBlueRed = greenmxbluered == 1;\n" \
	"\n" \
	"	bool RedGreen = redgreen == 1;\n" \
	"	bool RedBlue = redblue == 1;\n" \
	"	bool RedBlueGreen = redbluegreen == 1;\n" \
	"	bool RedMxBlueGreen = redmxbluegreen == 1;\n" \
	"\n" \
	"	// matte parameter values\n" \
	"	float high = %ff;\n" \
	"	float highfade = %ff;\n" \
	"	float lowfade = %ff;\n" \
	"	float low = %ff;\n" \
	"	float highfadecurve = %ff;\n" \
	"	float lowfadecurve = %ff;\n" \
	"	float offset = %ff;\n" \
	"	float mix = %ff;\n" \
	"\n" \
	"\n" \
	"	float luma = (p_R * 0.2126f) + (p_G * 0.7152f) + (p_B * 0.0722f);  \n" \
	"	float L = luma - offset;								\n" \
	"	float q = _fminf(L, 1.0f);									\n" \
	"	float n = _fmaxf(q, 0.0f);\n" \
	"\n" \
	"	float BR = p_B > p_R ? p_R : p_B;    \n" \
	"	float BG = p_B > p_G ? p_G : p_B;    \n" \
	"	float BGR = p_B > _fminf(p_G, p_R) ? _fminf(p_G, p_R) : p_B;    \n" \
	"	float BGRX = p_B > _fmaxf(p_G, p_R) ? _fmaxf(p_G, p_R) : p_B;    \n" \
	"	float blue = BlueRed ? BR : (BlueGreen ? BG : (BlueGreenRed ? BGR : (BlueMxGreenRed ? BGRX : p_B))); \n" \
	"									  \n" \
	"	float GR = p_G > p_R ? p_R : p_G;    \n" \
	"	float GB = p_G > p_B ? p_B : p_G;    \n" \
	"	float GBR = p_G > _fminf(p_B, p_R) ? _fminf(p_B, p_R) : p_G;    \n" \
	"	float GBRX = p_G > _fmaxf(p_B, p_R) ? _fmaxf(p_B, p_R) : p_G;    \n" \
	"	float green = GreenRed ? GR : (GreenBlue ? GB : (GreenBlueRed ? GBR : (GreenMxBlueRed ? GBRX : p_G))); \n" \
	"									  \n" \
	"	float RG = p_R > p_G ? p_G : p_R;    \n" \
	"	float RB = p_R > p_B ? p_B : p_R;    \n" \
	"	float RBG = p_R > _fminf(p_B, p_G) ? _fminf(p_B, p_G) : p_R;    \n" \
	"	float RBGX = p_R > _fmaxf(p_B, p_G) ? _fmaxf(p_B, p_G) : p_R;    \n" \
	"	float red = RedGreen ? RG : (RedBlue ? RB : (RedBlueGreen ? RBG : (RedMxBlueGreen ? RBGX : p_R))); 					\n" \
	"											   \n" \
	"\n" \
	"	float highalpha = high + n == 0.0f ? 0.0f : high - (1.0f - highfade) >= n ? 1.0f : (high >= n ? _powf((high - n) / (1.0f - highfade), highfadecurve) : 0.0f);\n" \
	"	float lowalpha = low + n == 2.0f ? 0.0f : low + lowfade <= n ? 1.0f : (low <= n ? _powf((n - low) / lowfade, lowfadecurve) : 0.0f);\n" \
	"	float alpha = highalpha * lowalpha;\n" \
	"	float alphaM = alpha + (1.0f - alpha) * mix;\n" \
	"	float alphaV = InvertAlpha ? 1.0f - alphaM : alphaM;\n" \
	"																					  \n" \
	"	float r = DisplayMatte ? alphaV : p_R * (1.0f - alphaV) + (red * alphaV);		\n" \
	"	float g = DisplayMatte ? alphaV : p_G * (1.0f - alphaV) + (green * alphaV);\n" \
	"	float b = DisplayMatte ? alphaV : p_B * (1.0f - alphaV) + (blue * alphaV);\n" \
	"\n" \
	"	return make_float3(r, g, b);\n" \
	"}\n", display, invert, brChannelI, bgChannelI, bgrChannelI, bgrxChannelI, grChannelI, 
	gbChannelI, gbrChannelI, gbrxChannelI, rgChannelI, rbChannelI, rbgChannelI, rbgxChannelI, 
	high, highfade, low, lowfade, highfadecurve, lowfadecurve, offset, mix);
	fclose (pFile);
	} else {
     sendMessage(OFX::Message::eMessageError, "", string("Error: Cannot save " + NAME + ".dctl to " + PATH  + ". Check Permissions."));
	}	
	}
	}

	if(p_ParamName == "button2")
    {
    
    float high = m_ScaleR->getValueAtTime(p_Args.time);
    float highfade = m_ScaleG->getValueAtTime(p_Args.time);
    float lowfade = m_ScaleB->getValueAtTime(p_Args.time);
    float low = m_ScaleA->getValueAtTime(p_Args.time);
    float highfadecurve = m_ScaleD->getValueAtTime(p_Args.time);
    float lowfadecurve = m_ScaleE->getValueAtTime(p_Args.time);
    float offset = m_ScaleO->getValueAtTime(p_Args.time);
    float mix = m_ScaleZ->getValueAtTime(p_Args.time);
    
    bool Display = m_SwitchA->getValueAtTime(p_Args.time);
    bool Invert = m_SwitchB->getValueAtTime(p_Args.time);

	int display = Display ? 1 : 0;
	int invert = Invert ? 1 : 0;
	
	int channelBox_i;
    m_ChannelBox->getValueAtTime(p_Args.time, channelBox_i);
    ChannelBoxEnum channelBox = (ChannelBoxEnum)channelBox_i;
    
    int channel = channelBox_i;
    
 	string PATH;
	m_Path->getValue(PATH);
	
	string NAME;
	m_Name->getValue(NAME);
	
	OFX::Message::MessageReplyEnum reply = sendMessage(OFX::Message::eMessageQuestion, "", "Save " + NAME + ".nk to " + PATH + "?");
	if (reply == OFX::Message::eMessageReplyYes) {
	
	FILE * pFile;
	
	pFile = fopen ((PATH + "/" + NAME + ".nk").c_str(), "w");
	if (pFile != NULL) {
    	
	fprintf (pFile, "Group {\n" \
	" inputs 0\n" \
	" name ChannelBox\n" \
	" selected true\n" \
	" xpos -146\n" \
	" ypos 84\n" \
	"}\n" \
	" Input {\n" \
	"  inputs 0\n" \
	"  name Input1\n" \
	"  xpos -444\n" \
	"  ypos 136\n" \
	" }\n" \
	"set N14d6ab50 [stack 0]\n" \
	" Expression {\n" \
	"  temp_name0 high\n" \
	"  temp_expr0 %f\n" \
	"  temp_name1 highfade\n" \
	"  temp_expr1 %f\n" \
	"  temp_name2 highfadecurve\n" \
	"  temp_expr2 %f\n" \
	"  temp_name3 n\n" \
	"  temp_expr3 \"max(min((r * 0.2126 + g * 0.7152 + b * 0.0722) - %f, 1.0), 0.0)\"\n" \
	"  expr0 \"high + n == 0.0 ? 0.0 : high - (1.0 - highfade) >= n ? 1.0 : (high >= n ? pow((high - n) / (1.0 - highfade), highfadecurve) : 0.0)\"\n" \
	"  expr1 0\n" \
	"  expr2 0\n" \
	"  name highalpha\n" \
	"  xpos -618\n" \
	"  ypos 220\n" \
	" }\n" \
	"push $N14d6ab50\n" \
	" Expression {\n" \
	"  temp_name0 low\n" \
	"  temp_expr0 %f\n" \
	"  temp_name1 lowfade\n" \
	"  temp_expr1 %f\n" \
	"  temp_name2 lowfadecurve\n" \
	"  temp_expr2 %f\n" \
	"  temp_name3 n\n" \
	"  temp_expr3 \"max(min((r * 0.2126 + g * 0.7152 + b * 0.0722) %f, 1.0), 0.0)\"\n" \
	"  expr0 \"low + n == 2.0 ? 0.0 : low + lowfade <= n ? 1.0 : (low <= n ? pow((n - low) / lowfade, lowfadecurve) : 0.0)\"\n" \
	"  expr1 0\n" \
	"  expr2 0\n" \
	"  name lowalpha\n" \
	"  xpos -510\n" \
	"  ypos 218\n" \
	" }\n" \
	" MergeExpression {\n" \
	"  inputs 2\n" \
	"  temp_name0 mix\n" \
	"  temp_expr0 %f\n" \
	"  temp_name1 alpha\n" \
	"  temp_expr1 \"Ar * Br\"\n" \
	"  expr0 \"alpha + (1.0 - alpha) * mix\"\n" \
	"  expr1 \"alpha + (1.0 - alpha) * mix\"\n" \
	"  expr2 \"alpha + (1.0 - alpha) * mix\"\n" \
	"  name AlphaM\n" \
	"  xpos -566\n" \
	"  ypos 269\n" \
	" }\n" \
	"set N1d3dac70 [stack 0]\n" \
	" Expression {\n" \
	"  expr0 \"1.0 - r\"\n" \
	"  expr1 \"1.0 - r\"\n" \
	"  expr2 \"1.0 - r\"\n" \
	"  name invertAlpha\n" \
	"  xpos -608\n" \
	"  ypos 332\n" \
	" }\n" \
	"push $N1d3dac70\n" \
	" Switch {\n" \
	"  inputs 2\n" \
	"  which %d\n" \
	"  name Invert\n" \
	"  xpos -524\n" \
	"  ypos 366\n" \
	" }\n" \
	"set N1d3af0a0 [stack 0]\n" \
	"push $N1d3af0a0\n" \
	"push $N14d6ab50\n" \
	" Dot {\n" \
	"  name Dot1\n" \
	"  xpos -277\n" \
	"  ypos 139\n" \
	" }\n" \
	"set N1efa7e80 [stack 0]\n" \
	" Dot {\n" \
	"  name Dot4\n" \
	"  xpos 2\n" \
	"  ypos 291\n" \
	" }\n" \
	"set N223e4b40 [stack 0]\n" \
	" Expression {\n" \
	"  expr0 \"r > max(b, g) ? max(b, g) : r\"\n" \
	"  expr1 g\n" \
	"  expr2 b\n" \
	"  name redmaxbluegreen\n" \
	"  xpos 74\n" \
	"  ypos 284\n" \
	" }\n" \
	" Dot {\n" \
	"  name Dot9\n" \
	"  xpos -24\n" \
	"  ypos 417\n" \
	" }\n" \
	"push $N223e4b40\n" \
	" Expression {\n" \
	"  expr0 \"r > min(b, g) ? min(b, g) : r\"\n" \
	"  expr1 g\n" \
	"  expr2 b\n" \
	"  name redbluegreen\n" \
	"  xpos 71\n" \
	"  ypos 347\n" \
	" }\n" \
	" Dot {\n" \
	"  name Dot8\n" \
	"  xpos -13\n" \
	"  ypos 441\n" \
	" }\n" \
	"push $N223e4b40\n" \
	" Expression {\n" \
	"  expr0 \"r > b ? b : r\"\n" \
	"  expr1 g\n" \
	"  expr2 b\n" \
	"  name redblue\n" \
	"  xpos -42\n" \
	"  ypos 347\n" \
	" }\n" \
	" Dot {\n" \
	"  name Dot10\n" \
	"  xpos -61\n" \
	"  ypos 404\n" \
	" }\n" \
	"push $N223e4b40\n" \
	" Expression {\n" \
	"  expr0 \"r > g ? g : r\"\n" \
	"  expr1 g\n" \
	"  expr2 b\n" \
	"  name redgreen\n" \
	"  xpos -78\n" \
	"  ypos 322\n" \
	" }\n" \
	" Dot {\n" \
	"  name Dot11\n" \
	"  xpos -99\n" \
	"  ypos 389\n" \
	" }\n" \
	"push $N1efa7e80\n" \
	" Dot {\n" \
	"  name Dot2\n" \
	"  xpos -59\n" \
	"  ypos 139\n" \
	" }\n" \
	"set N223f3e30 [stack 0]\n" \
	" Expression {\n" \
	"  expr0 r\n" \
	"  expr1 \"g > max(b, r) ? max(b, r) : g\"\n" \
	"  expr2 b\n" \
	"  name greenmaxbluered\n" \
	"  xpos 43\n" \
	"  ypos 159\n" \
	" }\n" \
	" Dot {\n" \
	"  name Dot13\n" \
	"  xpos -76\n" \
	"  ypos 299\n" \
	" }\n" \
	"push $N223f3e30\n" \
	" Expression {\n" \
	"  expr0 r\n" \
	"  expr1 \"g > min(b, r) ? min(b, r) : g\"\n" \
	"  expr2 b\n" \
	"  name greenbluered\n" \
	"  xpos -42\n" \
	"  ypos 184\n" \
	" }\n" \
	" Dot {\n" \
	"  name Dot12\n" \
	"  xpos -111\n" \
	"  ypos 302\n" \
	" }\n" \
	"push $N223f3e30\n" \
	" Expression {\n" \
	"  expr0 r\n" \
	"  expr1 \"g > b ? b : g\"\n" \
	"  expr2 b\n" \
	"  name greenblue\n" \
	"  xpos -118\n" \
	"  ypos 204\n" \
	" }\n" \
	"push $N223f3e30\n" \
	" Expression {\n" \
	"  expr0 r\n" \
	"  expr1 \"g > r ? r ? g\"\n" \
	"  expr2 b\n" \
	"  name greenred\n" \
	"  xpos -178\n" \
	"  ypos 175\n" \
	" }\n" \
	"push $N1efa7e80\n" \
	" Dot {\n" \
	"  name Dot3\n" \
	"  xpos -277\n" \
	"  ypos 231\n" \
	" }\n" \
	"set N246337a0 [stack 0]\n" \
	" Expression {\n" \
	"  expr0 r\n" \
	"  expr1 g\n" \
	"  expr2 \"b > max(g, r) ? max(g, r) : b\"\n" \
	"  name bluemaxgreenred\n" \
	"  xpos -218\n" \
	"  ypos 228\n" \
	" }\n" \
	"push $N246337a0\n" \
	" Expression {\n" \
	"  expr0 r\n" \
	"  expr1 g\n" \
	"  expr2 \"b > min(g, r) ? min(g, r) : b\"\n" \
	"  name bluegreenred\n" \
	"  xpos -258\n" \
	"  ypos 280\n" \
	" }\n" \
	" Dot {\n" \
	"  name Dot7\n" \
	"  xpos -250\n" \
	"  ypos 351\n" \
	" }\n" \
	"push $N246337a0\n" \
	" Expression {\n" \
	"  expr0 r\n" \
	"  expr1 g\n" \
	"  expr2 \"b > g ? g : b\"\n" \
	"  name bluegreen\n" \
	"  xpos -354\n" \
	"  ypos 277\n" \
	" }\n" \
	" Dot {\n" \
	"  name Dot6\n" \
	"  xpos -320\n" \
	"  ypos 354\n" \
	" }\n" \
	"push $N246337a0\n" \
	" Expression {\n" \
	"  expr0 r\n" \
	"  expr1 g\n" \
	"  expr2 \"b > r ? r : b\"\n" \
	"  name bluered\n" \
	"  xpos -401\n" \
	"  ypos 246\n" \
	" }\n" \
	" Dot {\n" \
	"  name Dot5\n" \
	"  xpos -389\n" \
	"  ypos 357\n" \
	" }\n" \
	" Switch {\n" \
	"  inputs 12\n" \
	"  which %d\n" \
	"  name channel_switch\n" \
	"  xpos -240\n" \
	"  ypos 466\n" \
	" }\n" \
	" ShuffleCopy {\n" \
	"  inputs 2\n" \
	"  alpha red\n" \
	"  name channel_plus_alpha\n" \
	"  xpos -265\n" \
	"  ypos 514\n" \
	" }\n" \
	" Expression {\n" \
	"  expr0 \"r * a + r * (1.0 - a)\"\n" \
	"  expr1 \"g * a + g * (1.0 - a)\"\n" \
	"  expr2 \"b * a + b * (1.0 - a)\"\n" \
	"  name mult\n" \
	"  xpos -340\n" \
	"  ypos 556\n" \
	" }\n" \
	" Switch {\n" \
	"  inputs 2\n" \
	"  which %d\n" \
	"  name Display_matte\n" \
	"  xpos -439\n" \
	"  ypos 614\n" \
	" }\n" \
	" Output {\n" \
	"  name Output1\n" \
	"  xpos -439\n" \
	"  ypos 670\n" \
	" }\n" \
	"end_group\n", high, highfade, highfadecurve, offset, low, lowfade, 
	lowfadecurve, offset, mix, invert, channel, display);
	fclose (pFile);
	} else {
     sendMessage(OFX::Message::eMessageError, "", string("Error: Cannot save " + NAME + ".nk to " + PATH  + ". Check Permissions."));
	}	
	}
	}
 	   
    if (p_ParamName == "sample")
    {
        
    RGBValues sample;
    m_Sample->getValueAtTime(p_Args.time, sample.r, sample.g, sample.b);
    float luma = (sample.r * 0.2126) + (sample.g * 0.7152) + (sample.b * 0.0722);
    float L1 = luma + 0.1 > 1.0 ? 1.0 : luma + 0.1;
    float L2 = luma - 0.1 < 0.0 ? 0.0 : luma - 0.1;
    float L3 = luma > 0.9 ? 1.0 : 0.95;
    float L4 = luma < 0.1 ? 0.0 : 0.05;
    m_ScaleL->setValue(luma);
    m_ScaleR->setValue(L1);
    m_ScaleG->setValue(L3);
    m_ScaleB->setValue(L4);
    m_ScaleA->setValue(L2);
    
    }
    
    if (p_ParamName == "luma")
    {
    float luma = m_ScaleL->getValueAtTime(p_Args.time);
    float L1 = luma + 0.1 > 1.0 ? 1.0 : luma + 0.1;
    float L2 = luma - 0.1 < 0.0 ? 0.0 : luma - 0.1;
    float L3 = luma > 0.9 ? 1.0 : 0.95;
    float L4 = luma < 0.1 ? 0.0 : 0.05;
    m_ScaleR->setValue(L1);
    m_ScaleG->setValue(L3);
    m_ScaleB->setValue(L4);
    m_ScaleA->setValue(L2);
    
    }
    
}

void ChannelBoxPlugin::setupAndProcess(ChannelBox& p_ChannelBox, const OFX::RenderArguments& p_Args)
{
    // Get the dst image
    std::auto_ptr<OFX::Image> dst(m_DstClip->fetchImage(p_Args.time));
    OFX::BitDepthEnum dstBitDepth = dst->getPixelDepth();
    OFX::PixelComponentEnum dstComponents = dst->getPixelComponents();

    // Get the src image
    std::auto_ptr<OFX::Image> src(m_SrcClip->fetchImage(p_Args.time));
    OFX::BitDepthEnum srcBitDepth = src->getPixelDepth();
    OFX::PixelComponentEnum srcComponents = src->getPixelComponents();

    // Check to see if the bit depth and number of components are the same
    if ((srcBitDepth != dstBitDepth) || (srcComponents != dstComponents))
    {
        OFX::throwSuiteStatusException(kOfxStatErrValue);
    }

    int channelBox_i;
    m_ChannelBox->getValueAtTime(p_Args.time, channelBox_i);
    ChannelBoxEnum channelBox = (ChannelBoxEnum)channelBox_i;
    
    bool brChannel = channelBox_i == 0;
    bool bgChannel = channelBox_i == 1;
    bool bgrChannel = channelBox_i == 2;
    bool bgrxChannel = channelBox_i == 3;
    bool grChannel = channelBox_i == 4;
    bool gbChannel = channelBox_i == 5;
    bool gbrChannel = channelBox_i == 6;
    bool gbrxChannel = channelBox_i == 7;
    bool rgChannel = channelBox_i == 8;
    bool rbChannel = channelBox_i == 9;
    bool rbgChannel = channelBox_i == 10;
    bool rbgxChannel = channelBox_i == 11;

	float brChannelF = brChannel ? 1.0f : 0.0f;
	float bgChannelF = bgChannel ? 1.0f : 0.0f;
	float bgrChannelF = bgrChannel ? 1.0f : 0.0f;
	float bgrxChannelF = bgrxChannel ? 1.0f : 0.0f;
	float grChannelF = grChannel ? 1.0f : 0.0f;
	float gbChannelF = gbChannel ? 1.0f : 0.0f;
	float gbrChannelF = gbrChannel ? 1.0f : 0.0f;
	float gbrxChannelF = gbrxChannel ? 1.0f : 0.0f;
	float rgChannelF = rgChannel ? 1.0f : 0.0f;
	float rbChannelF = rbChannel ? 1.0f : 0.0f;
	float rbgChannelF = rbgChannel ? 1.0f : 0.0f;
	float rbgxChannelF = rbgxChannel ? 1.0f : 0.0f;

    
    float rScale = m_ScaleR->getValueAtTime(p_Args.time);
    float gScale = m_ScaleG->getValueAtTime(p_Args.time);
    float bScale = m_ScaleB->getValueAtTime(p_Args.time);
    float aScale = m_ScaleA->getValueAtTime(p_Args.time);
    float dScale = m_ScaleD->getValueAtTime(p_Args.time);
    float eScale = m_ScaleE->getValueAtTime(p_Args.time);
    float oScale = m_ScaleO->getValueAtTime(p_Args.time);
    float zScale = m_ScaleZ->getValueAtTime(p_Args.time);
    
    bool aSwitch = m_SwitchA->getValueAtTime(p_Args.time);
    bool bSwitch = m_SwitchB->getValueAtTime(p_Args.time);

	float aSwitchF = aSwitch ? 1.0f : 0.0f;
	float bSwitchF = bSwitch ? 1.0f : 0.0f;


    // Set the images
    p_ChannelBox.setDstImg(dst.get());
    p_ChannelBox.setSrcImg(src.get());

    // Setup OpenCL and CUDA Render arguments
    p_ChannelBox.setGPURenderArgs(p_Args);

    // Set the render window
    p_ChannelBox.setRenderWindow(p_Args.renderWindow);

    // Set the scales
    p_ChannelBox.setScales(brChannelF, bgChannelF, bgrChannelF, bgrxChannelF, grChannelF, gbChannelF,
     gbrChannelF, gbrxChannelF, rgChannelF, rbChannelF, rbgChannelF, rbgxChannelF, rScale, gScale,
      bScale, aScale, dScale, eScale, oScale, zScale, aSwitchF, bSwitchF);

    // Call the base class process member, this will call the derived templated process code
    p_ChannelBox.process();
}

////////////////////////////////////////////////////////////////////////////////

using namespace OFX;

ChannelBoxPluginFactory::ChannelBoxPluginFactory()
    : OFX::PluginFactoryHelper<ChannelBoxPluginFactory>(kPluginIdentifier, kPluginVersionMajor, kPluginVersionMinor)
{
}

void ChannelBoxPluginFactory::describe(OFX::ImageEffectDescriptor& p_Desc)
{
    // Basic labels
    p_Desc.setLabels(kPluginName, kPluginName, kPluginName);
    p_Desc.setPluginGrouping(kPluginGrouping);
    p_Desc.setPluginDescription(kPluginDescription);

    // Add the supported contexts, only filter at the moment
    p_Desc.addSupportedContext(eContextFilter);
    p_Desc.addSupportedContext(eContextGeneral);

    // Add supported pixel depths
    p_Desc.addSupportedBitDepth(eBitDepthFloat);

    // Set a few flags
    p_Desc.setSingleInstance(false);
    p_Desc.setHostFrameThreading(false);
    p_Desc.setSupportsMultiResolution(kSupportsMultiResolution);
    p_Desc.setSupportsTiles(kSupportsTiles);
    p_Desc.setTemporalClipAccess(false);
    p_Desc.setRenderTwiceAlways(false);
    p_Desc.setSupportsMultipleClipPARs(kSupportsMultipleClipPARs);

    // Setup OpenCL and CUDA render capability flags
    p_Desc.setSupportsOpenCLRender(true);
}

static DoubleParamDescriptor* defineScaleParam(OFX::ImageEffectDescriptor& p_Desc, const std::string& p_Name, const std::string& p_Label,
                                               const std::string& p_Hint, GroupParamDescriptor* p_Parent)
{
    DoubleParamDescriptor* param = p_Desc.defineDoubleParam(p_Name);
    param->setLabels(p_Label, p_Label, p_Label);
    param->setScriptName(p_Name);
    param->setHint(p_Hint);
    param->setDefault(1.0);
    param->setRange(0.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(0.0, 1.0);
    param->setDoubleType(eDoubleTypeScale);

    if (p_Parent)
    {
        param->setParent(*p_Parent);
    }

    return param;
}


void ChannelBoxPluginFactory::describeInContext(OFX::ImageEffectDescriptor& p_Desc, OFX::ContextEnum /*p_Context*/)
{
    // Source clip only in the filter context
    // Create the mandated source clip
    ClipDescriptor* srcClip = p_Desc.defineClip(kOfxImageEffectSimpleSourceClipName);
    srcClip->addSupportedComponent(ePixelComponentRGBA);
    srcClip->setTemporalClipAccess(false);
    srcClip->setSupportsTiles(kSupportsTiles);
    srcClip->setIsMask(false);

    // Create the mandated output clip
    ClipDescriptor* dstClip = p_Desc.defineClip(kOfxImageEffectOutputClipName);
    dstClip->addSupportedComponent(ePixelComponentRGBA);
    dstClip->addSupportedComponent(ePixelComponentAlpha);
    dstClip->setSupportsTiles(kSupportsTiles);

    // Make some pages and to things in
    PageParamDescriptor* page = p_Desc.definePageParam("Controls");
    
    {
    
    //Drop down menu
    ChoiceParamDescriptor* choiceparam = p_Desc.defineChoiceParam("channelBox");
    choiceparam->setLabel(kParamChannelBoxLabel);
    choiceparam->setHint(kParamChannelBoxHint);
    assert(choiceparam->getNOptions() == eChannelBoxBR);
    choiceparam->appendOption(kParamChannelBoxOptionBR, kParamChannelBoxOptionBRHint);
    assert(choiceparam->getNOptions() == eChannelBoxBG);
    choiceparam->appendOption(kParamChannelBoxOptionBG, kParamChannelBoxOptionBGHint);
    assert(choiceparam->getNOptions() == eChannelBoxBGR);
    choiceparam->appendOption(kParamChannelBoxOptionBGR, kParamChannelBoxOptionBGRHint);
    assert(choiceparam->getNOptions() == eChannelBoxBGRX);
    choiceparam->appendOption(kParamChannelBoxOptionBGRX, kParamChannelBoxOptionBGRXHint);
    assert(choiceparam->getNOptions() == eChannelBoxGR);
    choiceparam->appendOption(kParamChannelBoxOptionGR, kParamChannelBoxOptionGRHint);
    assert(choiceparam->getNOptions() == eChannelBoxGB);
    choiceparam->appendOption(kParamChannelBoxOptionGB, kParamChannelBoxOptionGBHint);
    assert(choiceparam->getNOptions() == eChannelBoxGBR);
    choiceparam->appendOption(kParamChannelBoxOptionGBR, kParamChannelBoxOptionGBRHint);
    assert(choiceparam->getNOptions() == eChannelBoxGBRX);
    choiceparam->appendOption(kParamChannelBoxOptionGBRX, kParamChannelBoxOptionGBRXHint);
    assert(choiceparam->getNOptions() == eChannelBoxRG);
    choiceparam->appendOption(kParamChannelBoxOptionRG, kParamChannelBoxOptionRGHint);
    assert(choiceparam->getNOptions() == eChannelBoxRB);
    choiceparam->appendOption(kParamChannelBoxOptionRB, kParamChannelBoxOptionRBHint);
    assert(choiceparam->getNOptions() == eChannelBoxRBG);
    choiceparam->appendOption(kParamChannelBoxOptionRBG, kParamChannelBoxOptionRBGHint);
    assert(choiceparam->getNOptions() == eChannelBoxRBGX);
    choiceparam->appendOption(kParamChannelBoxOptionRBGX, kParamChannelBoxOptionRBGXHint);
    page->addChild(*choiceparam);
    
    }
    
    {
    PushButtonParamDescriptor* param = p_Desc.definePushButtonParam("info");
    param->setLabel("Info");
    page->addChild(*param);
    }

   // Group param to group the scales
    GroupParamDescriptor* componentScalesGroup = p_Desc.defineGroupParam("alphaChannel");
    componentScalesGroup->setOpen(false);
    componentScalesGroup->setHint("Pull Luma Key");
    componentScalesGroup->setLabel("Luma Range");
    
    {
    
    // Add a boolean to enable the component scale
    BooleanParamDescriptor* boolParam = p_Desc.defineBooleanParam("display");
    boolParam->setDefault(false);
    boolParam->setHint("Displays alpha on RGB Channels");
    boolParam->setLabel("Display Matte");
    boolParam->setParent(*componentScalesGroup);
    page->addChild(*boolParam);
    
    boolParam = p_Desc.defineBooleanParam("invertAlpha");
    boolParam->setDefault(false);
    boolParam->setHint("Inverts the Alpha Channel");
    boolParam->setLabel("Invert");
    boolParam->setParent(*componentScalesGroup);
    page->addChild(*boolParam);

    }

	RGBParamDescriptor *rgbparam = p_Desc.defineRGBParam("sample");
	rgbparam->setLabel("Luma Sample");
	rgbparam->setHint("click on pixel");
	rgbparam->setDefault(1.0, 1.0, 1.0);
	rgbparam->setDisplayRange(0.0, 0.0, 0.0, 4.0, 4.0, 4.0);
	rgbparam->setAnimates(true); // can animate
	rgbparam->setParent(*componentScalesGroup);
	page->addChild(*rgbparam);
       
	DoubleParamDescriptor* param = defineScaleParam(p_Desc, "luma", "luma", "luma from sample", componentScalesGroup);
	param->setDefault(1.0);
	param->setRange(0.0, 1.0);
	param->setIncrement(0.001);
	param->setDisplayRange(0.0, 1.0);
	param->setParent(*componentScalesGroup);
	page->addChild(*param);
    

    // Make the four component scale params
    param = defineScaleParam(p_Desc, "scaleR", "high", "High limit of alpha channel", componentScalesGroup);
    page->addChild(*param);

    param = defineScaleParam(p_Desc, "scaleG", "high fade", "Roll-off between high limit", componentScalesGroup);
    page->addChild(*param);

    param = defineScaleParam(p_Desc, "scaleB", "low fade", "Roll-off between low limit", componentScalesGroup);
    param->setDefault(0.0);
    param->setRange(0.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(0.0, 1.0);
    page->addChild(*param);

    param = defineScaleParam(p_Desc, "scaleA", "low", "Low limit of alpha channel", componentScalesGroup);
    param->setDefault(0.0);
    param->setRange(0.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(0.0, 1.0);
    page->addChild(*param);
    
    param = defineScaleParam(p_Desc, "scaleD", "high fade curve", "Easy out / Easy in", componentScalesGroup);
    param->setDefault(1.0);
    param->setRange(0.2, 5.0);
    param->setIncrement(0.001);
    param->setDisplayRange(0.2, 5.0);
    page->addChild(*param);
    
    param = defineScaleParam(p_Desc, "scaleE", "low fade curve", "Easy out / Easy in", componentScalesGroup);
    param->setDefault(1.0);
    param->setRange(0.2, 5.0);
    param->setIncrement(0.001);
    param->setDisplayRange(0.2, 5.0);
    page->addChild(*param);
    
    param = defineScaleParam(p_Desc, "scaleO", "offset", "Offsets the alpha range", componentScalesGroup);
    param->setDefault(0.0);
    param->setRange(-1.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(-1.0, 1.0);
    page->addChild(*param);
    
    param = defineScaleParam(p_Desc, "scaleZ", "mix", "Blends new alpha with original alpha", componentScalesGroup);
    param->setDefault(0.0);
    param->setRange(0.0, 1.0);
    param->setIncrement(0.001);
    param->setDisplayRange(0.0, 1.0);
    page->addChild(*param);
    
    {    
    GroupParamDescriptor* script = p_Desc.defineGroupParam("Script Export");
    script->setOpen(false);
    script->setHint("export DCTL and Nuke script");
      if (page) {
            page->addChild(*script);
            }
    {
    PushButtonParamDescriptor* param = p_Desc.definePushButtonParam("button1");
    param->setLabel("Export DCTL");
    param->setHint("create DCTL version");
    param->setParent(*script);
    page->addChild(*param);
    }
    {
    PushButtonParamDescriptor* param = p_Desc.definePushButtonParam("button2");
    param->setLabel("Export Nuke script");
    param->setHint("create NUKE version");
    param->setParent(*script);
    page->addChild(*param);
    }
    {
	StringParamDescriptor* param = p_Desc.defineStringParam("name");
	param->setLabel("Name");
	param->setHint("overwrites if the same");
	param->setDefault("ChannelBox");
	param->setParent(*script);
	page->addChild(*param);
	}
	{
	StringParamDescriptor* param = p_Desc.defineStringParam("path");
	param->setLabel("Directory");
	param->setHint("make sure it's the absolute path");
	param->setStringType(eStringTypeFilePath);
	param->setDefault(kPluginScript);
	param->setFilePathExists(false);
	param->setParent(*script);
	page->addChild(*param);
	}
	}        
    
}

ImageEffect* ChannelBoxPluginFactory::createInstance(OfxImageEffectHandle p_Handle, ContextEnum /*p_Context*/)
{
    return new ChannelBoxPlugin(p_Handle);
}

void OFX::Plugin::getPluginIDs(PluginFactoryArray& p_FactoryArray)
{
    static ChannelBoxPluginFactory ChannelBoxPlugin;
    p_FactoryArray.push_back(&ChannelBoxPlugin);
}
