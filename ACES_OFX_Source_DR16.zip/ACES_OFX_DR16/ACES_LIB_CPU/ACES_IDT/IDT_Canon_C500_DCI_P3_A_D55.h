#ifndef __IDT_CANON_C500_DCI_P3_A_D55_H_INCLUDED__
#define __IDT_CANON_C500_DCI_P3_A_D55_H_INCLUDED__

inline float3 IDT_Canon_C500_DCI_P3_A_D55( float3 In)
{
float3 CLogIRE;
CLogIRE.x = (In.x * 1023.0f - 64.0f) / 876.0f;
CLogIRE.y = (In.y * 1023.0f - 64.0f) / 876.0f;
CLogIRE.z = (In.z * 1023.0f - 64.0f) / 876.0f;

float3 lin;
lin.x = 0.9f * CanonLog_to_linear( CLogIRE.x);
lin.y = 0.9f * CanonLog_to_linear( CLogIRE.y);
lin.z = 0.9f * CanonLog_to_linear( CLogIRE.z);

float3 aces;
aces.x =  0.607160575f * lin.x + 0.299507286f * lin.y + 0.093332140f * lin.z;
aces.y =  0.004968120f * lin.x + 1.050982224f * lin.y - 0.055950343f * lin.z;
aces.z = -0.007839939f * lin.x + 0.000809127f * lin.y + 1.007030813f * lin.z;

return aces;
}

#endif