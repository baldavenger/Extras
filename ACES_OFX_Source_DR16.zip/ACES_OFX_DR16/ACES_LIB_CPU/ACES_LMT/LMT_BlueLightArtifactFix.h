#ifndef __ACES_LMT_BLUELIGHTARTIFACTFIX_H_INCLUDED__
#define __ACES_LMT_BLUELIGHTARTIFACTFIX_H_INCLUDED__

#include "../ACES_LMT.h"

inline float3 LMT_BlueLightArtifactFix( float3 aces)
{
/*
mat3 correctionMatrix = 
{ { 0.9404372683f, -0.0183068787f, 0.0778696104f }, 
{ 0.0083786969f, 0.8286599939f, 0.1629613092f },
{ 0.0005471261f, -0.0008833746f, 1.0003362486f } };
*/

mat3 correctionMatrix = 
{ {0.9404372683f, 0.0083786969f, 0.0005471261f },
{-0.0183068787f, 0.8286599939f, -0.0008833746f },
{ 0.0778696104f, 0.1629613092f, 1.0003362486f } };

float3 acesMod = mult_f3_f33( aces, correctionMatrix);

return acesMod;
}

#endif