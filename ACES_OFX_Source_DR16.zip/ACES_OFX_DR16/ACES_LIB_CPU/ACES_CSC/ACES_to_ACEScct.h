#ifndef __ACES_TO_ACESCCT_H_INCLUDED__
#define __ACES_TO_ACESCCT_H_INCLUDED__

inline float lin_to_ACEScct( float in)
{
if (in <= X_BRK)
return A * in + B;
else
return (log2f(in) + 9.72f) / 17.52f;
}

inline float3 ACES_to_ACEScct( float3 ACES)
{
float3 lin_AP1 = mult_f3_f33( ACES, AP0_2_AP1_MAT);
float3 out;
out.x = lin_to_ACEScct( lin_AP1.x);
out.y = lin_to_ACEScct( lin_AP1.y);
out.z = lin_to_ACEScct( lin_AP1.z);
return out;
}

#endif