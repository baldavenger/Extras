#ifndef __IDT_SONY_SLOG3_SGAMUT3_H_INCLUDED__
#define __IDT_SONY_SLOG3_SGAMUT3_H_INCLUDED__

__device__ inline float3 IDT_Sony_SLog3_SGamut3( float3 SLog3)
{
mat3 matrixCoef = { {0.7529825954f, 0.0217076974f, -0.0094160528f}, {0.1433702162f, 1.0153188355f, 0.0033704179f}, {0.1036471884f, -0.0370265329f, 1.0060456349f} };

float3 linear;
linear.x = SLog3_to_linear( SLog3.x );
linear.y = SLog3_to_linear( SLog3.y );
linear.z = SLog3_to_linear( SLog3.z );

float3 aces = mult_f3_f33( linear, matrixCoef );

return aces;
}

#endif
