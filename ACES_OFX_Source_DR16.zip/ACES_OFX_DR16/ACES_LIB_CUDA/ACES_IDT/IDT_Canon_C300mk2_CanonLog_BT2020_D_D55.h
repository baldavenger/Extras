#ifndef __IDT_CANON_C300MK2_CANONLOG_BT2020_D_D55_H_INCLUDED__
#define __IDT_CANON_C300MK2_CANONLOG_BT2020_D_D55_H_INCLUDED__

__device__ inline float3 IDT_Canon_C300mk2_CanonLog_BT2020_D_D55( float3 In)
{
float3 CLogIRE;
CLogIRE.x = (In.x * 1023.0f - 64.0f) / 876.0f;
CLogIRE.y = (In.y * 1023.0f - 64.0f) / 876.0f;
CLogIRE.z = (In.z * 1023.0f - 64.0f) / 876.0f;

float3 lin;
lin.x = 0.9f * CanonLog_to_linear( CLogIRE.x);
lin.y = 0.9f * CanonLog_to_linear( CLogIRE.y);
lin.z = 0.9f * CanonLog_to_linear( CLogIRE.z);

float3 aces;
aces.x =  0.678891151f * lin.x + 0.158868422f * lin.y + 0.162240427f * lin.z;
aces.y =  0.045570831f * lin.x + 0.860712772f * lin.y + 0.093716397f * lin.z;
aces.z = -0.000485710f * lin.x + 0.025060196f * lin.y + 0.975425515f * lin.z;

return aces;
}

#endif