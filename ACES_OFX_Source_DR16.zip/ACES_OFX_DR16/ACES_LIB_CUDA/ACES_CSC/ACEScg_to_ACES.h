#ifndef __ACESCG_TO_ACES_H_INCLUDED__
#define __ACESCG_TO_ACES_H_INCLUDED__

__device__ inline float3 ACEScg_to_ACES( float3 ACEScg)
{
float3 ACES = mult_f3_f44( ACEScg, AP1_2_AP0_MAT);
return ACES;
}

#endif