#ifndef __ACES_LMT_ANALYTIC_1C_H_INCLUDED__
#define __ACES_LMT_ANALYTIC_1C_H_INCLUDED__

#include "../ACES_LMT.h"

__device__ inline float3 LMT_Analytic_1c( float3 aces)
{
const float GAMMA = 0.6f;
aces = gamma_adjust_linear( aces, GAMMA);
const float SAT_FACTOR = 0.85f;
aces = sat_adjust( aces, SAT_FACTOR);

return aces;
}

#endif