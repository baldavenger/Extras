#ifndef __ODT_DCDM_P3D65LIMITED_H_INCLUDED__
#define __ODT_DCDM_P3D65LIMITED_H_INCLUDED__

inline float3 ODT_DCDM_P3D65limited( float3 oces)
{
const Chromaticities LIMITING_PRI = P3D65_PRI;

float3 rgbPre = mult_f3_f33( oces, AP0_2_AP1_MAT);
float3 rgbPost;
rgbPost.x = segmented_spline_c9_fwd( rgbPre.x, ODT_48nits());
rgbPost.y = segmented_spline_c9_fwd( rgbPre.y, ODT_48nits());
rgbPost.z = segmented_spline_c9_fwd( rgbPre.z, ODT_48nits());

float3 linearCV;
linearCV.x = Y_2_linCV( rgbPost.x, CINEMA_WHITE, CINEMA_BLACK);
linearCV.y = Y_2_linCV( rgbPost.y, CINEMA_WHITE, CINEMA_BLACK);
linearCV.z = Y_2_linCV( rgbPost.z, CINEMA_WHITE, CINEMA_BLACK);

float3 XYZ = mult_f3_f33( linearCV, AP1_2_XYZ_MAT);
XYZ = limit_to_primaries( XYZ, LIMITING_PRI);
float3 outputCV = dcdm_encode( XYZ);

return outputCV;
}

#endif