#ifndef __IDT_CANON_C500_A_TNG_H_INCLUDED__
#define __IDT_CANON_C500_A_TNG_H_INCLUDED__

inline float3 IDT_Canon_C500_A_Tng( float3 In) 
{
float3 CLogIRE;
CLogIRE.x = (In.x * 1023 - 64) / 876;
CLogIRE.y = (In.y * 1023 - 64) / 876;
CLogIRE.z = (In.z * 1023 - 64) / 876;

float3 lin;
lin.x = CanonLog_to_linear( CLogIRE.x);
lin.y = CanonLog_to_linear( CLogIRE.y);
lin.z = CanonLog_to_linear( CLogIRE.z);

float3 aces;
aces.x = 0.566996399 * lin.x +0.365079418 * lin.y + 0.067924183 * lin.z;
aces.y = 0.070901044 * lin.x +0.880331008 * lin.y + 0.048767948 * lin.z;
aces.z = 0.073013542 * lin.x -0.066540862 * lin.y + 0.99352732 * lin.z;

return aces;
}

#endif