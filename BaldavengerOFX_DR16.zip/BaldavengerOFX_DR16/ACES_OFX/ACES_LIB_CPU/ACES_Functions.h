#ifndef __ACES_FUNCTIONS_H_INCLUDED__
#define __ACES_FUNCTIONS_H_INCLUDED__

#include <cmath>

typedef struct
{
float x, y;
} float2;

typedef struct
{
float x, y, z;
} float3;

typedef struct
{
float x, y, z, w;
} float4;

typedef struct
{
float x, y, z, w, m;
} float5;

typedef struct
{
float2 c0, c1;
} mat2;

typedef struct
{
float3 c0, c1, c2;
} mat3;

typedef struct
{
float2 red; float2 green; float2 blue; float2 white;
} Chromaticities;

#ifndef M_PI
#define M_PI	3.14159265358979323846264338327950288f
#endif

inline int size(float array[])
{
int Size = sizeof(&array)/sizeof(array[0]);
return Size + 1;
}

inline int size(float2 array[])
{
int Size = sizeof(&array)/sizeof(array[0]);
return Size + 1;
}

inline int size(float3 array[])
{
int Size = sizeof(&array)/sizeof(array[0]);
return Size + 1;
}

inline Chromaticities make_chromaticities( float2 A, float2 B, float2 C, float2 D)
{
Chromaticities E;
E.red = A; E.green = B; E.blue = C; E.white = D;
return E;
}

inline float2 make_float2(float A, float B)
{
float2 C;
C.x = A;
C.y = B;
return C;
}

inline float3 make_float3(float A, float B, float C)
{
float3 D;
D.x = A;
D.y = B;
D.z = C;
return D;
}

inline float4 make_float4(float A, float B, float C, float D)
{
float4 E;
E.x = A;
E.y = B;
E.z = C;
E.w = D;
return E;
}

inline float4 make_float4(float3 A, float B)
{
float4 C = make_float4(A.x, A.y, A.z, B);
return C;
}

inline mat2 make_mat2( float2 A, float2 B)
{
mat2 C;
C.c0 = A; C.c1 = B;
return C;
}

inline mat3 make_mat3( float3 A, float3 B, float3 C)
{
mat3 D;
D.c0 = A; D.c1 = B; D.c2 = C;
return D;
}

inline float min_f3( float3 a)
{
return fminf( a.x, fminf( a.y, a.z));
}

inline float max_f3( float3 a)
{
return fmaxf( a.x, fmaxf( a.y, a.z));
}

inline float3 max_f3_f( float3 a, float b)
{
float3 out;
out.x = fmaxf(a.x, b); out.y = fmaxf(a.y, b); out.z = fmaxf(a.z, b);
return out;
}

inline float clip( float v)
{
return fminf(v, 1.0f);
}

inline float3 clip_f3( float3 in)
{
float3 out;
out.x = clip( in.x); out.y = clip( in.y); out.z = clip( in.z);
return out;
}

inline float3 add_f_f3( float a, float3 b)
{
float3 out;
out.x = a + b.x; out.y = a + b.y; out.z = a + b.z;
return out;
}

inline float3 pow_f3( float3 a, float b)
{
float3 out;
out.x = powf(a.x, b); out.y = powf(a.y, b); out.z = powf(a.z, b);
return out;
}

inline float pow10f( float x)
{
return powf(10.0f, x);
}

inline float3 pow10_f3( float3 a)
{
float3 out;
out.x = pow10f(a.x); out.y = pow10f(a.y); out.z = pow10f(a.z);
return out;
}

inline float3 log10_f3( float3 a)
{
float3 out;
out.x = log10f(a.x); out.y = log10f(a.y); out.z = log10f(a.z);
return out;
}

inline int sign( float x)
{
int y;
if (x < 0) y = -1;
else if (x > 0) y = 1;
else y = 0;
return y;
}

inline float3 mult_f3_f( float3 x, float f)
{
float3 r;
r.x = f * x.x; r.y = f * x.y; r.z = f * x.z;
return r;
}

inline float3 mult_f_f3( float f, float3 x)
{
float3 r;
r.x = f * x.x; r.y = f * x.y; r.z = f * x.z;
return r;
}

inline float3 add_f3_f3( float3 x, float3 y)
{
float3 r;
r.x = x.x + y.x; r.y = x.y + y.y; r.z = x.z + y.z;
return r;
}

inline float3 sub_f3_f( float3 x, float y)
{
float3 r;
r.x = x.x - y; r.y = x.y - y; r.z = x.z - y;
return r;
}

inline float3 sub_f3_f3( float3 x, float3 y)
{
float3 r;
r.x = x.x - y.x; r.y = x.y - y.y; r.z = x.z - y.z;
return r;
}

inline float3 cross_f3_f3( float3 x, float3 y)
{
float3 r;
r.z = x.x * y.y - x.y * y.x; r.x = x.y * y.z - x.z * y.y; r.y = x.z * y.x - x.x * y.z;
return r;
}

inline float clamp( float in, float clampMin, float clampMax) {
return fmaxf( clampMin, fminf(in, clampMax));
}

inline float3 clamp_f3( float3 A, float mn, float mx)
{
float3 out;
out.x = clamp( A.x, mn, mx); out.y = clamp( A.y, mn, mx); out.z = clamp( A.z, mn, mx);
return out;
}

inline float dot_f3_f3( float3 x, float3 y)
{
return x.x * y.x + x.y * y.y + x.z * y.z;
}

inline float length_f3( float3 x)
{
return sqrtf( x.x * x.x + x.y * x.y + x.z * x.z );
}

inline mat2 transpose_f22( mat2 A)
{
mat2 B;
B.c0 = make_float2(A.c0.x, A.c1.x); B.c1 = make_float2(A.c0.y, A.c1.y);
return B;
}

inline mat3 transpose_f33( mat3 A)
{
float r[3][3];
float a[3][3] =	{{A.c0.x, A.c0.y, A.c0.z}, {A.c1.x, A.c1.y, A.c1.z}, {A.c2.x, A.c2.y, A.c2.z}};
for( int i = 0; i < 3; ++i){
for( int j = 0; j < 3; ++j){
r[i][j] = a[j][i];}}
mat3 R = make_mat3(make_float3(r[0][0], r[0][1], r[0][2]), make_float3(r[1][0], r[1][1], r[1][2]), make_float3(r[2][0], r[2][1], r[2][2]));
return R;
}

inline mat3 mult_f_f33( float f, mat3 A)
{
float r[3][3];
float a[3][3] =	{{A.c0.x, A.c0.y, A.c0.z}, {A.c1.x, A.c1.y, A.c1.z}, {A.c2.x, A.c2.y, A.c2.z}};
for( int i = 0; i < 3; ++i ){
for( int j = 0; j < 3; ++j ){
r[i][j] = f * a[i][j];}}
mat3 R = make_mat3(make_float3(r[0][0], r[0][1], r[0][2]), make_float3(r[1][0], r[1][1], r[1][2]), make_float3(r[2][0], r[2][1], r[2][2]));
return R;
}

inline float3 mult_f3_f33( float3 X, mat3 A)
{
float r[3];
float x[3] = {X.x, X.y, X.z};
float a[3][3] =	{{A.c0.x, A.c0.y, A.c0.z}, {A.c1.x, A.c1.y, A.c1.z}, {A.c2.x, A.c2.y, A.c2.z}};
for( int i = 0; i < 3; ++i){
r[i] = 0.0f;
for( int j = 0; j < 3; ++j){
r[i] = r[i] + x[j] * a[j][i];}}
return make_float3(r[0], r[1], r[2]);
}

inline mat3 mult_f33_f33( mat3 A, mat3 B)
{
float r[3][3];
float a[3][3] =	{{A.c0.x, A.c0.y, A.c0.z},
{A.c1.x, A.c1.y, A.c1.z},
{A.c2.x, A.c2.y, A.c2.z}};
float b[3][3] =	{{B.c0.x, B.c0.y, B.c0.z},
{B.c1.x, B.c1.y, B.c1.z},
{B.c2.x, B.c2.y, B.c2.z}};
for( int i = 0; i < 3; ++i){
for( int j = 0; j < 3; ++j){
r[i][j] = 0.0f;
for( int k = 0; k < 3; ++k){
r[i][j] = r[i][j] + a[i][k] * b[k][j];
}}}
mat3 R = make_mat3(make_float3(r[0][0], r[0][1], r[0][2]), make_float3(r[1][0], r[1][1], r[1][2]), make_float3(r[2][0], r[2][1], r[2][2]));
return R;
}

inline mat3 add_f33_f33( mat3 A, mat3 B)
{
float r[3][3];
float a[3][3] =	{{A.c0.x, A.c0.y, A.c0.z}, {A.c1.x, A.c1.y, A.c1.z}, {A.c2.x, A.c2.y, A.c2.z}};
float b[3][3] =	{{B.c0.x, B.c0.y, B.c0.z}, {B.c1.x, B.c1.y, B.c1.z}, {B.c2.x, B.c2.y, B.c2.z}};
for( int i = 0; i < 3; ++i ){
for( int j = 0; j < 3; ++j ){
r[i][j] = a[i][j] + b[i][j];}}
mat3 R = make_mat3(make_float3(r[0][0], r[0][1], r[0][2]), make_float3(r[1][0], r[1][1], r[1][2]), make_float3(r[2][0], r[2][1], r[2][2]));
return R;
}

inline mat3 invert_f33( mat3 A)
{
mat3 R;
float result[3][3];
float a[3][3] =	{{A.c0.x, A.c0.y, A.c0.z}, {A.c1.x, A.c1.y, A.c1.z}, {A.c2.x, A.c2.y, A.c2.z}};
float det =   a[0][0] * a[1][1] * a[2][2] + a[0][1] * a[1][2] * a[2][0]
+ a[0][2] * a[1][0] * a[2][1] - a[2][0] * a[1][1] * a[0][2]
- a[2][1] * a[1][2] * a[0][0] - a[2][2] * a[1][0] * a[0][1];
if( det != 0.0f ){
result[0][0] = a[1][1] * a[2][2] - a[1][2] * a[2][1]; result[0][1] = a[2][1] * a[0][2] - a[2][2] * a[0][1];
result[0][2] = a[0][1] * a[1][2] - a[0][2] * a[1][1]; result[1][0] = a[2][0] * a[1][2] - a[1][0] * a[2][2];
result[1][1] = a[0][0] * a[2][2] - a[2][0] * a[0][2]; result[1][2] = a[1][0] * a[0][2] - a[0][0] * a[1][2];
result[2][0] = a[1][0] * a[2][1] - a[2][0] * a[1][1]; result[2][1] = a[2][0] * a[0][1] - a[0][0] * a[2][1];
result[2][2] = a[0][0] * a[1][1] - a[1][0] * a[0][1];
R = make_mat3(make_float3(result[0][0], result[0][1], result[0][2]), make_float3(result[1][0], result[1][1], 
result[1][2]), make_float3(result[2][0], result[2][1], result[2][2]));
return mult_f_f33( 1.0f / det, R);
}
R = make_mat3(make_float3(1.0f, 0.0f, 0.0f), make_float3(0.0f, 1.0f, 0.0f), make_float3(0.0f, 0.0f, 1.0f));
return R;
}

inline float lookup1D( float table[], float pMin, float pMax, float p)
{
int Size = size(table);
if( p < pMin ) return table[ 0 ];
if( p > pMax ) return table[ Size - 1 ];
float t = (p - pMin) / (pMax - pMin ) * (Size - 1.0f);
int i = floor(t);
float s = t - i;
return table[i] * ( 1.0f - s ) + table[i + 1] * s; 
}

inline float lookupCubic1D( float table[], float pMin, float pMax, float p)
{
int Size = size(table);
if( p < pMin ) return table[ 0 ];
if( p > pMax ) return table[ Size - 1 ];
float t = (p - pMin) / (pMax - pMin) * (Size - 1 );
int i = floor(t);
float s = t - i;
float m0;
float m1;
if( i > 0 ){
m0 = (table[i + 1] - table[i - 1]) / 2.0f;
}
if( i < Size-2 ){
m1 = (table[i + 2] - table[i]) / 2.0f;
}
if( i == 0) {
m0 = (3 * table[i+1] - table[i] - m1);
}
if( i == Size - 2 ){
m1 = (3.0f * table[i + 1] - table[i] - m0);
}
return table[i] * (2.0f * s*s*s - 3.0f * s*s + 1.0f) + m0 * (s*s*s - 2.0f * s*s + s) + table[i + 1] * (-2.0f * s*s*s + 3.0f * s*s) + m1 * (s*s*s - s*s);
}

inline float interpolate1D (float2 table[], int Size, float p)
{
if( p <= table[0].x ) return table[0].y;
if( p >= table[Size - 1].x ) return table[Size - 1].y;
for( int i = 0; i < Size - 1; ++i ){
if( table[i].x <= p && p < table[i+1].x ){
float s = (p - table[i].x) / (table[i + 1].x - table[i].x);
return table[i].y * ( 1 - s ) + table[i + 1].y * s;
}}
return 0.0f;
}

inline float interpolateCubic1D( float2 table[], float p)
{
int Size = size(table);
if( p <= table[0].x ) return table[0].y;
if( p >= table[Size - 1].x ) return table[Size - 1].y;
if( Size == 2 ) {
float s = (p - table[0].x) / (table[1].x - table[0].x);
return (1.0f - s) * table[0].y + s * table[1].y;
}
for( int i = 0; i < Size - 1; ++i ){
if( table[i].x <= p && p < table[i+1].x ){
float s = (p - table[i].x) / (table[i + 1].x - table[i].x);
float dx1 = (table[i + 1].x - table[i].x);
float dy1 = (table[i + 1].y - table[i].y);
float m0;
float m1;
if( i > 0 ){
float dy0 = (table[i].y - table[i - 1].y);
float dx0 = (table[i].x - table[i - 1].x);
m0 = (dy1 + dx1 * dy0 / dx0) / 2.0f;
}
if( i < Size - 2 ){
float dx2 = (table[i + 2].x - table[i + 1].x);
float dy2 = (table[i + 2].y - table[i + 1].y);
m1 = (dy1 + dx1 * dy2 / dx2) / 2.0f;
}
if( i == 0) {
m0 = (3.0f * dy1 - m1) / 2.0f;
}
if( i == Size - 2 ){
m1 = (3.0f * dy1 - m0) / 2.0f;
}
return table[i].y * (2.0f * s*s*s - 3.0f * s*s + 1.0f) + m0 * (s*s*s - 2.0f * s*s + s) + table[i + 1].y * (-2.0f * s*s*s + 3.0f * s*s) + m1 * (s*s*s - s*s);
}}
return 0.0f;
}

inline mat3 RGBtoXYZ( Chromaticities N)
{
mat3 M = make_mat3(make_float3(N.red.x, N.red.y, 1.0f - (N.red.x + N.red.y)),
make_float3(N.green.x, N.green.y, 1.0f - (N.green.x + N.green.y)), make_float3(N.blue.x, N.blue.y, 1.0f - (N.blue.x + N.blue.y)));
float3 wh = make_float3(N.white.x / N.white.y, 1.0f, (1.0f - (N.white.x + N.white.y)) / N.white.y);
wh = mult_f3_f33(wh, invert_f33(M));
mat3 WH =  make_mat3(make_float3(wh.x, 0.0f, 0.0f), make_float3(0.0f, wh.y, 0.0f), make_float3(0.0f, 0.0f, wh.z));
M = mult_f33_f33(WH, M);
return M;
}

inline mat3 XYZtoRGB( Chromaticities N)
{
mat3 M = invert_f33(RGBtoXYZ(N));
return M;
}

inline float SLog3_to_linear( float SLog )
{
float out;
if (SLog >= 171.2102946929f / 1023.0f){
out = powf(10.0f, (SLog * 1023.0f - 420.0f) / 261.5f) * (0.18f + 0.01f) - 0.01f;
} else {
out = (SLog * 1023.0f - 95.0f) * 0.01125000f / (171.2102946929f - 95.0f);}
return out;
}

inline float vLogToLinScene( float x)
{
const float cutInv = 0.181f;
const float b = 0.00873f;
const float c = 0.241514f;
const float d = 0.598206f;
if (x <= cutInv)
return (x - 0.125f) / 5.6f;
else
return powf(10.0f, (x - d) / c) - b;
}

inline float SLog1_to_lin( float SLog, float b, float ab, float w)
{
float lin;
if (SLog >= ab)
lin = ( powf(10.0f, ( ( ( SLog - b) / ( w - b) - 0.616596f - 0.03f) / 0.432699f)) - 0.037584f) * 0.9f;
else if (SLog < ab) 
lin = ( ( ( SLog - b) / ( w - b) - 0.030001222851889303f) / 5.0f) * 0.9f;
return lin;
}

inline float SLog2_to_lin( float SLog, float b, float ab, float w)
{
float lin;
if (SLog >= ab)
lin = ( 219.0f * ( powf(10.0f, ( ( ( SLog - b) / ( w - b) - 0.616596f - 0.03f) / 0.432699f)) - 0.037584f) / 155.0f) * 0.9f;
else if (SLog < ab) 
lin = ( ( ( SLog - b) / ( w - b) - 0.030001222851889303f) / 3.53881278538813f) * 0.9f;
return lin;
}

inline float CanonLog_to_linear ( float clog)
{
float out;
if(clog < 0.12512248f)
out = -( powf( 10.0f, ( 0.12512248f - clog ) / 0.45310179f ) - 1.0f ) / 10.1596f;
else
out = ( powf( 10.0f, ( clog - 0.12512248f ) / 0.45310179f ) - 1.0f ) / 10.1596f;
return out;
}

inline float CanonLog2_to_linear ( float clog2)
{
float out;
if(clog2 < 0.092864125f)
out = -( powf( 10.0f, ( 0.092864125f - clog2 ) / 0.24136077f ) - 1.0f ) / 87.099375f;
else
out = ( powf( 10.0f, ( clog2 - 0.092864125f ) / 0.24136077f ) - 1.0f ) / 87.099375f;
return out;
}

inline float CanonLog3_to_linear ( float clog3)
{
float out;
if(clog3 < 0.097465473f)
out = -( powf( 10.0f, ( 0.12783901f - clog3 ) / 0.36726845f ) - 1.0f ) / 14.98325f;
else if(clog3 <= 0.15277891f)
out = ( clog3 - 0.12512219f ) / 1.9754798f;
else
out = ( powf( 10.0f, ( clog3 - 0.12240537f ) / 0.36726845f ) - 1.0f ) / 14.98325f;
return out;
}

inline float Log3G10_to_linear_2016 ( float log3g10)
{
float a, b, c, mirror, linear;
a = 0.224282f;
b = 155.975327f;
c = 0.01f;
mirror = 1.0f;
if (log3g10 < 0.0f){
mirror = -1.0f;
log3g10 = -log3g10;}
linear = (powf(10.0f, log3g10 / a) - 1.0f) / b;
linear = linear * mirror - c;
return linear;
}

inline float Log3G10_to_linear ( float log3g10)
{
float a, b, c, g, linear;
a = 0.224282f; b = 155.975327f; c = 0.01f; g = 15.1927f;
linear = log3g10 < 0.0f ? (log3g10 / g) : (powf(10.0f, log3g10 / a) - 1.0f) / b;
linear = linear - c;
return linear;
}

#endif