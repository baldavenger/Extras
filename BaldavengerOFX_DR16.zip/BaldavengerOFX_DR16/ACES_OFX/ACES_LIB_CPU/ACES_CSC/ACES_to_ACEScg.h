#ifndef __ACES_TO_ACESCG_H_INCLUDED__
#define __ACES_TO_ACESCG_H_INCLUDED__

inline float3 ACES_to_ACEScg( float3 ACES)
{
ACES = max_f3_f( ACES, 0.0f);
float3 ACEScg = mult_f3_f33( ACES, AP0_2_AP1_MAT);
return ACEScg;
}

#endif