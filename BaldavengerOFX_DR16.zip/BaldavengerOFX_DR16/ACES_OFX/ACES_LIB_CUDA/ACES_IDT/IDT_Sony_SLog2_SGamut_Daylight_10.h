#ifndef __IDT_SONY_SLOG2_SGAMUT_DAYLIGHT_10_H_INCLUDED__
#define __IDT_SONY_SLOG2_SGAMUT_DAYLIGHT_10_H_INCLUDED__

__device__ inline float3 IDT_Sony_SLog2_SGamut_Daylight_10( float3 In)
{
mat3 SGAMUT_DAYLIGHT_TO_ACES_MTX = { { 0.8764457030f,  0.0774075345f,  0.0573564351f}, { 0.0145411681f,  0.9529571767f, -0.1151066335f}, { 0.1090131290f, -0.0303647111f,  1.0577501984f} };
							
float B = 64.0f;
float AB = 90.0f;
float W = 940.0f;

float3 SLog;
SLog.x = In.x * 1023.0f;
SLog.y = In.y * 1023.0f;
SLog.z = In.z * 1023.0f;

float3 lin;
lin.x = SLog2_to_lin( SLog.x, B, AB, W);
lin.y = SLog2_to_lin( SLog.y, B, AB, W);
lin.z = SLog2_to_lin( SLog.z, B, AB, W);

float3 aces = mult_f3_f33( lin, SGAMUT_DAYLIGHT_TO_ACES_MTX);

return aces;
}

#endif