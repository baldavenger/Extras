#ifndef __IDT_CANON_C300MK2_CANONLOG_BT2020_D_TNG_H_INCLUDED__
#define __IDT_CANON_C300MK2_CANONLOG_BT2020_D_TNG_H_INCLUDED__

__device__ inline float3 IDT_Canon_C300mk2_CanonLog_BT2020_D_Tng( float3 In)
{
float3 CLogIRE;
CLogIRE.x = (In.x * 1023.0f - 64.0f) / 876.0f;
CLogIRE.y = (In.y * 1023.0f - 64.0f) / 876.0f;
CLogIRE.z = (In.z * 1023.0f - 64.0f) / 876.0f;

float3 lin;
lin.x = 0.9f * CanonLog_to_linear( CLogIRE.x);
lin.y = 0.9f * CanonLog_to_linear( CLogIRE.y);
lin.z = 0.9f * CanonLog_to_linear( CLogIRE.z);

float3 aces;
aces.x = 0.724488568f * lin.x + 0.115140904f * lin.y + 0.160370529f * lin.z;
aces.y = 0.010659276f * lin.x + 0.839605344f * lin.y + 0.149735380f * lin.z;
aces.z = 0.014560161f * lin.x - 0.028562057f * lin.y + 1.014001897f * lin.z;

return aces;
}

#endif