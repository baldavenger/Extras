#ifndef __IDT_CANON_C500_CINEMAGAMUT_A_D55_H_INCLUDED__
#define __IDT_CANON_C500_CINEMAGAMUT_A_D55_H_INCLUDED__

__device__ inline float3 IDT_Canon_C500_CinemaGamut_A_D55( float3 In)
{
float3 CLogIRE;
CLogIRE.x = (In.x * 1023.0f - 64.0f) / 876.0f;
CLogIRE.y = (In.y * 1023.0f - 64.0f) / 876.0f;
CLogIRE.z = (In.z * 1023.0f - 64.0f) / 876.0f;

float3 lin;
lin.x = 0.9f * CanonLog_to_linear( CLogIRE.x);
lin.y = 0.9f * CanonLog_to_linear( CLogIRE.y);
lin.z = 0.9f * CanonLog_to_linear( CLogIRE.z);

float3 aces;
aces.x =  0.763064455f * lin.x + 0.149021161f * lin.y + 0.087914384f * lin.z;
aces.y =  0.003657457f * lin.x + 1.10696038f  * lin.y - 0.110617837f * lin.z;
aces.z = -0.009407794f * lin.x - 0.218383305f * lin.y + 1.227791099f * lin.z;

return aces;
}

#endif