#ifndef __ACESCC_TO_ACES_H_INCLUDED__
#define __ACESCC_TO_ACES_H_INCLUDED__

__device__ inline float ACEScc_to_lin( float in)
{
if (in < -0.3013698630f)
return (powf( 2.0f, in * 17.52f - 9.72f) - powf( 2.0f, -16.0f)) * 2.0f;
else
return powf( 2.0f, in * 17.52f - 9.72f);
}

__device__ inline float3 ACEScc_to_ACES( float3 ACEScc)
{
float3 lin_AP1;
lin_AP1.x = ACEScc_to_lin( ACEScc.x);
lin_AP1.y = ACEScc_to_lin( ACEScc.y);
lin_AP1.z = ACEScc_to_lin( ACEScc.z);
float3 ACES = mult_f3_f33( lin_AP1, AP1_2_AP0_MAT);
return ACES;  
}

#endif