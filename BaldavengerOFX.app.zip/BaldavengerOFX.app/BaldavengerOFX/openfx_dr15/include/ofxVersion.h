#ifndef _ofxVersion_h_
#define _ofxVersion_h_

#define OFX_VERSION_MAJOR 1
#define OFX_VERSION_MINOR 3
#define OFX_VERSION_STR   "1.3"

#define OFX_API_1_1
#define OFX_API_1_2
#define OFX_API_1_3

#endif
